<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-tree {
  background: var(--zk-mask-background-color);
  border: 1px solid var(--zk-base-border-color);
  overflow: hidden;
  zoom: 1;
}
.z-tree:focus-visible {
  box-shadow: var(--zk-mesh-focus-box-shadow);
  transition: unset;
}
.z-tree-header {
  width: 100%;
  position: relative;
  overflow: hidden;
}
.z-tree-header table {
  border-spacing: 0;
}
.z-tree-header table th,
.z-tree-header table td {
  background-clip: padding-box;
  padding: 0;
}
.z-tree-header table th {
  text-align: inherit;
}
.z-tree-body {
  position: relative;
  overflow: hidden;
  overflow-anchor: none;
}
.z-tree-body table {
  border-spacing: 0;
}
.z-tree-body table th,
.z-tree-body table td {
  background-clip: padding-box;
  padding: 0;
}
.z-tree-body table th {
  text-align: inherit;
}
.z-tree-body .z-tree-emptybody td {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-disabled-color);
  text-align: left;
  height: 1px;
  padding: 12px 16px;
}
.z-tree-footer {
  overflow: hidden;
  white-space: nowrap;
}
.z-tree-footer table {
  border-spacing: 0;
}
.z-tree-footer table th,
.z-tree-footer table td {
  background-clip: padding-box;
  padding: 0;
}
.z-tree-footer table th {
  text-align: inherit;
}
.z-tree-footer .z-treefooter {
  overflow: hidden;
  background: var(--zk-mesh-foot-background-color);
  border-top: 1px solid var(--zk-base-border-color);
}
.z-tree-footer .z-treefoot-bar {
  background: var(--zk-mesh-foot-background-color);
}
.z-tree-loading {
  background: transparent no-repeat center;
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/progress-72.gif")});
}
.z-tree-icon,
.z-tree-line {
  display: inline-block;
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  line-height: var(--zk-base-icon-height);
  vertical-align: middle;
}
.z-tree-icon {
  font-size: var(--zk-font-size-large);
  color: var(--zk-text-color-default);
  text-align: center;
  cursor: pointer;
}
.z-treecol-content,
.z-treecell-content,
.z-treefooter-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  padding: var(--zk-mesh-body-padding);
  line-height: var(--zk-mesh-content-line-height);
  overflow: hidden;
}
.z-treecol-content {
  color: var(--zk-mesh-title-color);
  position: relative;
}
.z-treecell-content {
  line-height: var(--zk-treecell-content-line-height);
}
.z-treefooter-content {
  color: var(--zk-text-color-light);
}
.z-treecell-text {
  vertical-align: middle;
  margin-left: 8px;
}
.z-treecols th:first-child {
  border-left: none;
}
.z-treecols th:first-child.z-treecols-border {
  border-left: 1px solid var(--zk-mesh-title-border-color);
}
.z-treecols-bar {
  background: var(--zk-mesh-title-background-color);
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
}
.z-treecol {
  background: var(--zk-mesh-title-background-color);
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
  padding: 0;
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}
.z-treecol:focus-visible {
  box-shadow: var(--zk-mesh-title-focus-box-shadow);
  transition: unset;
}
.z-treecol-sort {
  cursor: pointer;
}
.z-treecol-sort .z-treecol-sorticon {
  color: var(--zk-mesh-title-color);
  position: absolute;
  top: -7px;
  left: 50%;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  transform: translateX(-50%);
}
.z-treecol-sort .z-treecol-sorticon :active {
  background: rgba(0, 0, 0, 0);
}
.z-treecol-sizing,
.z-treecol-sizing .z-treecol-content {
  cursor: col-resize;
}
.z-treecol-checkable {
  display: inline-block;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-checked-color);
  border: 1px solid var(--zk-checked-border-color);
  background: var(--zk-checked-background-color);
  vertical-align: text-top;
  margin-right: 8px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-treecol-checkable:focus-visible {
  box-shadow: var(--zk-mesh-title-focus-box-shadow);
  transition: unset;
}
.z-treecol-checkable .z-treecol-icon {
  display: none;
  cursor: default;
}
.z-treecol-checkable.z-treecol-checked .z-treecol-icon {
  display: block;
}
.z-treecol-partial > .z-treecol-icon {
  color: var(--zk-checked-color);
  display: block;
}
.z-tree-paging-top {
  border-bottom: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
  width: 100%;
}
.z-tree-paging-bottom {
  border-top: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
  width: 100%;
}
.z-tree-autopaging .z-treecell-content {
  height: var(--zk-mesh-auto-paging-row-height);
  padding: var(--zk-mesh-auto-paging-row-padding);
  line-height: var(--zk-mesh-auto-paging-row-line-height);
  overflow: hidden;
}
.z-treerow .z-treecell {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  overflow: hidden;
  cursor: pointer;
  background: var(--zk-mesh-background-color);
  position: relative;
  z-index: 0;
}
.z-treerow-focus > .z-treecell {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-treerow-focus > .z-treecell:first-child {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 2px 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-treerow-focus > .z-treecell:last-child {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset -2px 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-treerow-focus > .z-treecell > .z-treecell-content {
  color: var(--zk-hover-color);
}
.z-treerow:hover > .z-treecell {
  background: var(--zk-hover-background-color);
}
.z-treerow:hover > .z-treecell > .z-treecell-content {
  color: var(--zk-hover-color);
}
.z-treerow-checkable {
  display: inline-block;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-checked-color);
  border: 1px solid var(--zk-checked-border-color);
  background: var(--zk-checked-background-color);
  vertical-align: text-top;
  margin-right: 8px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-treerow-checkable.z-treerow-radio {
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
}
.z-treerow-checkable .z-treerow-icon {
  display: none;
  cursor: default;
}
.z-treerow.z-treerow-selected > .z-treecell {
  background: var(--zk-selected-background-color);
}
.z-treerow.z-treerow-selected > .z-treecell > .z-treecell-content {
  color: var(--zk-selected-color);
}
.z-treerow.z-treerow-selected:hover > .z-treecell {
  background: var(--zk-selected-hover-background-color);
}
.z-treerow.z-treerow-selected:hover > .z-treecell > .z-treecell-content {
  color: var(--zk-selected-hover-color);
}
.z-treerow.z-treerow-selected.z-treerow-focus > .z-treecell {
  background: var(--zk-selected-focus-background-color);
}
.z-treerow.z-treerow-selected.z-treerow-focus > .z-treecell > .z-treecell-content {
  color: var(--zk-selected-focus-color);
}
.z-treerow.z-treerow-selected.z-treerow-focus:hover > .z-treecell {
  background: var(--zk-selected-hover-background-color);
}
.z-treerow.z-treerow-selected.z-treerow-focus:hover > .z-treecell > .z-treecell-content {
  color: var(--zk-selected-hover-color);
}
.z-treerow-selected > .z-treecell > .z-treecell-content > .z-treerow-checkable .z-treerow-icon {
  color: var(--zk-checked-color);
  display: block;
}
.z-treerow-selected > .z-treecell > .z-treecell-content > .z-treerow-checkable .z-treerow-icon.z-icon-radio {
  width: 10px;
  height: 10px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
  background: var(--zk-checked-color);
  position: relative;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.z-treerow.z-treerow-disabled * {
  color: var(--zk-disabled-color) !important;
  cursor: default !important;
}
.z-treerow-partial > .z-treecell > .z-treecell-content > .z-treerow-checkable .z-treerow-icon {
  color: var(--zk-checked-color);
  display: block;
}
.z-treecell-hidden-col {
  white-space: nowrap;
  overflow: hidden;
}
