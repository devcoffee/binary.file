<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-fisheye,
.z-fisheye-text,
.z-fisheye-image {
  position: absolute;
  cursor: pointer;
}
.z-fisheye {
  z-index: 2;
}
.z-fisheye-image {
  width: 100%;
  height: 100%;
  border: 0;
}
.z-fisheye-text {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-x-small);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-tooltip-color);
  display: none;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: 4px;
  background: var(--zk-tooltip-background-color);
  text-align: center;
  -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -o-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -ms-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
}
.z-fisheyebar-inner {
  position: relative;
}
