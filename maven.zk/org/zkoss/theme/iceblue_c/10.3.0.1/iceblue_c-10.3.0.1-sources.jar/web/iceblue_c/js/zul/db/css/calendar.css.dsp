<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-calendar {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-calendar-font-size);
  font-weight: normal;
  font-style: normal;
  background-color: var(--zk-calendar-background-color);
  min-width: 230px;
  padding: var(--zk-calendar-padding);
}
.z-calendar a {
  text-decoration: none;
}
.z-calendar th {
  width: 32px;
  height: 36px;
  min-width: 32px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-calendar-font-size-small);
  font-weight: 700;
  font-style: normal;
  color: var(--zk-calendar-week-title-color);
  text-align: center;
  padding: 8px 0;
}
.z-calendar table {
  width: 100%;
}
.z-calendar-title {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-calendar-title-font-size);
  color: var(--zk-calendar-title-color);
  width: 100%;
  line-height: var(--zk-base-line-height);
  text-align: center;
}
.z-calendar-title:hover {
  color: var(--zk-calendar-title-hover-color);
}
.z-calendar-header {
  position: relative;
  text-align: center;
}
.z-calendar-header > a {
  display: inline-block;
}
.z-calendar-header:first-child {
  line-height: var(--zk-calendar-title-line-height);
}
.z-calendar-body {
  height: 100%;
}
.z-calendar-cell {
  font-size: var(--zk-calendar-font-size-small);
  color: var(--zk-calendar-cell-color);
  min-width: var(--zk-calendar-cell-width);
  height: var(--zk-calendar-cell-height);
  line-height: normal;
  text-align: center;
  cursor: pointer;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-calendar-cell:hover {
  color: var(--zk-calendar-cell-color);
  background: var(--zk-calendar-cell-hover-background-color);
}
.z-calendar-decade,
.z-calendar-month,
.z-calendar-year {
  padding-top: 8px;
}
.z-calendar-decade .z-calendar-cell,
.z-calendar-month .z-calendar-cell,
.z-calendar-year .z-calendar-cell {
  min-width: 56px;
  height: 40px;
  padding: 0 8px;
}
.z-calendar-decade .z-calendar-cell {
  text-align: left;
}
.z-calendar-wk.z-calendar .z-calendar-decade .z-calendar-cell,
.z-calendar-wk.z-calendar .z-calendar-month .z-calendar-cell,
.z-calendar-wk.z-calendar .z-calendar-year .z-calendar-cell {
  width: 64px;
  height: 44px;
}
.z-calendar-weekend {
  color: var(--zk-weekend-color);
  background: var(--zk-weekend-background-color);
}
.z-calendar-weekday {
  color: var(--zk-weekday-color);
  background: var(--zk-weekday-background-color);
}
.z-calendar-outrange {
  color: var(--zk-disabled-color);
  text-shadow: none;
}
.z-calendar-weekofyear {
  font-style: italic !important;
  color: var(--zk-weekofyear-color) !important;
  background: var(--zk-weekofyear-background-color);
  cursor: default;
}
.z-calendar-weekofyear:hover {
  color: var(--zk-weekofyear-color);
  background: var(--zk-weekofyear-background-color);
}
.z-calendar-anima {
  overflow: hidden;
  position: relative;
}
.z-calendar-anima-inner {
  height: 100%;
  width: 200%;
  position: absolute;
}
.z-calendar-anima-inner table {
  width: 50%;
  float: left;
}
.z-calendar-selected {
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  color: var(--zk-calendar-selected-color);
  background: var(--zk-calendar-selected-background-color);
}
.z-calendar-selected:hover {
  color: var(--zk-calendar-selected-hover-color);
  background: var(--zk-calendar-selected-hover-background-color);
}
.z-calendar-outside {
  color: var(--zk-disabled-color);
  text-shadow: none;
}
.z-calendar-icon {
  font-size: var(--zk-calendar-icon-font-size);
  color: var(--zk-icon-color);
  width: var(--zk-base-button-width);
  height: var(--zk-base-button-height);
  padding: 0 4px;
  position: absolute;
}
.z-calendar-icon:hover {
  color: var(--zk-icon-hover-color);
}
.z-calendar-right {
  right: var(--zk-calendar-left-right-position);
}
.z-calendar-left {
  left: var(--zk-calendar-left-right-position);
}
.z-calendar-left[disabled],
.z-calendar-right[disabled],
.z-calendar-disabled {
  color: var(--zk-disabled-color) !important;
  text-shadow: none !important;
  cursor: default !important;
}
.z-calendar-left[disabled]:hover,
.z-calendar-right[disabled]:hover,
.z-calendar-disabled:hover {
  background: var(--zk-calendar-background-color);
}
.z-calendar-today {
  border: 1px solid var(--zk-base-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  background-color: var(--zk-calendar-background-color);
  margin-top: var(--zk-calendar-today-margin-top);
}
.z-calendar-today .z-calendar-title {
  display: block;
  padding: var(--zk-calendar-today-title-padding);
  color: var(--zk-calendar-today-color);
}
.z-calendar-today:hover {
  border-color: var(--zk-hover-border-color);
  background-color: var(--zk-calendar-cell-hover-background-color);
}
.z-calendar-today:active {
  border-color: var(--zk-active-border-color);
  background-color: var(--zk-calendar-selected-background-color);
}
.z-calendar-today:active .z-calendar-title {
  color: var(--zk-calendar-selected-color);
}
.z-calendar-decade + .z-calendar-today,
.z-calendar-month + .z-calendar-today,
.z-calendar-year + .z-calendar-today {
  display: none;
}
.z-datebox-timezone {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
}
.z-datebox-popup {
  position: absolute;
}
.z-datebox-popup .z-calendar {
  background: transparent;
  border: 0;
}
.z-datebox-popup .z-calendar + .z-timebox {
  margin: 5px;
}
.z-datebox-popup .z-calendar ~ .z-datebox-timezone {
  margin: 0 5px 5px;
}
