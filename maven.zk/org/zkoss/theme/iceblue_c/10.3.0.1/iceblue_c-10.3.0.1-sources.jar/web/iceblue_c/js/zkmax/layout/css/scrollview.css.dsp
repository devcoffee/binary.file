<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-scrollview {
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}
.z-scrollview-horizontal .z-scrollview-content {
  height: 100%;
}
.z-scrollview-horizontal .z-scrollview-inner {
  display: inline-block;
  vertical-align: top;
}
.z-scrollview-horizontal .z-scrollview-scrollbar {
  height: 7px;
  bottom: 1px;
  left: 2px;
  right: 2px;
}
.z-scrollview-horizontal .z-scrollview-scrollbar-indicator {
  height: 100%;
}
.z-scrollview-vertical .z-scrollview-content {
  width: 100%;
}
.z-scrollview-vertical .z-scrollview-scrollbar {
  width: 7px;
  bottom: 2px;
  top: 2px;
  right: 1px;
}
.z-scrollview-vertical .z-scrollview-scrollbar-indicator {
  width: 100%;
}
.z-scrollview-content {
  -webkit-transition-duration: 0;
  -moz-transition-duration: 0;
  -o-transition-duration: 0;
  -ms-transition-duration: 0;
  transition-duration: 0;
  -webkit-transform-origin: 0 0;
  -moz-transform-origin: 0 0;
  -o-transform-origin: 0 0;
  -ms-transform-origin: 0 0;
  transform-origin: 0 0;
  -webkit-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -moz-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -o-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -ms-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -webkit-transition-delay: 0;
  -moz-transition-delay: 0;
  -o-transition-delay: 0;
  -ms-transition-delay: 0;
  transition-delay: 0;
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform: translate3d(0, 0, 0);
  -o-transform: translate3d(0, 0, 0);
  -ms-transform: translate3d(0, 0, 0);
  transform: translate3d(0, 0, 0);
}
.z-scrollview-inner {
  position: relative;
  zoom: 1;
}
.z-scrollview-scrollbar {
  position: absolute;
  z-index: 100;
  pointer-events: none;
  opacity: 0;
  overflow: hidden;
  -webkit-transition-property: opacity;
  -moz-transition-property: opacity;
  -o-transition-property: opacity;
  -ms-transition-property: opacity;
  transition-property: opacity;
  -webkit-transition-duration: 0;
  -moz-transition-duration: 0;
  -o-transition-duration: 0;
  -ms-transition-duration: 0;
  transition-duration: 0;
}
.z-scrollview-scrollbar-indicator {
  border: 1px solid rgba(255, 255, 255, 0.9);
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  -o-border-radius: 3px;
  -ms-border-radius: 3px;
  border-radius: 3px;
  background: rgba(0, 0, 0, 0.5);
  background-clip: padding-box;
  position: absolute;
  z-index: 100;
  pointer-events: none;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -o-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -moz-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -o-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -ms-transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1);
  -webkit-transition-duration: 0;
  -moz-transition-duration: 0;
  -o-transition-duration: 0;
  -ms-transition-duration: 0;
  transition-duration: 0;
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform: translate3d(0, 0, 0);
  -o-transform: translate3d(0, 0, 0);
  -ms-transform: translate3d(0, 0, 0);
  transform: translate3d(0, 0, 0);
}
.z-scrollview-load {
  display: none;
  width: 100%;
  height: 100%;
  text-align: center;
  vertical-align: middle;
  position: absolute;
}
.z-scrollview-load-up,
.z-scrollview-load-down,
.z-scrollview-load-left,
.z-scrollview-load-right {
  width: 32px;
  height: 32px;
  position: absolute;
  z-index: 999;
}
.z-scrollview-load-up {
  background-image: url(${c:encodeThemeURL("~./zkmax/img/tablet/layout/load-up.png")});
}
.z-scrollview-load-down {
  background-image: url(${c:encodeThemeURL("~./zkmax/img/tablet/layout/load-down.png")});
}
.z-scrollview-load-left {
  background-image: url(${c:encodeThemeURL("~./zkmax/img/tablet/layout/load-left.png")});
}
.z-scrollview-load-right {
  background-image: url(${c:encodeThemeURL("~./zkmax/img/tablet/layout/load-right.png")});
}
