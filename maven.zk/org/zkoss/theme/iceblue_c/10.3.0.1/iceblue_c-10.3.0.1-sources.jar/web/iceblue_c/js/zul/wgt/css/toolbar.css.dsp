<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-toolbar {
  display: block;
  border: 0;
  padding: var(--zk-toolbar-padding);
  background: var(--zk-base-background-color);
  position: relative;
}
.z-toolbar-start {
  float: left;
  clear: none;
}
.z-toolbar-end {
  float: right;
  clear: none;
}
.z-toolbar-center {
  text-align: center;
  margin: 0 auto;
}
.z-toolbar-overflowpopup {
  white-space: nowrap;
  font-size: 0;
}
.z-toolbar-overflowpopup-button {
  font-size: var(--zk-toolbar-overflowpopup-button-size);
}
.z-toolbar-overflowpopup-off > .z-toolbar-overflowpopup-button {
  display: none;
}
.z-toolbar-overflowpopup-on > .z-toolbar-overflowpopup-button {
  cursor: pointer;
  position: absolute;
  top: 50%;
  -webkit-transform: translateY(-50%);
  -moz-transform: translateY(-50%);
  -o-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  right: var(--zk-toolbar-horizontal-padding);
}
.z-toolbar-overflowpopup-on > .z-toolbar-overflowpopup-button:hover {
  color: var(--zk-color-primary-lighter);
}
.z-toolbar-overflowpopup-on > .z-toolbar-end {
  position: relative;
  right: calc(var(--zk-toolbar-overflowpopup-button-size) + var(--zk-toolbar-horizontal-padding));
}
.z-toolbar-overflowpopup-on > .z-toolbar-center {
  padding-right: var(--zk-toolbar-overflowpopup-button-size);
}
.z-toolbar-popup {
  border: 1px solid var(--zk-popup-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  background-color: var(--zk-popup-background-color);
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  display: block;
  position: absolute;
  padding: 0 4px;
  overflow: auto;
  max-height: 350px;
}
.z-toolbar-popup > *:not([disabled]) {
  display: table !important;
  margin: 4px 0 4px 8px;
}
.z-toolbar-popup-open {
  visibility: visible;
}
.z-toolbar-popup-close {
  visibility: hidden;
}
.z-toolbar.z-toolbar-tabs {
  background-color: var(--zk-tabbox-toolbar-background-color);
  position: absolute;
  right: 0;
  top: 0;
  overflow: hidden;
  z-index: 1;
  min-height: var(--zk-toolbar-in-tabbox-min-height);
}
.z-caption .z-toolbar {
  background: none;
  border: 0;
}
.z-toolbar-content > * {
  margin-left: var(--zk-toolbar-buttons-spacing);
}
.z-toolbar-content > *:first-child {
  margin-left: 0;
}
.z-toolbar-vertical .z-toolbar-content > * {
  margin-left: 0;
  display: block;
}
.z-toolbar-panel {
  background-color: transparent;
}
.z-toolbar-panel .z-toolbar-horizontal,
.z-toolbar-panel .z-toolbar-vertical {
  border: 0;
  padding: 0;
}
.z-toolbar-panel .z-toolbar-horizontal {
  padding-left: var(--zk-toolbar-buttons-spacing);
}
.z-toolbar-panel .z-toolbar-vertical {
  padding-bottom: var(--zk-toolbar-buttons-spacing);
}
.z-toolbarbutton {
  display: inline-block;
  vertical-align: middle;
  position: relative;
  cursor: pointer;
  -webkit-border-radius: var(--zk-input-border-radius);
  -moz-border-radius: var(--zk-input-border-radius);
  -o-border-radius: var(--zk-input-border-radius);
  -ms-border-radius: var(--zk-input-border-radius);
  border-radius: var(--zk-input-border-radius);
  overflow: hidden;
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-toolbar-button-font-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-toolbar-button-color);
  border: var(--zk-button-border-width) solid transparent;
  background-color: var(--zk-toolbar-button-background-color);
  padding: var(--zk-toolbar-button-padding);
}
.z-toolbarbutton:before {
  content: '';
  height: 100%;
  display: inline-block;
  vertical-align: middle;
}
.z-toolbarbutton-content {
  display: inline-block;
  text-align: center;
  position: relative;
  white-space: nowrap;
  width: 100%;
}
.z-toolbarbutton-content > img {
  vertical-align: text-bottom;
}
.z-toolbarbutton:hover {
  color: var(--zk-button-hover-color);
  border-color: var(--zk-button-hover-border-color);
  background-color: var(--zk-button-hover-background-color);
}
.z-toolbarbutton:focus {
  border-color: var(--zk-button-focus-border-color);
}
.z-toolbarbutton:active {
  color: var(--zk-button-active-color);
  border-color: var(--zk-button-active-border-color);
  background-color: var(--zk-button-active-background-color);
}
.z-toolbarbutton[disabled] {
  color: var(--zk-button-disable-color) !important;
  border-color: var(--zk-button-disable-border-color);
  background-color: var(--zk-button-disable-background-color);
  cursor: default !important;
}
.z-toolbarbutton-checked {
  color: var(--zk-toolbar-button-checked-color);
  background-color: var(--zk-toolbar-button-checked-background-color);
}
