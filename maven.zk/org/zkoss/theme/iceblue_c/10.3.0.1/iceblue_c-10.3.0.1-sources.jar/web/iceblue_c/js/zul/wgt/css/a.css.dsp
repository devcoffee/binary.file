<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-a {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-font-size-medium);
  color: var(--zk-color-primary);
}
.z-a:hover {
  color: var(--zk-color-primary-dark);
}
.z-a:visited {
  color: var(--zk-color-primary-dark);
}
.z-a[disabled] {
  color: var(--zk-disabled-color);
  cursor: default;
  text-decoration: none;
}
.z-a[disabled]:hover,
.z-a[disabled]:visited {
  color: var(--zk-disabled-color);
}
