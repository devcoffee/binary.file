<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-signature {
  position: relative;
  border: 1px solid var(--zk-signature-border-color);
  border-radius: var(--zk-signature-border-radius);
}
.z-signature-toolbar {
  position: absolute;
  bottom: var(--zk-signature-toolbar-bottom);
  right: var(--zk-signature-toolbar-right);
}
.z-signature-toolbar-hide {
  display: none;
}
.z-signature-tool-button {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-input-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-button-color);
  min-height: var(--zk-base-button-height);
  border: var(--zk-button-border-width) solid var(--zk-button-border-color);
  -webkit-border-radius: var(--zk-input-border-radius);
  -moz-border-radius: var(--zk-input-border-radius);
  -o-border-radius: var(--zk-input-border-radius);
  -ms-border-radius: var(--zk-input-border-radius);
  border-radius: var(--zk-input-border-radius);
  padding: var(--zk-button-padding);
  line-height: normal;
  background-color: var(--zk-button-background-color);
  -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -o-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -ms-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  cursor: pointer;
  white-space: nowrap;
  margin-right: var(--zk-signature-toolbar-button-spacing);
}
.z-signature-tool-button:hover {
  color: var(--zk-button-hover-color);
  border-color: var(--zk-button-hover-border-color);
  background-color: var(--zk-button-hover-background-color);
}
.z-signature-tool-button:focus {
  color: var(--zk-button-focus-color);
  border-color: var(--zk-button-focus-border-color);
  background-color: var(--zk-button-focus-background-color);
}
.z-signature-tool-button:active {
  color: var(--zk-button-active-color);
  border-color: var(--zk-button-active-border-color);
  background-color: var(--zk-button-active-background-color);
}
.z-signature-tool-button-icon {
  display: inline-block;
  font-family: ZK85Icons, FontAwesome;
  font-style: normal;
  font-weight: normal;
  font-size: inherit;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: auto;
  font-size: var(--zk-signature-toolbar-button-icon-font-size);
  vertical-align: bottom;
}
.z-signature-tool-button-undo:before {
  content: "\f112";
}
.z-signature-tool-button-save:before {
  content: "\f0c7";
}
.z-signature-tool-button-clear:before {
  content: "\f00d";
}
.z-signature-tool-button-label:not(:empty) {
  margin-left: 4px;
}
.z-signature-canvas {
  width: 100%;
  height: 100%;
  border-radius: var(--zk-signature-border-radius);
  position: absolute;
  top: 0;
  left: 0;
}
