<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-multislider {
  white-space: nowrap;
  overflow: visible;
  cursor: pointer;
}
.z-multislider-inner {
  position: relative;
}
.z-multislider-track {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: var(--zk-multislider-track-color);
}
.z-multislider-marks {
  position: relative;
}
.z-multislider-mark {
  position: absolute;
}
.z-multislider-mark-label {
  position: absolute;
  font-family: var(--zk-base-title-font-family);
  color: var(--zk-text-color-default);
  text-align: center;
  font-size: var(--zk-rangeslider-label-font-size);
}
.z-multislider .z-sliderbuttons-button {
  width: var(--zk-multislider-button-size);
  height: var(--zk-multislider-button-size);
  border-width: var(--zk-multislider-button-border-width);
  background-color: var(--zk-multislider-button-color);
  border-color: var(--zk-multislider-button-color);
  border-radius: 50%;
  box-shadow: 0 0 4px 0 var(--zk-multislider-shadow-color);
  z-index: 2;
}
.z-multislider .z-sliderbuttons-tooltip {
  border-radius: var(--zk-multislider-border-radius);
  background: var(--zk-multislider-tooltip-background-color);
}
.z-multislider .z-sliderbuttons-area {
  background-color: var(--zk-multislider-button-color);
}
.z-multislider .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-area {
  background-color: var(--zk-multislider-button-color2);
}
.z-multislider .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-button {
  background-color: var(--zk-multislider-button-color2);
  border-color: var(--zk-multislider-button-color2);
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons-button:hover {
  border-color: var(--zk-multislider-button-hover-color);
  background-color: var(--zk-multislider-button-hover-color);
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons-button:hover .z-sliderbuttons-tooltip {
  display: block;
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons-button:active {
  border-color: var(--zk-multislider-button-active-color);
  background-color: var(--zk-multislider-button-active-color);
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons-button:focus {
  border-color: var(--zk-multislider-button-focus-border-color);
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-button:hover {
  border-color: var(--zk-multislider-button-hover-color2);
  background-color: var(--zk-multislider-button-hover-color2);
}
.z-multislider:not(.z-multislider-disabled) .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-button:active {
  border-color: var(--zk-multislider-button-active-color2);
  background-color: var(--zk-multislider-button-active-color2);
}
.z-multislider-horizontal {
  width: 300px;
}
.z-multislider-horizontal .z-sliderbuttons-area {
  height: 100%;
}
.z-multislider-horizontal .z-sliderbuttons-button {
  margin-top: var(--zk-rangeslider-horizontal-button-margin-top);
  margin-left: var(--zk-rangeslider-horizontal-button-margin-left);
  top: 0;
}
.z-multislider-horizontal .z-sliderbuttons-tooltip {
  top: var(--zk-rangeslider-horizontal-tooltip-position-top);
  left: 50%;
  transform: translateX(-50%) translateY(-100%);
  padding: var(--zk-rangeslider-horizontal-tooltip-padding);
}
.z-multislider-horizontal .z-multislider-inner {
  margin: 40px 12px 30px;
  height: var(--zk-multislider-inner-size);
}
.z-multislider-horizontal .z-multislider-marks {
  width: 100%;
}
.z-multislider-horizontal .z-multislider-mark-label {
  top: var(--zk-rangeslider-horizontal-mark-label-position-top);
  transform: translateX(-50%);
}
.z-multislider-vertical {
  height: 300px;
}
.z-multislider-vertical .z-sliderbuttons-area {
  width: 100%;
}
.z-multislider-vertical .z-sliderbuttons-button {
  margin-top: var(--zk-rangeslider-horizontal-button-margin-left);
  margin-left: var(--zk-rangeslider-horizontal-button-margin-top);
  left: 0;
}
.z-multislider-vertical .z-sliderbuttons-tooltip {
  left: var(--zk-rangeslider-vertical-tooltip-position-left);
  top: 50%;
  transform: translateY(-50%);
  padding: var(--zk-rangeslider-vertical-tooltip-padding);
}
.z-multislider-vertical .z-multislider-inner {
  margin: 12px 30px 12px 12px;
  width: var(--zk-multislider-inner-size);
  height: 100%;
}
.z-multislider-vertical .z-multislider-marks {
  height: 100%;
}
.z-multislider-vertical .z-multislider-mark-label {
  left: var(--zk-rangeslider-horizontal-mark-label-position-top);
  transform: translateY(-50%);
}
.z-multislider-disabled .z-multislider-track {
  background-color: var(--zk-multislider-disabled-track-color);
}
.z-multislider-disabled {
  cursor: default;
}
.z-multislider-disabled .z-sliderbuttons-area {
  background-color: var(--zk-multislider-disabled-button-color);
}
.z-multislider-disabled .z-sliderbuttons-button {
  border-color: var(--zk-multislider-disabled-button-color);
  background-color: var(--zk-multislider-disabled-button-color);
  box-shadow: none;
}
.z-multislider-disabled .z-sliderbuttons-tooltip {
  background-color: var(--zk-multislider-disabled-tooltip-background-color);
}
.z-multislider-disabled .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-area {
  background-color: var(--zk-multislider-disabled-button-color2);
}
.z-multislider-disabled .z-sliderbuttons:nth-last-of-type(2n-2) .z-sliderbuttons-button {
  border-color: var(--zk-multislider-disabled-button-color2);
  background-color: var(--zk-multislider-disabled-button-color2);
}
