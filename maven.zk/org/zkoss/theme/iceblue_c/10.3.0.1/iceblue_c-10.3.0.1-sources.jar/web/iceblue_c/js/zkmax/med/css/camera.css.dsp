<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-camera {
  display: none;
  position: relative;
}
.z-camera-real {
  width: 100%;
  height: 100%;
}
.z-camera-preview {
  display: inline-block;
}
.z-camera-recording,
.z-camera-stop,
.z-camera-pause {
  display: inline-block;
  font-family: ZK85Icons, FontAwesome;
  font-style: normal;
  font-weight: normal;
  font-size: inherit;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: auto;
  font-size: 36px;
  position: absolute;
  top: 12px;
  right: 12px;
}
.z-camera-recording:before {
  content: '\f03d';
  color: #D0021B;
}
.z-camera-stop:before {
  content: '\f04d';
  color: #FFFFFF;
}
.z-camera-pause:before {
  content: '\f04c';
  color: #FFFFFF;
}
