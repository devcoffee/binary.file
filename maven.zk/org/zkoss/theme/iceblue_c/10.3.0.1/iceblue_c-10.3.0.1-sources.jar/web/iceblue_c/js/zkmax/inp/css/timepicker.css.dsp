<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-timepicker {
  display: inline-block;
  min-height: var(--zk-timepicker-height);
  white-space: nowrap;
}
.z-timepicker-input {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-input-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-input-color);
  width: 100%;
  height: var(--zk-timepicker-height);
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  margin: 0;
  padding: var(--zk-input-padding);
  padding-right: var(--zk-timepicker-padding-right);
  line-height: var(--zk-timepicker-line-height);
  background: var(--zk-input-background-color);
}
.z-timepicker-input::-webkit-input-placeholder {
  color: var(--zk-input-placeholder-color);
}
.z-timepicker-input:-moz-placeholder {
  /* FF 4-18 */
  color: var(--zk-input-placeholder-color);
  opacity: 1;
}
.z-timepicker-input::-moz-placeholder {
  /* FF 19+ */
  color: var(--zk-input-placeholder-color);
  opacity: 1;
}
.z-timepicker-input:-ms-input-placeholder {
  /* IE 10+ */
  color: var(--zk-input-placeholder-color);
}
.z-timepicker-input.z-timepicker-hover,
.z-timepicker-input.z-timepicker-hover + .z-timepicker-button {
  border-color: var(--zk-input-hover-border-color);
}
.z-timepicker-input:focus {
  border: 1px solid var(--zk-input-focus-border-color);
}
.z-timepicker-input:focus + .z-timepicker-button {
  border-left: 1px solid var(--zk-input-focus-border-color);
}
.z-timepicker-input-full {
  padding-right: var(--zk-input-padding-right);
}
.z-timepicker-button {
  font-size: var(--zk-combo-button-icon-size-large);
  color: var(--zk-combo-button-icon-color);
  display: inline-block;
  position: relative;
  top: 0;
  right: var(--zk-timepicker-button-width);
  min-width: var(--zk-timepicker-button-width);
  height: var(--zk-timepicker-height);
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -moz-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -o-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -ms-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  padding: var(--zk-timepicker-button-padding);
  line-height: var(--zk-base-line-height);
  background: var(--zk-input-background-color);
  text-align: center;
  vertical-align: middle;
  overflow: hidden;
  cursor: pointer;
}
.z-timepicker-button:hover {
  border-color: var(--zk-combo-button-hover-border-color);
  background: var(--zk-combo-button-hover-background-color);
}
.z-timepicker-button:active {
  color: var(--zk-combo-button-active-icon-color);
  border-color: var(--zk-combo-button-active-border-color);
  background-color: var(--zk-combo-button-active-background-color);
}
.z-timepicker-button[readonly] {
  cursor: pointer;
}
.z-timepicker-disabled .z-timepicker-input,
.z-timepicker-disabled .z-timepicker-button {
  color: var(--zk-input-disable-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
}
.z-timepicker-disabled .z-timepicker-button:hover {
  border-color: var(--zk-input-border-color);
}
.z-timepicker-readonly > input {
  color: var(--zk-input-readonly-color);
  background: var(--zk-input-readonly-background-color);
}
.z-timepicker-readonly > a {
  color: var(--zk-input-readonly-color);
  background-color: var(--zk-input-background-color);
}
.z-timepicker-invalid {
  border: 1px solid var(--zk-invalid-border-color) !important;
  margin-right: -1px;
}
.z-timepicker-button.z-timepicker-disabled {
  display: none;
}
.z-timepicker-inplace .z-timepicker-input {
  border: 0;
  padding: 3px;
  background: none;
}
.z-timepicker-inplace .z-timepicker-button {
  visibility: hidden;
}
.z-timepicker-option {
  font-size: var(--zk-combo-popup-item-size);
  white-space: nowrap;
  cursor: pointer;
  display: block;
  padding: var(--zk-timepicker-popup-padding);
  position: relative;
  min-height: 20px;
  font-weight: normal;
  color: var(--zk-combo-popup-item-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-timepicker-option:hover {
  background-color: var(--zk-combo-popup-item-hover-background-color);
}
.z-timepicker-option-selected {
  color: var(--zk-combo-popup-item-selected-color);
  line-height: calc(var(--zk-combo-popup-item-size) + 2px);
}
.z-timepicker-popup {
  max-height: 200px;
  font-family: var(--zk-base-content-font-family);
  font-weight: normal;
  font-size: var(--zk-font-size-medium);
  display: block;
  border: 1px solid var(--zk-combo-popup-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-timepicker-popup-padding);
  background: var(--zk-popup-background-color);
  position: absolute;
  overflow: auto;
}
.z-timepicker-content {
  border: 0;
  padding: 0;
  margin: 0;
  background: transparent none repeat 0 0;
  position: relative;
  list-style: none outside none;
}
.z-timepicker-shadow {
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
}
