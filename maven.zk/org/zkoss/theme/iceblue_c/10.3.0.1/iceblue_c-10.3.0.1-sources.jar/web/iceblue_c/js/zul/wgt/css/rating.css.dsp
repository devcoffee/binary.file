<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-rating {
  display: inline-block;
  margin: 0;
  padding: 0;
  font-size: var(--zk-rating-icon-font-size);
  line-height: normal;
}
.z-rating > .z-rating-icon {
  text-align: center;
  color: var(--zk-rating-icon);
  padding: var(--zk-rating-icon-padding);
  width: var(--zk-rating-icon-size);
  height: var(--zk-rating-icon-size);
  text-decoration: none;
}
.z-rating-vertical > .z-rating-icon {
  display: block;
}
.z-rating > .z-rating-selected {
  color: var(--zk-rating-icon-selected);
}
.z-rating > .z-rating-hover {
  color: var(--zk-rating-icon-hover);
  text-shadow: 0 0 1px var(--zk-rating-icon-hover-text-shadow);
}
.z-rating > .z-rating-disabled {
  opacity: 0.5;
  cursor: default;
}
.z-rating > .z-rating-readonly {
  cursor: default;
}
