<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-grid {
  background: var(--zk-mask-background-color);
  border: 1px solid var(--zk-base-border-color);
  overflow: hidden;
  zoom: 1;
}
.z-grid-header {
  width: 100%;
  position: relative;
  overflow: hidden;
}
.z-grid-header table {
  border-spacing: 0;
}
.z-grid-header table th,
.z-grid-header table td {
  background-clip: padding-box;
  padding: 0;
}
.z-grid-header table th {
  text-align: inherit;
}
.z-grid-body {
  margin-top: auto;
  position: relative;
  overflow: hidden;
  overflow-anchor: none;
}
.z-grid-body table {
  border-spacing: 0;
}
.z-grid-body table th,
.z-grid-body table td {
  background-clip: padding-box;
  padding: 0;
}
.z-grid-body table th {
  text-align: inherit;
}
.z-grid-body .z-grid-emptybody td {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-disabled-color);
  text-align: left;
  height: 1px;
}
.z-grid-body .z-grid-emptybody .z-grid-emptybody-content {
  background: var(--zk-mesh-background-color);
  padding: var(--zk-mesh-empty-body-padding);
}
.z-grid-footer {
  overflow: hidden;
  white-space: nowrap;
}
.z-grid-footer table {
  border-spacing: 0;
}
.z-grid-footer table th,
.z-grid-footer table td {
  background-clip: padding-box;
  padding: 0;
}
.z-grid-footer table th {
  text-align: inherit;
}
.z-grid-footer .z-footer {
  overflow: hidden;
  background: var(--zk-mesh-foot-background-color);
  border-top: 1px solid var(--zk-base-border-color);
}
.z-grid-footer .z-foot-bar {
  background: var(--zk-mesh-foot-background-color);
}
.z-grid .z-row-inner,
.z-grid .z-cell {
  background: var(--zk-mesh-background-color);
}
.z-grid .z-cell:focus-visible,
.z-grid .z-row .z-row-inner:focus-visible {
  box-shadow: var(--zk-mesh-cell-focus-box-shadow);
  transition: unset;
}
.z-grid-odd > .z-row-inner,
.z-grid-odd > .z-cell {
  background: var(--zk-mesh-stripe-background-color);
}
.z-grid-loading {
  background: transparent no-repeat center;
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/progress-72.gif")});
}
.z-columns th:first-child {
  border-left: none;
}
.z-columns th:first-child.z-columns-border {
  border-left: 1px solid var(--zk-mesh-title-border-color);
}
.z-columns-bar {
  background: var(--zk-mesh-title-background-color);
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
}
.z-column-content,
.z-row-content,
.z-group-content,
.z-groupfoot-content,
.z-footer-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  line-height: var(--zk-mesh-content-line-height);
  overflow: hidden;
  padding: var(--zk-mesh-body-padding);
}
.z-column-content {
  color: var(--zk-mesh-title-color);
}
.z-footer-content {
  color: var(--zk-text-color-light);
}
.z-group-content {
  color: var(--zk-mesh-group-color);
}
.z-groupfoot-content {
  color: var(--zk-mesh-group-footer-color);
  padding: var(--zk-mesh-body-padding);
}
.z-group-open .z-groupfoot-content {
  color: var(--zk-mesh-group-footer-open-color);
}
.z-columns-menupopup .z-column-content {
  padding-right: 34px;
  text-overflow: ellipsis;
}
.z-column {
  background: var(--zk-mesh-title-background-color);
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
  padding: 0;
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}
.z-column:focus-visible {
  box-shadow: var(--zk-mesh-title-focus-box-shadow);
  transition: unset;
}
.z-column-button {
  font-size: var(--zk-font-size-large);
  color: var(--zk-mesh-title-color);
  display: none;
  width: var(--zk-mesh-column-sort-button-width);
  height: var(--zk-mesh-column-sort-button-height);
  line-height: var(--zk-mesh-column-sort-button-height);
  text-align: center;
  position: absolute;
  top: 0;
  right: 0;
  z-index: 15;
  cursor: pointer;
  text-decoration: none;
  -webkit-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -moz-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -o-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -ms-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
}
.z-column-hover {
  background: var(--zk-mesh-title-hover-background-color);
}
.z-column-hover .z-column-button {
  display: block;
}
.z-column-hover .z-column-content {
  color: var(--zk-mesh-title-hover-color);
}
.z-column-visited {
  background: var(--zk-mesh-title-background-color);
}
.z-column-visited .z-column-button {
  background: var(--zk-mesh-title-active-background-color);
}
.z-column-visited .z-column-content {
  color: var(--zk-mesh-title-active-color);
}
.z-column-sort .z-column-content {
  cursor: pointer;
}
.z-column-sort .z-column-content:active {
  background: var(--zk-mesh-title-active-background-color);
  color: var(--zk-mesh-title-color);
}
.z-column-sort .z-column-sorticon {
  font-size: var(--zk-font-size-large);
  color: var(--zk-mesh-title-color);
  position: absolute;
  top: var(--zk-mesh-column-sort-icon-top);
  left: 50%;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  transform: translateX(-50%);
}
.z-column-sort .z-column-sorticon :active {
  background: rgba(0, 0, 0, 0);
}
.z-column-sizing,
.z-column-sizing .z-column-button,
.z-column-sizing.z-column-sort .z-column-content {
  cursor: col-resize;
}
.z-grid-autopaging .z-row-content,
.z-grid-autopaging .z-groupfoot-content {
  height: var(--zk-mesh-auto-paging-row-height);
  padding: var(--zk-mesh-auto-paging-row-padding);
  line-height: var(--zk-mesh-auto-paging-row-line-height);
  overflow: hidden;
}
.z-grid-autopaging .z-group-content {
  height: var(--zk-mesh-auto-paging-row-height);
  padding: var(--zk-mesh-auto-paging-row-padding);
  line-height: var(--zk-mesh-auto-paging-row-line-height);
  overflow: hidden;
}
.z-group-inner {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  border-bottom: 1px solid var(--zk-mesh-group-border-color);
  background: var(--zk-mesh-group-background-color);
  position: relative;
  overflow: hidden;
}
.z-group-inner .z-group-content,
.z-group-inner .z-cell {
  padding: var(--zk-mesh-body-padding);
}
.z-group-icon {
  font-size: var(--zk-font-size-medium);
  color: var(--zk-mesh-group-color);
  display: inline-block;
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  line-height: var(--zk-base-icon-height);
  text-align: center;
  position: relative;
  cursor: pointer;
  margin-right: 8px;
}
.z-group.z-group-open .z-group-inner {
  background: var(--zk-mesh-group-open-background-color);
  border-bottom: var(--zk-mesh-group-open-border);
}
.z-group.z-group-open .z-group-inner .z-group-icon,
.z-group.z-group-open .z-group-inner .z-group-content {
  color: var(--zk-mesh-group-open-color);
}
.z-groupfoot-inner {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  background: var(--zk-mesh-group-footer-background-color);
  overflow: hidden;
}
.z-grid-body .z-cell {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  color: var(--zk-base-text-color);
  padding: var(--zk-mesh-body-padding);
  line-height: var(--zk-base-button-height);
  overflow: hidden;
}
.z-row .z-row-inner,
.z-row .z-cell {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  overflow: hidden;
  position: relative;
  z-index: 0;
}
.z-row:hover > .z-row-inner,
.z-row:hover > .z-cell {
  background: var(--zk-hover-background-color);
}
.z-row:hover > .z-row-inner > .z-row-content {
  color: var(--zk-hover-color);
}
.z-grid-paging-top {
  width: 100%;
  border-bottom: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
}
.z-grid-paging-bottom {
  width: 100%;
  border-top: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
}
.z-columns-menugrouping .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-group.png")});
}
.z-columns-menuungrouping .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-ungroup.png")});
}
.z-columns-menuascending .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-arrowup.png")});
}
.z-columns-menudescending .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-arrowdown.png")});
}
.z-cell-hidden-column,
.z-row-hidden-column {
  white-space: nowrap;
  overflow: hidden;
}
