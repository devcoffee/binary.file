<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-inputgroup {
  display: -ms-inline-flexbox;
  display: inline-flex;
}
.z-inputgroup-text {
  display: -ms-flexbox;
  display: flex;
  background: var(--zk-inputgroup-text-background-color);
  border: 1px solid var(--zk-input-border-color);
  padding: 0 12px;
  min-height: var(--zk-input-height);
  -ms-flex-align: center;
  align-items: center;
}
.z-inputgroup > :nth-child(n) {
  border-radius: 0;
}
.z-inputgroup-vertical {
  -ms-flex-direction: column;
  flex-direction: column;
}
.z-inputgroup-vertical > :first-child {
  border-top-left-radius: var(--zk-input-border-radius);
  border-top-right-radius: var(--zk-input-border-radius);
}
.z-inputgroup-vertical > :last-child {
  border-bottom-left-radius: var(--zk-input-border-radius);
  border-bottom-right-radius: var(--zk-input-border-radius);
}
.z-inputgroup:not(.z-inputgroup-vertical) > :nth-child(n) {
  height: auto;
}
.z-inputgroup:not(.z-inputgroup-vertical) > :first-child {
  border-top-left-radius: var(--zk-input-border-radius);
  border-bottom-left-radius: var(--zk-input-border-radius);
}
.z-inputgroup:not(.z-inputgroup-vertical) > :last-child {
  border-top-right-radius: var(--zk-input-border-radius);
  border-bottom-right-radius: var(--zk-input-border-radius);
}
