<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
/*!
 * Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
 * Copyright 2023 Fonticons, Inc.
 */
/* FONT PATH
 * -------------------------- */
@font-face {
  font-family: 'ZK85Icons';
  src: url(${c:encodeURL("~./zul/less/font/ZK85Icons.eot?v=4.7.0")});
  src: url(${c:encodeURL("~./zul/less/font/ZK85Icons.eot?#iefix&v=4.7.0")}) format("embedded-opentype"),
    url(${c:encodeURL("~./zul/less/font/ZK85Icons.woff?v=4.7.0")}) format("woff"),
    url(${c:encodeURL("~./zul/less/font/ZK85Icons.ttf?v=4.7.0")}) format("truetype"),
    url(${c:encodeURL("~./zul/less/font/ZK85Icons.svg?v=4.7.0#ZK85Icons")}) format("svg");
  font-weight: normal;
  font-style: normal;
}
/*!
 * Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
 * Copyright 2023 Fonticons, Inc.
 */
@font-face {
  font-family: 'FontAwesome';
  font-style: normal;
  font-weight: 900;
  font-display: block;
  src: url(${c:encodeURL("~./zul/less/font/fa-solid-900.woff2")}) format("woff2"),
  url(${c:encodeURL("~./zul/less/font/fa-solid-900.ttf")}) format("truetype"),
  url(${c:encodeURL("~./zul/less/font/solid.svg")}) format("svg");
}
@font-face {
  font-family: 'FontAwesome';
  font-style: normal;
  font-weight: 400;
  font-display: block;
  src: url(${c:encodeURL("~./zul/less/font/fa-regular-400.woff2")}) format("woff2"),
  url(${c:encodeURL("~./zul/less/font/fa-regular-400.ttf")}) format("truetype"),
  url(${c:encodeURL("~./zul/less/font/regular.svg")}) format("svg");
}
@font-face {
  font-family: 'FontAwesome';
  font-style: normal;
  font-weight: 400;
  font-display: block;
  src: url(${c:encodeURL("~./zul/less/font/fa-brands-400.woff2")}) format("woff2"),
  url(${c:encodeURL("~./zul/less/font/fa-brands-400.ttf")}) format("truetype"),
  url(${c:encodeURL("~./zul/less/font/brands.svg")}) format("svg");
}
.z-icon {
  font-family: var(--z-icon-style-family, 'FontAwesome');
  font-weight: var(--z-icon-style, 900);
}
[class*="z-icon"],
.fas,
.z-icon-solid,
.fass,
.z-icon-sharp,
.far,
.z-icon-regular,
.fab,
.z-icon-brands {
  display: inline-block;
  font: normal normal normal 14px/1 FontAwesome;
  font-size: inherit;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.fas,
.z-icon-classic,
.z-icon-solid,
.far,
.z-icon-regular,
.fab,
.z-icon-brands {
  font-family: FontAwesome;
}
.z-icon-1x {
  font-size: 1em;
}
.z-icon-2x {
  font-size: 2em;
}
.z-icon-3x {
  font-size: 3em;
}
.z-icon-4x {
  font-size: 4em;
}
.z-icon-5x {
  font-size: 5em;
}
.z-icon-6x {
  font-size: 6em;
}
.z-icon-7x {
  font-size: 7em;
}
.z-icon-8x {
  font-size: 8em;
}
.z-icon-9x {
  font-size: 9em;
}
.z-icon-10x {
  font-size: 10em;
}
.z-icon-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}
.z-icon-xs {
  font-size: 0.75em;
  line-height: 0.08333333em;
  vertical-align: 0.125em;
}
.z-icon-sm {
  font-size: 0.875em;
  line-height: 0.07142857em;
  vertical-align: 0.05357143em;
}
.z-icon-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}
.z-icon-xl {
  font-size: 1.5em;
  line-height: 0.04166667em;
  vertical-align: -0.125em;
}
.z-icon-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}
.z-icon-fw {
  text-align: center;
  width: 1.25em;
}
.z-icon-ul {
  list-style-type: none;
  margin-left: var(--z-icon-li-margin, 2.5em);
  padding-left: 0;
}
.z-icon-ul > li {
  position: relative;
}
.z-icon-li {
  left: calc(var(--z-icon-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--z-icon-li-width, 2em);
  line-height: inherit;
}
.z-icon-border {
  border-color: var(--z-icon-border-color, #eee);
  border-radius: var(--z-icon-border-radius, 0.1em);
  border-style: var(--z-icon-border-style, solid);
  border-width: var(--z-icon-border-width, 0.08em);
  padding: var(--z-icon-border-padding, 0.2em 0.25em 0.15em);
}
.z-icon-pull-left {
  float: left;
  margin-right: var(--z-icon-pull-margin, 0.3em);
}
.z-icon-pull-right {
  float: right;
  margin-left: var(--z-icon-pull-margin, 0.3em);
}
.z-icon-beat {
  animation-name: z-icon-beat;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, ease-in-out);
}
.z-icon-bounce {
  animation-name: z-icon-beat;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, cubic-bezier(0.280, 0.840, 0.420, 1));
}
.z-icon-fade {
  animation-name: z-icon-fade;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, cubic-bezier(.4,0,.6,1));
}
.z-icon-beat-fade {
  animation-name: z-icon-beat-fade;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, cubic-bezier(.4,0,.6,1));
}
.z-icon-flip {
  animation-name: z-icon-flip;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, ease-in-out);
}
.z-icon-shake {
  animation-name: z-icon-shake;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, ease-in-out);
}
.z-icon-spin {
  animation-name: z-icon-spin;
  animation-delay: var(--z-icon-animation-delay, 0s);
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 2s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, linear);
}
.z-icon-spin-reverse {
  --z-icon-animation-direction: reverse;
}
.z-icon-pulse,
.z-icon-spin-pulse {
  animation-name: z-icon-spin;
  animation-direction: var(--z-icon-animation-direction, normal);
  animation-duration: var(--z-icon-animation-duration, 1s);
  animation-iteration-count: var(--z-icon-animation-iteration-count, infinite);
  animation-timing-function: var(--z-icon-animation-timing, steps(8));;
}
@media (prefers-reduced-motion: reduce) {
  .z-icon-beat,
  .z-icon-bounce,
  .z-icon-fade,
  .z-icon-beat-fade,
  .z-icon-flip,
  .z-icon-pulse,
  .z-icon-shake,
  .z-icon-spin,
  .z-icon-spin-pulse {
    animation-delay: -1ms;
    animation-duration: 1ms;
    animation-iteration-count: 1;
    transition-delay: 0s;
    transition-duration: 0s;
  }
}
@keyframes z-icon-beat {
  0%,
  90% {
    transform: scale(1);
  }
  45% {
    transform: scale(var(--z-icon-beat-scale, 1.25));
  }
}
@keyframes z-icon-bounce {
  0% {
    transform: scale(1, 1) translateY(0);
  }
  10% {
    transform: scale(var(--z-icon-bounce-start-scale-x, 1.1),var(--z-icon-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    transform: scale(var(--z-icon-bounce-jump-scale-x, 0.9),var(--z-icon-bounce-jump-scale-y, 1.1)) translateY(var(--z-icon-bounce-height, -0.5em));
  }
  50% {
    transform: scale(var(--z-icon-bounce-land-scale-x, 1.05),var(--z-icon-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    transform: scale(1,1) translateY(var(--z-icon-bounce-rebound, -0.125em));
  }
  64% {
    transform: scale(1, 1) translateY(0);
  }
  100% {
    transform: scale(1, 1) translateY(0);
  }
}
@keyframes z-icon-fade {
  50% {
    opacity: var(--z-icon-fade-opacity, 0.4);
  }
}
@keyframes z-icon-beat-fade {
  0%,
  100% {
    opacity: var(--z-icon-beat-fade-opacity, 0.4);
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(var(--z-icon-beat-fade-scale, 1.125));
  }
}
@keyframes z-icon-flip {
  50% {
    transform: rotate3d(var(--z-icon-flip-x, 0), var(--z-icon-flip-y, 1), var(--z-icon-flip-z, 0), var(--z-icon-flip-angle, -180deg));
  }
}
@keyframes z-icon-shake {
  0% {
    transform: rotate(-15deg);
  }
  4% {
    transform: rotate(15deg);
  }
  8%,
  24% {
    transform: rotate(-18deg);
  }
  12%,
  28% {
    transform: rotate(18deg);
  }
  16% {
    transform: rotate(-22deg);
  }
  20% {
    transform: rotate(22deg);
  }
  32% {
    transform: rotate(-12deg);
  }
  36% {
    transform: rotate(12deg);
  }
  40%,
  100% {
    transform: rotate(0deg);
  }
}
@keyframes z-icon-spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.z-icon-rotate-90 {
  transform: rotate(90deg);
}
.z-icon-rotate-180 {
  transform: rotate(180deg);
}
.z-icon-rotate-270 {
  transform: rotate(270deg);
}
.z-icon-flip-horizontal {
  transform: scale(-1, 1);
}
.z-icon-flip-vertical {
  transform: scale(1, -1);
}
.z-icon-flip-both,
.z-icon-flip-horizontal.z-icon-flip-vertical {
  transform: scale(-1, -1);
}
.z-icon-rotate-by {
  transform: rotate(var(--z-icon-rotate-angle, none));
}
.z-icon-stack {
  display: inline-block;
  height: 2em;
  line-height: 2em;
  position: relative;
  vertical-align: middle;
  width: 2.5em;
}
.z-icon-stack-1x,
.z-icon-stack-2x {
  left: 0;
  position: absolute;
  text-align: center;
  width: 100%;
  z-index: var(--z-icon-stack-z-index, auto);
}
.z-icon-stack-1x {
  line-height: inherit;
}
.z-icon-stack-2x {
  font-size: 2em;
}
.z-icon-inverse {
  color: var(--z-icon-inverse, #fff);
}
/* Font Awesome uses the Unicode Private Use Area (PUA) to ensure screen
   readers do not read off random characters that represent icons */
.z-icon-0::before {
  content: "\30";
}
.z-icon-1::before {
  content: "\31";
}
.z-icon-2::before {
  content: "\32";
}
.z-icon-3::before {
  content: "\33";
}
.z-icon-4::before {
  content: "\34";
}
.z-icon-5::before {
  content: "\35";
}
.z-icon-6::before {
  content: "\36";
}
.z-icon-7::before {
  content: "\37";
}
.z-icon-8::before {
  content: "\38";
}
.z-icon-9::before {
  content: "\39";
}
.z-icon-fill-drip::before {
  content: "\f576";
}
.z-icon-arrows-to-circle::before {
  content: "\e4bd";
}
.z-icon-circle-chevron-right::before {
  content: "\f138";
}
.z-icon-chevron-circle-right::before {
  content: "\f138";
}
.z-icon-at::before {
  content: "\40";
}
.z-icon-trash-can::before {
  content: "\f2ed";
}
.z-icon-trash-alt::before {
  content: "\f2ed";
}
.z-icon-text-height::before {
  content: "\f034";
}
.z-icon-user-xmark::before {
  content: "\f235";
}
.z-icon-user-times::before {
  content: "\f235";
}
.z-icon-stethoscope::before {
  content: "\f0f1";
}
.z-icon-message::before {
  content: "\f27a";
}
.z-icon-comment-alt::before {
  content: "\f27a";
}
.z-icon-info::before {
  content: "\f129";
}
.z-icon-down-left-and-up-right-to-center::before {
  content: "\f422";
}
.z-icon-compress-alt::before {
  content: "\f422";
}
.z-icon-explosion::before {
  content: "\e4e9";
}
.z-icon-file-lines::before {
  content: "\f15c";
}
.z-icon-file-alt::before {
  content: "\f15c";
}
.z-icon-file-text::before {
  content: "\f15c";
}
.z-icon-wave-square::before {
  content: "\f83e";
}
.z-icon-ring::before {
  content: "\f70b";
}
.z-icon-building-un::before {
  content: "\e4d9";
}
.z-icon-dice-three::before {
  content: "\f527";
}
.z-icon-calendar-days::before {
  content: "\f073";
}
.z-icon-calendar-alt::before {
  content: "\f073";
}
.z-icon-anchor-circle-check::before {
  content: "\e4aa";
}
.z-icon-building-circle-arrow-right::before {
  content: "\e4d1";
}
.z-icon-volleyball::before {
  content: "\f45f";
}
.z-icon-volleyball-ball::before {
  content: "\f45f";
}
.z-icon-arrows-up-to-line::before {
  content: "\e4c2";
}
.z-icon-sort-down::before {
  content: "\f0dd";
}
.z-icon-sort-desc::before {
  content: "\f0dd";
}
.z-icon-circle-minus::before {
  content: "\f056";
}
.z-icon-minus-circle::before {
  content: "\f056";
}
.z-icon-door-open::before {
  content: "\f52b";
}
.z-icon-right-from-bracket::before {
  content: "\f2f5";
}
.z-icon-sign-out-alt::before {
  content: "\f2f5";
}
.z-icon-atom::before {
  content: "\f5d2";
}
.z-icon-soap::before {
  content: "\e06e";
}
.z-icon-icons::before {
  content: "\f86d";
}
.z-icon-heart-music-camera-bolt::before {
  content: "\f86d";
}
.z-icon-microphone-lines-slash::before {
  content: "\f539";
}
.z-icon-microphone-alt-slash::before {
  content: "\f539";
}
.z-icon-bridge-circle-check::before {
  content: "\e4c9";
}
.z-icon-pump-medical::before {
  content: "\e06a";
}
.z-icon-fingerprint::before {
  content: "\f577";
}
.z-icon-hand-point-right::before {
  content: "\f0a4";
}
.z-icon-magnifying-glass-location::before {
  content: "\f689";
}
.z-icon-search-location::before {
  content: "\f689";
}
.z-icon-forward-step::before {
  content: "\f051";
}
.z-icon-step-forward::before {
  content: "\f051";
}
.z-icon-face-smile-beam::before {
  content: "\f5b8";
}
.z-icon-smile-beam::before {
  content: "\f5b8";
}
.z-icon-flag-checkered::before {
  content: "\f11e";
}
.z-icon-football::before {
  content: "\f44e";
}
.z-icon-football-ball::before {
  content: "\f44e";
}
.z-icon-school-circle-exclamation::before {
  content: "\e56c";
}
.z-icon-crop::before {
  content: "\f125";
}
.z-icon-angles-down::before {
  content: "\f103";
}
.z-icon-angle-double-down::before {
  content: "\f103";
}
.z-icon-users-rectangle::before {
  content: "\e594";
}
.z-icon-people-roof::before {
  content: "\e537";
}
.z-icon-people-line::before {
  content: "\e534";
}
.z-icon-beer-mug-empty::before {
  content: "\f0fc";
}
.z-icon-beer::before {
  content: "\f0fc";
}
.z-icon-diagram-predecessor::before {
  content: "\e477";
}
.z-icon-arrow-up-long::before {
  content: "\f176";
}
.z-icon-long-arrow-up::before {
  content: "\f176";
}
.z-icon-fire-flame-simple::before {
  content: "\f46a";
}
.z-icon-burn::before {
  content: "\f46a";
}
.z-icon-person::before {
  content: "\f183";
}
.z-icon-male::before {
  content: "\f183";
}
.z-icon-laptop::before {
  content: "\f109";
}
.z-icon-file-csv::before {
  content: "\f6dd";
}
.z-icon-menorah::before {
  content: "\f676";
}
.z-icon-truck-plane::before {
  content: "\e58f";
}
.z-icon-record-vinyl::before {
  content: "\f8d9";
}
.z-icon-face-grin-stars::before {
  content: "\f587";
}
.z-icon-grin-stars::before {
  content: "\f587";
}
.z-icon-bong::before {
  content: "\f55c";
}
.z-icon-spaghetti-monster-flying::before {
  content: "\f67b";
}
.z-icon-pastafarianism::before {
  content: "\f67b";
}
.z-icon-arrow-down-up-across-line::before {
  content: "\e4af";
}
.z-icon-spoon::before {
  content: "\f2e5";
}
.z-icon-utensil-spoon::before {
  content: "\f2e5";
}
.z-icon-jar-wheat::before {
  content: "\e517";
}
.z-icon-envelopes-bulk::before {
  content: "\f674";
}
.z-icon-mail-bulk::before {
  content: "\f674";
}
.z-icon-file-circle-exclamation::before {
  content: "\e4eb";
}
.z-icon-circle-h::before {
  content: "\f47e";
}
.z-icon-hospital-symbol::before {
  content: "\f47e";
}
.z-icon-pager::before {
  content: "\f815";
}
.z-icon-address-book::before {
  content: "\f2b9";
}
.z-icon-contact-book::before {
  content: "\f2b9";
}
.z-icon-strikethrough::before {
  content: "\f0cc";
}
.z-icon-k::before {
  content: "\4b";
}
.z-icon-landmark-flag::before {
  content: "\e51c";
}
.z-icon-pencil::before {
  content: "\f303";
}
.z-icon-pencil-alt::before {
  content: "\f303";
}
.z-icon-backward::before {
  content: "\f04a";
}
.z-icon-caret-right::before {
  content: "\f0da";
}
.z-icon-comments::before {
  content: "\f086";
}
.z-icon-paste::before {
  content: "\f0ea";
}
.z-icon-file-clipboard::before {
  content: "\f0ea";
}
.z-icon-code-pull-request::before {
  content: "\e13c";
}
.z-icon-clipboard-list::before {
  content: "\f46d";
}
.z-icon-truck-ramp-box::before {
  content: "\f4de";
}
.z-icon-truck-loading::before {
  content: "\f4de";
}
.z-icon-user-check::before {
  content: "\f4fc";
}
.z-icon-vial-virus::before {
  content: "\e597";
}
.z-icon-sheet-plastic::before {
  content: "\e571";
}
.z-icon-blog::before {
  content: "\f781";
}
.z-icon-user-ninja::before {
  content: "\f504";
}
.z-icon-person-arrow-up-from-line::before {
  content: "\e539";
}
.z-icon-scroll-torah::before {
  content: "\f6a0";
}
.z-icon-torah::before {
  content: "\f6a0";
}
.z-icon-broom-ball::before {
  content: "\f458";
}
.z-icon-quidditch::before {
  content: "\f458";
}
.z-icon-quidditch-broom-ball::before {
  content: "\f458";
}
.z-icon-toggle-off::before {
  content: "\f204";
}
.z-icon-box-archive::before {
  content: "\f187";
}
.z-icon-archive::before {
  content: "\f187";
}
.z-icon-person-drowning::before {
  content: "\e545";
}
.z-icon-arrow-down-9-1::before {
  content: "\f886";
}
.z-icon-sort-numeric-desc::before {
  content: "\f886";
}
.z-icon-sort-numeric-down-alt::before {
  content: "\f886";
}
.z-icon-face-grin-tongue-squint::before {
  content: "\f58a";
}
.z-icon-grin-tongue-squint::before {
  content: "\f58a";
}
.z-icon-spray-can::before {
  content: "\f5bd";
}
.z-icon-truck-monster::before {
  content: "\f63b";
}
.z-icon-w::before {
  content: "\57";
}
.z-icon-earth-africa::before {
  content: "\f57c";
}
.z-icon-globe-africa::before {
  content: "\f57c";
}
.z-icon-rainbow::before {
  content: "\f75b";
}
.z-icon-circle-notch::before {
  content: "\f1ce";
}
.z-icon-tablet-screen-button::before {
  content: "\f3fa";
}
.z-icon-tablet-alt::before {
  content: "\f3fa";
}
.z-icon-paw::before {
  content: "\f1b0";
}
.z-icon-cloud::before {
  content: "\f0c2";
}
.z-icon-trowel-bricks::before {
  content: "\e58a";
}
.z-icon-face-flushed::before {
  content: "\f579";
}
.z-icon-flushed::before {
  content: "\f579";
}
.z-icon-hospital-user::before {
  content: "\f80d";
}
.z-icon-tent-arrow-left-right::before {
  content: "\e57f";
}
.z-icon-gavel::before {
  content: "\f0e3";
}
.z-icon-legal::before {
  content: "\f0e3";
}
.z-icon-binoculars::before {
  content: "\f1e5";
}
.z-icon-microphone-slash::before {
  content: "\f131";
}
.z-icon-box-tissue::before {
  content: "\e05b";
}
.z-icon-motorcycle::before {
  content: "\f21c";
}
.z-icon-bell-concierge::before {
  content: "\f562";
}
.z-icon-concierge-bell::before {
  content: "\f562";
}
.z-icon-pen-ruler::before {
  content: "\f5ae";
}
.z-icon-pencil-ruler::before {
  content: "\f5ae";
}
.z-icon-people-arrows::before {
  content: "\e068";
}
.z-icon-people-arrows-left-right::before {
  content: "\e068";
}
.z-icon-mars-and-venus-burst::before {
  content: "\e523";
}
.z-icon-square-caret-right::before {
  content: "\f152";
}
.z-icon-caret-square-right::before {
  content: "\f152";
}
.z-icon-scissors::before {
  content: "\f0c4";
}
.z-icon-cut::before {
  content: "\f0c4";
}
.z-icon-sun-plant-wilt::before {
  content: "\e57a";
}
.z-icon-toilets-portable::before {
  content: "\e584";
}
.z-icon-hockey-puck::before {
  content: "\f453";
}
.z-icon-table::before {
  content: "\f0ce";
}
.z-icon-magnifying-glass-arrow-right::before {
  content: "\e521";
}
.z-icon-tachograph-digital::before {
  content: "\f566";
}
.z-icon-digital-tachograph::before {
  content: "\f566";
}
.z-icon-users-slash::before {
  content: "\e073";
}
.z-icon-clover::before {
  content: "\e139";
}
.z-icon-reply::before {
  content: "\f3e5";
}
.z-icon-mail-reply::before {
  content: "\f3e5";
}
.z-icon-star-and-crescent::before {
  content: "\f699";
}
.z-icon-house-fire::before {
  content: "\e50c";
}
.z-icon-square-minus::before {
  content: "\f146";
}
.z-icon-minus-square::before {
  content: "\f146";
}
.z-icon-helicopter::before {
  content: "\f533";
}
.z-icon-compass::before {
  content: "\f14e";
}
.z-icon-square-caret-down::before {
  content: "\f150";
}
.z-icon-caret-square-down::before {
  content: "\f150";
}
.z-icon-file-circle-question::before {
  content: "\e4ef";
}
.z-icon-laptop-code::before {
  content: "\f5fc";
}
.z-icon-swatchbook::before {
  content: "\f5c3";
}
.z-icon-prescription-bottle::before {
  content: "\f485";
}
.z-icon-bars::before {
  content: "\f0c9";
}
.z-icon-navicon::before {
  content: "\f0c9";
}
.z-icon-people-group::before {
  content: "\e533";
}
.z-icon-hourglass-end::before {
  content: "\f253";
}
.z-icon-hourglass-3::before {
  content: "\f253";
}
.z-icon-heart-crack::before {
  content: "\f7a9";
}
.z-icon-heart-broken::before {
  content: "\f7a9";
}
.z-icon-square-up-right::before {
  content: "\f360";
}
.z-icon-external-link-square-alt::before {
  content: "\f360";
}
.z-icon-face-kiss-beam::before {
  content: "\f597";
}
.z-icon-kiss-beam::before {
  content: "\f597";
}
.z-icon-film::before {
  content: "\f008";
}
.z-icon-ruler-horizontal::before {
  content: "\f547";
}
.z-icon-people-robbery::before {
  content: "\e536";
}
.z-icon-lightbulb::before {
  content: "\f0eb";
}
.z-icon-caret-left::before {
  content: "\f0d9";
}
.z-icon-circle-exclamation::before {
  content: "\f06a";
}
.z-icon-exclamation-circle::before {
  content: "\f06a";
}
.z-icon-school-circle-xmark::before {
  content: "\e56d";
}
.z-icon-arrow-right-from-bracket::before {
  content: "\f08b";
}
.z-icon-sign-out::before {
  content: "\f08b";
}
.z-icon-circle-chevron-down::before {
  content: "\f13a";
}
.z-icon-chevron-circle-down::before {
  content: "\f13a";
}
.z-icon-unlock-keyhole::before {
  content: "\f13e";
}
.z-icon-unlock-alt::before {
  content: "\f13e";
}
.z-icon-cloud-showers-heavy::before {
  content: "\f740";
}
.z-icon-headphones-simple::before {
  content: "\f58f";
}
.z-icon-headphones-alt::before {
  content: "\f58f";
}
.z-icon-sitemap::before {
  content: "\f0e8";
}
.z-icon-circle-dollar-to-slot::before {
  content: "\f4b9";
}
.z-icon-donate::before {
  content: "\f4b9";
}
.z-icon-memory::before {
  content: "\f538";
}
.z-icon-road-spikes::before {
  content: "\e568";
}
.z-icon-fire-burner::before {
  content: "\e4f1";
}
.z-icon-flag::before {
  content: "\f024";
}
.z-icon-hanukiah::before {
  content: "\f6e6";
}
.z-icon-feather::before {
  content: "\f52d";
}
.z-icon-volume-low::before {
  content: "\f027";
}
.z-icon-volume-down::before {
  content: "\f027";
}
.z-icon-comment-slash::before {
  content: "\f4b3";
}
.z-icon-cloud-sun-rain::before {
  content: "\f743";
}
.z-icon-compress::before {
  content: "\f066";
}
.z-icon-wheat-awn::before {
  content: "\e2cd";
}
.z-icon-wheat-alt::before {
  content: "\e2cd";
}
.z-icon-ankh::before {
  content: "\f644";
}
.z-icon-hands-holding-child::before {
  content: "\e4fa";
}
.z-icon-asterisk::before {
  content: "\2a";
}
.z-icon-square-check::before {
  content: "\f14a";
}
.z-icon-check-square::before {
  content: "\f14a";
}
.z-icon-peseta-sign::before {
  content: "\e221";
}
.z-icon-heading::before {
  content: "\f1dc";
}
.z-icon-header::before {
  content: "\f1dc";
}
.z-icon-ghost::before {
  content: "\f6e2";
}
.z-icon-list::before {
  content: "\f03a";
}
.z-icon-list-squares::before {
  content: "\f03a";
}
.z-icon-square-phone-flip::before {
  content: "\f87b";
}
.z-icon-phone-square-alt::before {
  content: "\f87b";
}
.z-icon-cart-plus::before {
  content: "\f217";
}
.z-icon-gamepad::before {
  content: "\f11b";
}
.z-icon-circle-dot::before {
  content: "\f192";
}
.z-icon-dot-circle::before {
  content: "\f192";
}
.z-icon-face-dizzy::before {
  content: "\f567";
}
.z-icon-dizzy::before {
  content: "\f567";
}
.z-icon-egg::before {
  content: "\f7fb";
}
.z-icon-house-medical-circle-xmark::before {
  content: "\e513";
}
.z-icon-campground::before {
  content: "\f6bb";
}
.z-icon-folder-plus::before {
  content: "\f65e";
}
.z-icon-futbol::before {
  content: "\f1e3";
}
.z-icon-futbol-ball::before {
  content: "\f1e3";
}
.z-icon-soccer-ball::before {
  content: "\f1e3";
}
.z-icon-paintbrush::before {
  content: "\f1fc";
}
.z-icon-paint-brush::before {
  content: "\f1fc";
}
.z-icon-lock::before {
  content: "\f023";
}
.z-icon-gas-pump::before {
  content: "\f52f";
}
.z-icon-hot-tub-person::before {
  content: "\f593";
}
.z-icon-hot-tub::before {
  content: "\f593";
}
.z-icon-map-location::before {
  content: "\f59f";
}
.z-icon-map-marked::before {
  content: "\f59f";
}
.z-icon-house-flood-water::before {
  content: "\e50e";
}
.z-icon-tree::before {
  content: "\f1bb";
}
.z-icon-bridge-lock::before {
  content: "\e4cc";
}
.z-icon-sack-dollar::before {
  content: "\f81d";
}
.z-icon-pen-to-square::before {
  content: "\f044";
}
.z-icon-edit::before {
  content: "\f044";
}
.z-icon-car-side::before {
  content: "\f5e4";
}
.z-icon-share-nodes::before {
  content: "\f1e0";
}
.z-icon-share-alt::before {
  content: "\f1e0";
}
.z-icon-heart-circle-minus::before {
  content: "\e4ff";
}
.z-icon-hourglass-half::before {
  content: "\f252";
}
.z-icon-hourglass-2::before {
  content: "\f252";
}
.z-icon-microscope::before {
  content: "\f610";
}
.z-icon-sink::before {
  content: "\e06d";
}
.z-icon-bag-shopping::before {
  content: "\f290";
}
.z-icon-shopping-bag::before {
  content: "\f290";
}
.z-icon-arrow-down-z-a::before {
  content: "\f881";
}
.z-icon-sort-alpha-desc::before {
  content: "\f881";
}
.z-icon-sort-alpha-down-alt::before {
  content: "\f881";
}
.z-icon-mitten::before {
  content: "\f7b5";
}
.z-icon-person-rays::before {
  content: "\e54d";
}
.z-icon-users::before {
  content: "\f0c0";
}
.z-icon-eye-slash::before {
  content: "\f070";
}
.z-icon-flask-vial::before {
  content: "\e4f3";
}
.z-icon-hand::before {
  content: "\f256";
}
.z-icon-hand-paper::before {
  content: "\f256";
}
.z-icon-om::before {
  content: "\f679";
}
.z-icon-worm::before {
  content: "\e599";
}
.z-icon-house-circle-xmark::before {
  content: "\e50b";
}
.z-icon-plug::before {
  content: "\f1e6";
}
.z-icon-chevron-up::before {
  content: "\f077";
}
.z-icon-hand-spock::before {
  content: "\f259";
}
.z-icon-stopwatch::before {
  content: "\f2f2";
}
.z-icon-face-kiss::before {
  content: "\f596";
}
.z-icon-kiss::before {
  content: "\f596";
}
.z-icon-bridge-circle-xmark::before {
  content: "\e4cb";
}
.z-icon-face-grin-tongue::before {
  content: "\f589";
}
.z-icon-grin-tongue::before {
  content: "\f589";
}
.z-icon-chess-bishop::before {
  content: "\f43a";
}
.z-icon-face-grin-wink::before {
  content: "\f58c";
}
.z-icon-grin-wink::before {
  content: "\f58c";
}
.z-icon-ear-deaf::before {
  content: "\f2a4";
}
.z-icon-deaf::before {
  content: "\f2a4";
}
.z-icon-deafness::before {
  content: "\f2a4";
}
.z-icon-hard-of-hearing::before {
  content: "\f2a4";
}
.z-icon-road-circle-check::before {
  content: "\e564";
}
.z-icon-dice-five::before {
  content: "\f523";
}
.z-icon-square-rss::before {
  content: "\f143";
}
.z-icon-rss-square::before {
  content: "\f143";
}
.z-icon-land-mine-on::before {
  content: "\e51b";
}
.z-icon-i-cursor::before {
  content: "\f246";
}
.z-icon-stamp::before {
  content: "\f5bf";
}
.z-icon-stairs::before {
  content: "\e289";
}
.z-icon-i::before {
  content: "\49";
}
.z-icon-hryvnia-sign::before {
  content: "\f6f2";
}
.z-icon-hryvnia::before {
  content: "\f6f2";
}
.z-icon-pills::before {
  content: "\f484";
}
.z-icon-face-grin-wide::before {
  content: "\f581";
}
.z-icon-grin-alt::before {
  content: "\f581";
}
.z-icon-tooth::before {
  content: "\f5c9";
}
.z-icon-v::before {
  content: "\56";
}
.z-icon-bangladeshi-taka-sign::before {
  content: "\e2e6";
}
.z-icon-bicycle::before {
  content: "\f206";
}
.z-icon-staff-snake::before {
  content: "\e579";
}
.z-icon-rod-asclepius::before {
  content: "\e579";
}
.z-icon-rod-snake::before {
  content: "\e579";
}
.z-icon-staff-aesculapius::before {
  content: "\e579";
}
.z-icon-head-side-cough-slash::before {
  content: "\e062";
}
.z-icon-truck-medical::before {
  content: "\f0f9";
}
.z-icon-ambulance::before {
  content: "\f0f9";
}
.z-icon-wheat-awn-circle-exclamation::before {
  content: "\e598";
}
.z-icon-snowman::before {
  content: "\f7d0";
}
.z-icon-mortar-pestle::before {
  content: "\f5a7";
}
.z-icon-road-barrier::before {
  content: "\e562";
}
.z-icon-school::before {
  content: "\f549";
}
.z-icon-igloo::before {
  content: "\f7ae";
}
.z-icon-joint::before {
  content: "\f595";
}
.z-icon-angle-right::before {
  content: "\f105";
}
.z-icon-horse::before {
  content: "\f6f0";
}
.z-icon-q::before {
  content: "\51";
}
.z-icon-g::before {
  content: "\47";
}
.z-icon-notes-medical::before {
  content: "\f481";
}
.z-icon-temperature-half::before {
  content: "\f2c9";
}
.z-icon-temperature-2::before {
  content: "\f2c9";
}
.z-icon-thermometer-2::before {
  content: "\f2c9";
}
.z-icon-thermometer-half::before {
  content: "\f2c9";
}
.z-icon-dong-sign::before {
  content: "\e169";
}
.z-icon-capsules::before {
  content: "\f46b";
}
.z-icon-poo-storm::before {
  content: "\f75a";
}
.z-icon-poo-bolt::before {
  content: "\f75a";
}
.z-icon-face-frown-open::before {
  content: "\f57a";
}
.z-icon-frown-open::before {
  content: "\f57a";
}
.z-icon-hand-point-up::before {
  content: "\f0a6";
}
.z-icon-money-bill::before {
  content: "\f0d6";
}
.z-icon-bookmark::before {
  content: "\f02e";
}
.z-icon-align-justify::before {
  content: "\f039";
}
.z-icon-umbrella-beach::before {
  content: "\f5ca";
}
.z-icon-helmet-un::before {
  content: "\e503";
}
.z-icon-bullseye::before {
  content: "\f140";
}
.z-icon-bacon::before {
  content: "\f7e5";
}
.z-icon-hand-point-down::before {
  content: "\f0a7";
}
.z-icon-arrow-up-from-bracket::before {
  content: "\e09a";
}
.z-icon-folder::before {
  content: "\f07b";
}
.z-icon-folder-blank::before {
  content: "\f07b";
}
.z-icon-file-waveform::before {
  content: "\f478";
}
.z-icon-file-medical-alt::before {
  content: "\f478";
}
.z-icon-radiation::before {
  content: "\f7b9";
}
.z-icon-chart-simple::before {
  content: "\e473";
}
.z-icon-mars-stroke::before {
  content: "\f229";
}
.z-icon-vial::before {
  content: "\f492";
}
.z-icon-gauge::before {
  content: "\f624";
}
.z-icon-dashboard::before {
  content: "\f624";
}
.z-icon-gauge-med::before {
  content: "\f624";
}
.z-icon-tachometer-alt-average::before {
  content: "\f624";
}
.z-icon-wand-magic-sparkles::before {
  content: "\e2ca";
}
.z-icon-magic-wand-sparkles::before {
  content: "\e2ca";
}
.z-icon-e::before {
  content: "\45";
}
.z-icon-pen-clip::before {
  content: "\f305";
}
.z-icon-pen-alt::before {
  content: "\f305";
}
.z-icon-bridge-circle-exclamation::before {
  content: "\e4ca";
}
.z-icon-user::before {
  content: "\f007";
}
.z-icon-school-circle-check::before {
  content: "\e56b";
}
.z-icon-dumpster::before {
  content: "\f793";
}
.z-icon-van-shuttle::before {
  content: "\f5b6";
}
.z-icon-shuttle-van::before {
  content: "\f5b6";
}
.z-icon-building-user::before {
  content: "\e4da";
}
.z-icon-square-caret-left::before {
  content: "\f191";
}
.z-icon-caret-square-left::before {
  content: "\f191";
}
.z-icon-highlighter::before {
  content: "\f591";
}
.z-icon-key::before {
  content: "\f084";
}
.z-icon-bullhorn::before {
  content: "\f0a1";
}
.z-icon-globe::before {
  content: "\f0ac";
}
.z-icon-synagogue::before {
  content: "\f69b";
}
.z-icon-person-half-dress::before {
  content: "\e548";
}
.z-icon-road-bridge::before {
  content: "\e563";
}
.z-icon-location-arrow::before {
  content: "\f124";
}
.z-icon-c::before {
  content: "\43";
}
.z-icon-tablet-button::before {
  content: "\f10a";
}
.z-icon-building-lock::before {
  content: "\e4d6";
}
.z-icon-pizza-slice::before {
  content: "\f818";
}
.z-icon-money-bill-wave::before {
  content: "\f53a";
}
.z-icon-chart-area::before {
  content: "\f1fe";
}
.z-icon-area-chart::before {
  content: "\f1fe";
}
.z-icon-house-flag::before {
  content: "\e50d";
}
.z-icon-person-circle-minus::before {
  content: "\e540";
}
.z-icon-ban::before {
  content: "\f05e";
}
.z-icon-cancel::before {
  content: "\f05e";
}
.z-icon-camera-rotate::before {
  content: "\e0d8";
}
.z-icon-spray-can-sparkles::before {
  content: "\f5d0";
}
.z-icon-air-freshener::before {
  content: "\f5d0";
}
.z-icon-star::before {
  content: "\f005";
}
.z-icon-repeat::before {
  content: "\f363";
}
.z-icon-cross::before {
  content: "\f654";
}
.z-icon-box::before {
  content: "\f466";
}
.z-icon-venus-mars::before {
  content: "\f228";
}
.z-icon-arrow-pointer::before {
  content: "\f245";
}
.z-icon-mouse-pointer::before {
  content: "\f245";
}
.z-icon-maximize::before {
  content: "\f31e";
}
.z-icon-expand-arrows-alt::before {
  content: "\f31e";
}
.z-icon-charging-station::before {
  content: "\f5e7";
}
.z-icon-shapes::before {
  content: "\f61f";
}
.z-icon-triangle-circle-square::before {
  content: "\f61f";
}
.z-icon-shuffle::before {
  content: "\f074";
}
.z-icon-random::before {
  content: "\f074";
}
.z-icon-person-running::before {
  content: "\f70c";
}
.z-icon-running::before {
  content: "\f70c";
}
.z-icon-mobile-retro::before {
  content: "\e527";
}
.z-icon-grip-lines-vertical::before {
  content: "\f7a5";
}
.z-icon-spider::before {
  content: "\f717";
}
.z-icon-hands-bound::before {
  content: "\e4f9";
}
.z-icon-file-invoice-dollar::before {
  content: "\f571";
}
.z-icon-plane-circle-exclamation::before {
  content: "\e556";
}
.z-icon-x-ray::before {
  content: "\f497";
}
.z-icon-spell-check::before {
  content: "\f891";
}
.z-icon-slash::before {
  content: "\f715";
}
.z-icon-computer-mouse::before {
  content: "\f8cc";
}
.z-icon-mouse::before {
  content: "\f8cc";
}
.z-icon-arrow-right-to-bracket::before {
  content: "\f090";
}
.z-icon-sign-in::before {
  content: "\f090";
}
.z-icon-shop-slash::before {
  content: "\e070";
}
.z-icon-store-alt-slash::before {
  content: "\e070";
}
.z-icon-server::before {
  content: "\f233";
}
.z-icon-virus-covid-slash::before {
  content: "\e4a9";
}
.z-icon-shop-lock::before {
  content: "\e4a5";
}
.z-icon-hourglass-start::before {
  content: "\f251";
}
.z-icon-hourglass-1::before {
  content: "\f251";
}
.z-icon-blender-phone::before {
  content: "\f6b6";
}
.z-icon-building-wheat::before {
  content: "\e4db";
}
.z-icon-person-breastfeeding::before {
  content: "\e53a";
}
.z-icon-right-to-bracket::before {
  content: "\f2f6";
}
.z-icon-sign-in-alt::before {
  content: "\f2f6";
}
.z-icon-venus::before {
  content: "\f221";
}
.z-icon-passport::before {
  content: "\f5ab";
}
.z-icon-heart-pulse::before {
  content: "\f21e";
}
.z-icon-heartbeat::before {
  content: "\f21e";
}
.z-icon-people-carry-box::before {
  content: "\f4ce";
}
.z-icon-people-carry::before {
  content: "\f4ce";
}
.z-icon-temperature-high::before {
  content: "\f769";
}
.z-icon-microchip::before {
  content: "\f2db";
}
.z-icon-crown::before {
  content: "\f521";
}
.z-icon-weight-hanging::before {
  content: "\f5cd";
}
.z-icon-xmarks-lines::before {
  content: "\e59a";
}
.z-icon-file-prescription::before {
  content: "\f572";
}
.z-icon-weight-scale::before {
  content: "\f496";
}
.z-icon-weight::before {
  content: "\f496";
}
.z-icon-user-group::before {
  content: "\f500";
}
.z-icon-user-friends::before {
  content: "\f500";
}
.z-icon-arrow-up-a-z::before {
  content: "\f15e";
}
.z-icon-sort-alpha-up::before {
  content: "\f15e";
}
.z-icon-chess-knight::before {
  content: "\f441";
}
.z-icon-face-laugh-squint::before {
  content: "\f59b";
}
.z-icon-laugh-squint::before {
  content: "\f59b";
}
.z-icon-wheelchair::before {
  content: "\f193";
}
.z-icon-circle-arrow-up::before {
  content: "\f0aa";
}
.z-icon-arrow-circle-up::before {
  content: "\f0aa";
}
.z-icon-toggle-on::before {
  content: "\f205";
}
.z-icon-person-walking::before {
  content: "\f554";
}
.z-icon-walking::before {
  content: "\f554";
}
.z-icon-l::before {
  content: "\4c";
}
.z-icon-fire::before {
  content: "\f06d";
}
.z-icon-bed-pulse::before {
  content: "\f487";
}
.z-icon-procedures::before {
  content: "\f487";
}
.z-icon-shuttle-space::before {
  content: "\f197";
}
.z-icon-space-shuttle::before {
  content: "\f197";
}
.z-icon-face-laugh::before {
  content: "\f599";
}
.z-icon-laugh::before {
  content: "\f599";
}
.z-icon-folder-open::before {
  content: "\f07c";
}
.z-icon-heart-circle-plus::before {
  content: "\e500";
}
.z-icon-code-fork::before {
  content: "\e13b";
}
.z-icon-city::before {
  content: "\f64f";
}
.z-icon-microphone-lines::before {
  content: "\f3c9";
}
.z-icon-microphone-alt::before {
  content: "\f3c9";
}
.z-icon-pepper-hot::before {
  content: "\f816";
}
.z-icon-unlock::before {
  content: "\f09c";
}
.z-icon-colon-sign::before {
  content: "\e140";
}
.z-icon-headset::before {
  content: "\f590";
}
.z-icon-store-slash::before {
  content: "\e071";
}
.z-icon-road-circle-xmark::before {
  content: "\e566";
}
.z-icon-user-minus::before {
  content: "\f503";
}
.z-icon-mars-stroke-up::before {
  content: "\f22a";
}
.z-icon-mars-stroke-v::before {
  content: "\f22a";
}
.z-icon-champagne-glasses::before {
  content: "\f79f";
}
.z-icon-glass-cheers::before {
  content: "\f79f";
}
.z-icon-clipboard::before {
  content: "\f328";
}
.z-icon-house-circle-exclamation::before {
  content: "\e50a";
}
.z-icon-file-arrow-up::before {
  content: "\f574";
}
.z-icon-file-upload::before {
  content: "\f574";
}
.z-icon-wifi::before {
  content: "\f1eb";
}
.z-icon-wifi-3::before {
  content: "\f1eb";
}
.z-icon-wifi-strong::before {
  content: "\f1eb";
}
.z-icon-bath::before {
  content: "\f2cd";
}
.z-icon-bathtub::before {
  content: "\f2cd";
}
.z-icon-underline::before {
  content: "\f0cd";
}
.z-icon-user-pen::before {
  content: "\f4ff";
}
.z-icon-user-edit::before {
  content: "\f4ff";
}
.z-icon-signature::before {
  content: "\f5b7";
}
.z-icon-stroopwafel::before {
  content: "\f551";
}
.z-icon-bold::before {
  content: "\f032";
}
.z-icon-anchor-lock::before {
  content: "\e4ad";
}
.z-icon-building-ngo::before {
  content: "\e4d7";
}
.z-icon-manat-sign::before {
  content: "\e1d5";
}
.z-icon-not-equal::before {
  content: "\f53e";
}
.z-icon-border-top-left::before {
  content: "\f853";
}
.z-icon-border-style::before {
  content: "\f853";
}
.z-icon-map-location-dot::before {
  content: "\f5a0";
}
.z-icon-map-marked-alt::before {
  content: "\f5a0";
}
.z-icon-jedi::before {
  content: "\f669";
}
.z-icon-square-poll-vertical::before {
  content: "\f681";
}
.z-icon-poll::before {
  content: "\f681";
}
.z-icon-mug-hot::before {
  content: "\f7b6";
}
.z-icon-car-battery::before {
  content: "\f5df";
}
.z-icon-battery-car::before {
  content: "\f5df";
}
.z-icon-gift::before {
  content: "\f06b";
}
.z-icon-dice-two::before {
  content: "\f528";
}
.z-icon-chess-queen::before {
  content: "\f445";
}
.z-icon-glasses::before {
  content: "\f530";
}
.z-icon-chess-board::before {
  content: "\f43c";
}
.z-icon-building-circle-check::before {
  content: "\e4d2";
}
.z-icon-person-chalkboard::before {
  content: "\e53d";
}
.z-icon-mars-stroke-right::before {
  content: "\f22b";
}
.z-icon-mars-stroke-h::before {
  content: "\f22b";
}
.z-icon-hand-back-fist::before {
  content: "\f255";
}
.z-icon-hand-rock::before {
  content: "\f255";
}
.z-icon-square-caret-up::before {
  content: "\f151";
}
.z-icon-caret-square-up::before {
  content: "\f151";
}
.z-icon-cloud-showers-water::before {
  content: "\e4e4";
}
.z-icon-chart-bar::before {
  content: "\f080";
}
.z-icon-bar-chart::before {
  content: "\f080";
}
.z-icon-hands-bubbles::before {
  content: "\e05e";
}
.z-icon-hands-wash::before {
  content: "\e05e";
}
.z-icon-less-than-equal::before {
  content: "\f537";
}
.z-icon-train::before {
  content: "\f238";
}
.z-icon-eye-low-vision::before {
  content: "\f2a8";
}
.z-icon-low-vision::before {
  content: "\f2a8";
}
.z-icon-crow::before {
  content: "\f520";
}
.z-icon-sailboat::before {
  content: "\e445";
}
.z-icon-window-restore::before {
  content: "\f2d2";
}
.z-icon-square-plus::before {
  content: "\f0fe";
}
.z-icon-plus-square::before {
  content: "\f0fe";
}
.z-icon-torii-gate::before {
  content: "\f6a1";
}
.z-icon-frog::before {
  content: "\f52e";
}
.z-icon-bucket::before {
  content: "\e4cf";
}
.z-icon-image::before {
  content: "\f03e";
}
.z-icon-microphone::before {
  content: "\f130";
}
.z-icon-cow::before {
  content: "\f6c8";
}
.z-icon-caret-up::before {
  content: "\f0d8";
}
.z-icon-screwdriver::before {
  content: "\f54a";
}
.z-icon-folder-closed::before {
  content: "\e185";
}
.z-icon-house-tsunami::before {
  content: "\e515";
}
.z-icon-square-nfi::before {
  content: "\e576";
}
.z-icon-arrow-up-from-ground-water::before {
  content: "\e4b5";
}
.z-icon-martini-glass::before {
  content: "\f57b";
}
.z-icon-glass-martini-alt::before {
  content: "\f57b";
}
.z-icon-rotate-left::before {
  content: "\f2ea";
}
.z-icon-rotate-back::before {
  content: "\f2ea";
}
.z-icon-rotate-backward::before {
  content: "\f2ea";
}
.z-icon-undo-alt::before {
  content: "\f2ea";
}
.z-icon-table-columns::before {
  content: "\f0db";
}
.z-icon-columns::before {
  content: "\f0db";
}
.z-icon-lemon::before {
  content: "\f094";
}
.z-icon-head-side-mask::before {
  content: "\e063";
}
.z-icon-handshake::before {
  content: "\f2b5";
}
.z-icon-gem::before {
  content: "\f3a5";
}
.z-icon-dolly::before {
  content: "\f472";
}
.z-icon-dolly-box::before {
  content: "\f472";
}
.z-icon-smoking::before {
  content: "\f48d";
}
.z-icon-minimize::before {
  content: "\f78c";
}
.z-icon-compress-arrows-alt::before {
  content: "\f78c";
}
.z-icon-monument::before {
  content: "\f5a6";
}
.z-icon-snowplow::before {
  content: "\f7d2";
}
.z-icon-angles-right::before {
  content: "\f101";
}
.z-icon-angle-double-right::before {
  content: "\f101";
}
.z-icon-cannabis::before {
  content: "\f55f";
}
.z-icon-circle-play::before {
  content: "\f144";
}
.z-icon-play-circle::before {
  content: "\f144";
}
.z-icon-tablets::before {
  content: "\f490";
}
.z-icon-ethernet::before {
  content: "\f796";
}
.z-icon-euro-sign::before {
  content: "\f153";
}
.z-icon-eur::before {
  content: "\f153";
}
.z-icon-euro::before {
  content: "\f153";
}
.z-icon-chair::before {
  content: "\f6c0";
}
.z-icon-circle-check::before {
  content: "\f058";
}
.z-icon-check-circle::before {
  content: "\f058";
}
.z-icon-circle-stop::before {
  content: "\f28d";
}
.z-icon-stop-circle::before {
  content: "\f28d";
}
.z-icon-compass-drafting::before {
  content: "\f568";
}
.z-icon-drafting-compass::before {
  content: "\f568";
}
.z-icon-plate-wheat::before {
  content: "\e55a";
}
.z-icon-icicles::before {
  content: "\f7ad";
}
.z-icon-person-shelter::before {
  content: "\e54f";
}
.z-icon-neuter::before {
  content: "\f22c";
}
.z-icon-id-badge::before {
  content: "\f2c1";
}
.z-icon-marker::before {
  content: "\f5a1";
}
.z-icon-face-laugh-beam::before {
  content: "\f59a";
}
.z-icon-laugh-beam::before {
  content: "\f59a";
}
.z-icon-helicopter-symbol::before {
  content: "\e502";
}
.z-icon-universal-access::before {
  content: "\f29a";
}
.z-icon-circle-chevron-up::before {
  content: "\f139";
}
.z-icon-chevron-circle-up::before {
  content: "\f139";
}
.z-icon-lari-sign::before {
  content: "\e1c8";
}
.z-icon-volcano::before {
  content: "\f770";
}
.z-icon-person-walking-dashed-line-arrow-right::before {
  content: "\e553";
}
.z-icon-sterling-sign::before {
  content: "\f154";
}
.z-icon-gbp::before {
  content: "\f154";
}
.z-icon-pound-sign::before {
  content: "\f154";
}
.z-icon-viruses::before {
  content: "\e076";
}
.z-icon-square-person-confined::before {
  content: "\e577";
}
.z-icon-user-tie::before {
  content: "\f508";
}
.z-icon-arrow-down-long::before {
  content: "\f175";
}
.z-icon-long-arrow-down::before {
  content: "\f175";
}
.z-icon-tent-arrow-down-to-line::before {
  content: "\e57e";
}
.z-icon-certificate::before {
  content: "\f0a3";
}
.z-icon-reply-all::before {
  content: "\f122";
}
.z-icon-mail-reply-all::before {
  content: "\f122";
}
.z-icon-suitcase::before {
  content: "\f0f2";
}
.z-icon-person-skating::before {
  content: "\f7c5";
}
.z-icon-skating::before {
  content: "\f7c5";
}
.z-icon-filter-circle-dollar::before {
  content: "\f662";
}
.z-icon-funnel-dollar::before {
  content: "\f662";
}
.z-icon-camera-retro::before {
  content: "\f083";
}
.z-icon-circle-arrow-down::before {
  content: "\f0ab";
}
.z-icon-arrow-circle-down::before {
  content: "\f0ab";
}
.z-icon-file-import::before {
  content: "\f56f";
}
.z-icon-arrow-right-to-file::before {
  content: "\f56f";
}
.z-icon-square-arrow-up-right::before {
  content: "\f14c";
}
.z-icon-external-link-square::before {
  content: "\f14c";
}
.z-icon-box-open::before {
  content: "\f49e";
}
.z-icon-scroll::before {
  content: "\f70e";
}
.z-icon-spa::before {
  content: "\f5bb";
}
.z-icon-location-pin-lock::before {
  content: "\e51f";
}
.z-icon-pause::before {
  content: "\f04c";
}
.z-icon-hill-avalanche::before {
  content: "\e507";
}
.z-icon-temperature-empty::before {
  content: "\f2cb";
}
.z-icon-temperature-0::before {
  content: "\f2cb";
}
.z-icon-thermometer-0::before {
  content: "\f2cb";
}
.z-icon-thermometer-empty::before {
  content: "\f2cb";
}
.z-icon-bomb::before {
  content: "\f1e2";
}
.z-icon-registered::before {
  content: "\f25d";
}
.z-icon-address-card::before {
  content: "\f2bb";
}
.z-icon-contact-card::before {
  content: "\f2bb";
}
.z-icon-vcard::before {
  content: "\f2bb";
}
.z-icon-scale-unbalanced-flip::before {
  content: "\f516";
}
.z-icon-balance-scale-right::before {
  content: "\f516";
}
.z-icon-subscript::before {
  content: "\f12c";
}
.z-icon-diamond-turn-right::before {
  content: "\f5eb";
}
.z-icon-directions::before {
  content: "\f5eb";
}
.z-icon-burst::before {
  content: "\e4dc";
}
.z-icon-house-laptop::before {
  content: "\e066";
}
.z-icon-laptop-house::before {
  content: "\e066";
}
.z-icon-face-tired::before {
  content: "\f5c8";
}
.z-icon-tired::before {
  content: "\f5c8";
}
.z-icon-money-bills::before {
  content: "\e1f3";
}
.z-icon-smog::before {
  content: "\f75f";
}
.z-icon-crutch::before {
  content: "\f7f7";
}
.z-icon-cloud-arrow-up::before {
  content: "\f0ee";
}
.z-icon-cloud-upload::before {
  content: "\f0ee";
}
.z-icon-cloud-upload-alt::before {
  content: "\f0ee";
}
.z-icon-palette::before {
  content: "\f53f";
}
.z-icon-arrows-turn-right::before {
  content: "\e4c0";
}
.z-icon-vest::before {
  content: "\e085";
}
.z-icon-ferry::before {
  content: "\e4ea";
}
.z-icon-arrows-down-to-people::before {
  content: "\e4b9";
}
.z-icon-seedling::before {
  content: "\f4d8";
}
.z-icon-sprout::before {
  content: "\f4d8";
}
.z-icon-left-right::before {
  content: "\f337";
}
.z-icon-arrows-alt-h::before {
  content: "\f337";
}
.z-icon-boxes-packing::before {
  content: "\e4c7";
}
.z-icon-circle-arrow-left::before {
  content: "\f0a8";
}
.z-icon-arrow-circle-left::before {
  content: "\f0a8";
}
.z-icon-group-arrows-rotate::before {
  content: "\e4f6";
}
.z-icon-bowl-food::before {
  content: "\e4c6";
}
.z-icon-candy-cane::before {
  content: "\f786";
}
.z-icon-arrow-down-wide-short::before {
  content: "\f160";
}
.z-icon-sort-amount-asc::before {
  content: "\f160";
}
.z-icon-sort-amount-down::before {
  content: "\f160";
}
.z-icon-cloud-bolt::before {
  content: "\f76c";
}
.z-icon-thunderstorm::before {
  content: "\f76c";
}
.z-icon-text-slash::before {
  content: "\f87d";
}
.z-icon-remove-format::before {
  content: "\f87d";
}
.z-icon-face-smile-wink::before {
  content: "\f4da";
}
.z-icon-smile-wink::before {
  content: "\f4da";
}
.z-icon-file-word::before {
  content: "\f1c2";
}
.z-icon-file-powerpoint::before {
  content: "\f1c4";
}
.z-icon-arrows-left-right::before {
  content: "\f07e";
}
.z-icon-arrows-h::before {
  content: "\f07e";
}
.z-icon-house-lock::before {
  content: "\e510";
}
.z-icon-cloud-arrow-down::before {
  content: "\f0ed";
}
.z-icon-cloud-download::before {
  content: "\f0ed";
}
.z-icon-cloud-download-alt::before {
  content: "\f0ed";
}
.z-icon-children::before {
  content: "\e4e1";
}
.z-icon-chalkboard::before {
  content: "\f51b";
}
.z-icon-blackboard::before {
  content: "\f51b";
}
.z-icon-user-large-slash::before {
  content: "\f4fa";
}
.z-icon-user-alt-slash::before {
  content: "\f4fa";
}
.z-icon-envelope-open::before {
  content: "\f2b6";
}
.z-icon-handshake-simple-slash::before {
  content: "\e05f";
}
.z-icon-handshake-alt-slash::before {
  content: "\e05f";
}
.z-icon-mattress-pillow::before {
  content: "\e525";
}
.z-icon-guarani-sign::before {
  content: "\e19a";
}
.z-icon-arrows-rotate::before {
  content: "\f021";
}
.z-icon-refresh::before {
  content: "\f021";
}
.z-icon-sync::before {
  content: "\f021";
}
.z-icon-fire-extinguisher::before {
  content: "\f134";
}
.z-icon-cruzeiro-sign::before {
  content: "\e152";
}
.z-icon-greater-than-equal::before {
  content: "\f532";
}
.z-icon-shield-halved::before {
  content: "\f3ed";
}
.z-icon-shield-alt::before {
  content: "\f3ed";
}
.z-icon-book-atlas::before {
  content: "\f558";
}
.z-icon-atlas::before {
  content: "\f558";
}
.z-icon-virus::before {
  content: "\e074";
}
.z-icon-envelope-circle-check::before {
  content: "\e4e8";
}
.z-icon-layer-group::before {
  content: "\f5fd";
}
.z-icon-arrows-to-dot::before {
  content: "\e4be";
}
.z-icon-archway::before {
  content: "\f557";
}
.z-icon-heart-circle-check::before {
  content: "\e4fd";
}
.z-icon-house-chimney-crack::before {
  content: "\f6f1";
}
.z-icon-house-damage::before {
  content: "\f6f1";
}
.z-icon-file-zipper::before {
  content: "\f1c6";
}
.z-icon-file-archive::before {
  content: "\f1c6";
}
.z-icon-square::before {
  content: "\f0c8";
}
.z-icon-martini-glass-empty::before {
  content: "\f000";
}
.z-icon-glass-martini::before {
  content: "\f000";
}
.z-icon-couch::before {
  content: "\f4b8";
}
.z-icon-cedi-sign::before {
  content: "\e0df";
}
.z-icon-italic::before {
  content: "\f033";
}
.z-icon-church::before {
  content: "\f51d";
}
.z-icon-comments-dollar::before {
  content: "\f653";
}
.z-icon-democrat::before {
  content: "\f747";
}
.z-icon-z::before {
  content: "\5a";
}
.z-icon-person-skiing::before {
  content: "\f7c9";
}
.z-icon-skiing::before {
  content: "\f7c9";
}
.z-icon-road-lock::before {
  content: "\e567";
}
.z-icon-a::before {
  content: "\41";
}
.z-icon-temperature-arrow-down::before {
  content: "\e03f";
}
.z-icon-temperature-down::before {
  content: "\e03f";
}
.z-icon-feather-pointed::before {
  content: "\f56b";
}
.z-icon-feather-alt::before {
  content: "\f56b";
}
.z-icon-p::before {
  content: "\50";
}
.z-icon-snowflake::before {
  content: "\f2dc";
}
.z-icon-newspaper::before {
  content: "\f1ea";
}
.z-icon-rectangle-ad::before {
  content: "\f641";
}
.z-icon-ad::before {
  content: "\f641";
}
.z-icon-circle-arrow-right::before {
  content: "\f0a9";
}
.z-icon-arrow-circle-right::before {
  content: "\f0a9";
}
.z-icon-filter-circle-xmark::before {
  content: "\e17b";
}
.z-icon-locust::before {
  content: "\e520";
}
.z-icon-sort::before {
  content: "\f0dc";
}
.z-icon-unsorted::before {
  content: "\f0dc";
}
.z-icon-list-ol::before {
  content: "\f0cb";
}
.z-icon-list-1-2::before {
  content: "\f0cb";
}
.z-icon-list-numeric::before {
  content: "\f0cb";
}
.z-icon-person-dress-burst::before {
  content: "\e544";
}
.z-icon-money-check-dollar::before {
  content: "\f53d";
}
.z-icon-money-check-alt::before {
  content: "\f53d";
}
.z-icon-vector-square::before {
  content: "\f5cb";
}
.z-icon-bread-slice::before {
  content: "\f7ec";
}
.z-icon-language::before {
  content: "\f1ab";
}
.z-icon-face-kiss-wink-heart::before {
  content: "\f598";
}
.z-icon-kiss-wink-heart::before {
  content: "\f598";
}
.z-icon-filter::before {
  content: "\f0b0";
}
.z-icon-question::before {
  content: "\3f";
}
.z-icon-file-signature::before {
  content: "\f573";
}
.z-icon-up-down-left-right::before {
  content: "\f0b2";
}
.z-icon-arrows-alt::before {
  content: "\f0b2";
}
.z-icon-house-chimney-user::before {
  content: "\e065";
}
.z-icon-hand-holding-heart::before {
  content: "\f4be";
}
.z-icon-puzzle-piece::before {
  content: "\f12e";
}
.z-icon-money-check::before {
  content: "\f53c";
}
.z-icon-star-half-stroke::before {
  content: "\f5c0";
}
.z-icon-star-half-alt::before {
  content: "\f5c0";
}
.z-icon-code::before {
  content: "\f121";
}
.z-icon-whiskey-glass::before {
  content: "\f7a0";
}
.z-icon-glass-whiskey::before {
  content: "\f7a0";
}
.z-icon-building-circle-exclamation::before {
  content: "\e4d3";
}
.z-icon-magnifying-glass-chart::before {
  content: "\e522";
}
.z-icon-arrow-up-right-from-square::before {
  content: "\f08e";
}
.z-icon-external-link::before {
  content: "\f08e";
}
.z-icon-cubes-stacked::before {
  content: "\e4e6";
}
.z-icon-won-sign::before {
  content: "\f159";
}
.z-icon-krw::before {
  content: "\f159";
}
.z-icon-won::before {
  content: "\f159";
}
.z-icon-virus-covid::before {
  content: "\e4a8";
}
.z-icon-austral-sign::before {
  content: "\e0a9";
}
.z-icon-f::before {
  content: "\46";
}
.z-icon-leaf::before {
  content: "\f06c";
}
.z-icon-road::before {
  content: "\f018";
}
.z-icon-taxi::before {
  content: "\f1ba";
}
.z-icon-cab::before {
  content: "\f1ba";
}
.z-icon-person-circle-plus::before {
  content: "\e541";
}
.z-icon-chart-pie::before {
  content: "\f200";
}
.z-icon-pie-chart::before {
  content: "\f200";
}
.z-icon-bolt-lightning::before {
  content: "\e0b7";
}
.z-icon-sack-xmark::before {
  content: "\e56a";
}
.z-icon-file-excel::before {
  content: "\f1c3";
}
.z-icon-file-contract::before {
  content: "\f56c";
}
.z-icon-fish-fins::before {
  content: "\e4f2";
}
.z-icon-building-flag::before {
  content: "\e4d5";
}
.z-icon-face-grin-beam::before {
  content: "\f582";
}
.z-icon-grin-beam::before {
  content: "\f582";
}
.z-icon-object-ungroup::before {
  content: "\f248";
}
.z-icon-poop::before {
  content: "\f619";
}
.z-icon-location-pin::before {
  content: "\f041";
}
.z-icon-map-marker::before {
  content: "\f041";
}
.z-icon-kaaba::before {
  content: "\f66b";
}
.z-icon-toilet-paper::before {
  content: "\f71e";
}
.z-icon-helmet-safety::before {
  content: "\f807";
}
.z-icon-hard-hat::before {
  content: "\f807";
}
.z-icon-hat-hard::before {
  content: "\f807";
}
.z-icon-eject::before {
  content: "\f052";
}
.z-icon-circle-right::before {
  content: "\f35a";
}
.z-icon-arrow-alt-circle-right::before {
  content: "\f35a";
}
.z-icon-plane-circle-check::before {
  content: "\e555";
}
.z-icon-face-rolling-eyes::before {
  content: "\f5a5";
}
.z-icon-meh-rolling-eyes::before {
  content: "\f5a5";
}
.z-icon-object-group::before {
  content: "\f247";
}
.z-icon-chart-line::before {
  content: "\f201";
}
.z-icon-line-chart::before {
  content: "\f201";
}
.z-icon-mask-ventilator::before {
  content: "\e524";
}
.z-icon-arrow-right::before {
  content: "\f061";
}
.z-icon-signs-post::before {
  content: "\f277";
}
.z-icon-map-signs::before {
  content: "\f277";
}
.z-icon-cash-register::before {
  content: "\f788";
}
.z-icon-person-circle-question::before {
  content: "\e542";
}
.z-icon-h::before {
  content: "\48";
}
.z-icon-tarp::before {
  content: "\e57b";
}
.z-icon-screwdriver-wrench::before {
  content: "\f7d9";
}
.z-icon-tools::before {
  content: "\f7d9";
}
.z-icon-arrows-to-eye::before {
  content: "\e4bf";
}
.z-icon-plug-circle-bolt::before {
  content: "\e55b";
}
.z-icon-heart::before {
  content: "\f004";
}
.z-icon-mars-and-venus::before {
  content: "\f224";
}
.z-icon-house-user::before {
  content: "\e1b0";
}
.z-icon-home-user::before {
  content: "\e1b0";
}
.z-icon-dumpster-fire::before {
  content: "\f794";
}
.z-icon-house-crack::before {
  content: "\e3b1";
}
.z-icon-martini-glass-citrus::before {
  content: "\f561";
}
.z-icon-cocktail::before {
  content: "\f561";
}
.z-icon-face-surprise::before {
  content: "\f5c2";
}
.z-icon-surprise::before {
  content: "\f5c2";
}
.z-icon-bottle-water::before {
  content: "\e4c5";
}
.z-icon-circle-pause::before {
  content: "\f28b";
}
.z-icon-pause-circle::before {
  content: "\f28b";
}
.z-icon-toilet-paper-slash::before {
  content: "\e072";
}
.z-icon-apple-whole::before {
  content: "\f5d1";
}
.z-icon-apple-alt::before {
  content: "\f5d1";
}
.z-icon-kitchen-set::before {
  content: "\e51a";
}
.z-icon-r::before {
  content: "\52";
}
.z-icon-temperature-quarter::before {
  content: "\f2ca";
}
.z-icon-temperature-1::before {
  content: "\f2ca";
}
.z-icon-thermometer-1::before {
  content: "\f2ca";
}
.z-icon-thermometer-quarter::before {
  content: "\f2ca";
}
.z-icon-cube::before {
  content: "\f1b2";
}
.z-icon-bitcoin-sign::before {
  content: "\e0b4";
}
.z-icon-shield-dog::before {
  content: "\e573";
}
.z-icon-solar-panel::before {
  content: "\f5ba";
}
.z-icon-lock-open::before {
  content: "\f3c1";
}
.z-icon-elevator::before {
  content: "\e16d";
}
.z-icon-money-bill-transfer::before {
  content: "\e528";
}
.z-icon-money-bill-trend-up::before {
  content: "\e529";
}
.z-icon-house-flood-water-circle-arrow-right::before {
  content: "\e50f";
}
.z-icon-square-poll-horizontal::before {
  content: "\f682";
}
.z-icon-poll-h::before {
  content: "\f682";
}
.z-icon-circle::before {
  content: "\f111";
}
.z-icon-backward-fast::before {
  content: "\f049";
}
.z-icon-fast-backward::before {
  content: "\f049";
}
.z-icon-recycle::before {
  content: "\f1b8";
}
.z-icon-user-astronaut::before {
  content: "\f4fb";
}
.z-icon-plane-slash::before {
  content: "\e069";
}
.z-icon-trademark::before {
  content: "\f25c";
}
.z-icon-basketball::before {
  content: "\f434";
}
.z-icon-basketball-ball::before {
  content: "\f434";
}
.z-icon-satellite-dish::before {
  content: "\f7c0";
}
.z-icon-circle-up::before {
  content: "\f35b";
}
.z-icon-arrow-alt-circle-up::before {
  content: "\f35b";
}
.z-icon-mobile-screen-button::before {
  content: "\f3cd";
}
.z-icon-mobile-alt::before {
  content: "\f3cd";
}
.z-icon-volume-high::before {
  content: "\f028";
}
.z-icon-volume-up::before {
  content: "\f028";
}
.z-icon-users-rays::before {
  content: "\e593";
}
.z-icon-wallet::before {
  content: "\f555";
}
.z-icon-clipboard-check::before {
  content: "\f46c";
}
.z-icon-file-audio::before {
  content: "\f1c7";
}
.z-icon-burger::before {
  content: "\f805";
}
.z-icon-hamburger::before {
  content: "\f805";
}
.z-icon-wrench::before {
  content: "\f0ad";
}
.z-icon-bugs::before {
  content: "\e4d0";
}
.z-icon-rupee-sign::before {
  content: "\f156";
}
.z-icon-rupee::before {
  content: "\f156";
}
.z-icon-file-image::before {
  content: "\f1c5";
}
.z-icon-circle-question::before {
  content: "\f059";
}
.z-icon-question-circle::before {
  content: "\f059";
}
.z-icon-plane-departure::before {
  content: "\f5b0";
}
.z-icon-handshake-slash::before {
  content: "\e060";
}
.z-icon-book-bookmark::before {
  content: "\e0bb";
}
.z-icon-code-branch::before {
  content: "\f126";
}
.z-icon-hat-cowboy::before {
  content: "\f8c0";
}
.z-icon-bridge::before {
  content: "\e4c8";
}
.z-icon-phone-flip::before {
  content: "\f879";
}
.z-icon-phone-alt::before {
  content: "\f879";
}
.z-icon-truck-front::before {
  content: "\e2b7";
}
.z-icon-cat::before {
  content: "\f6be";
}
.z-icon-anchor-circle-exclamation::before {
  content: "\e4ab";
}
.z-icon-truck-field::before {
  content: "\e58d";
}
.z-icon-route::before {
  content: "\f4d7";
}
.z-icon-clipboard-question::before {
  content: "\e4e3";
}
.z-icon-panorama::before {
  content: "\e209";
}
.z-icon-comment-medical::before {
  content: "\f7f5";
}
.z-icon-teeth-open::before {
  content: "\f62f";
}
.z-icon-file-circle-minus::before {
  content: "\e4ed";
}
.z-icon-tags::before {
  content: "\f02c";
}
.z-icon-wine-glass::before {
  content: "\f4e3";
}
.z-icon-forward-fast::before {
  content: "\f050";
}
.z-icon-fast-forward::before {
  content: "\f050";
}
.z-icon-face-meh-blank::before {
  content: "\f5a4";
}
.z-icon-meh-blank::before {
  content: "\f5a4";
}
.z-icon-square-parking::before {
  content: "\f540";
}
.z-icon-parking::before {
  content: "\f540";
}
.z-icon-house-signal::before {
  content: "\e012";
}
.z-icon-bars-progress::before {
  content: "\f828";
}
.z-icon-tasks-alt::before {
  content: "\f828";
}
.z-icon-faucet-drip::before {
  content: "\e006";
}
.z-icon-cart-flatbed::before {
  content: "\f474";
}
.z-icon-dolly-flatbed::before {
  content: "\f474";
}
.z-icon-ban-smoking::before {
  content: "\f54d";
}
.z-icon-smoking-ban::before {
  content: "\f54d";
}
.z-icon-terminal::before {
  content: "\f120";
}
.z-icon-mobile-button::before {
  content: "\f10b";
}
.z-icon-house-medical-flag::before {
  content: "\e514";
}
.z-icon-basket-shopping::before {
  content: "\f291";
}
.z-icon-shopping-basket::before {
  content: "\f291";
}
.z-icon-tape::before {
  content: "\f4db";
}
.z-icon-bus-simple::before {
  content: "\f55e";
}
.z-icon-bus-alt::before {
  content: "\f55e";
}
.z-icon-eye::before {
  content: "\f06e";
}
.z-icon-face-sad-cry::before {
  content: "\f5b3";
}
.z-icon-sad-cry::before {
  content: "\f5b3";
}
.z-icon-audio-description::before {
  content: "\f29e";
}
.z-icon-person-military-to-person::before {
  content: "\e54c";
}
.z-icon-file-shield::before {
  content: "\e4f0";
}
.z-icon-user-slash::before {
  content: "\f506";
}
.z-icon-pen::before {
  content: "\f304";
}
.z-icon-tower-observation::before {
  content: "\e586";
}
.z-icon-file-code::before {
  content: "\f1c9";
}
.z-icon-signal::before {
  content: "\f012";
}
.z-icon-signal-5::before {
  content: "\f012";
}
.z-icon-signal-perfect::before {
  content: "\f012";
}
.z-icon-bus::before {
  content: "\f207";
}
.z-icon-heart-circle-xmark::before {
  content: "\e501";
}
.z-icon-house-chimney::before {
  content: "\e3af";
}
.z-icon-home-lg::before {
  content: "\e3af";
}
.z-icon-window-maximize::before {
  content: "\f2d0";
}
.z-icon-face-frown::before {
  content: "\f119";
}
.z-icon-frown::before {
  content: "\f119";
}
.z-icon-prescription::before {
  content: "\f5b1";
}
.z-icon-shop::before {
  content: "\f54f";
}
.z-icon-store-alt::before {
  content: "\f54f";
}
.z-icon-floppy-disk::before {
  content: "\f0c7";
}
.z-icon-save::before {
  content: "\f0c7";
}
.z-icon-vihara::before {
  content: "\f6a7";
}
.z-icon-scale-unbalanced::before {
  content: "\f515";
}
.z-icon-balance-scale-left::before {
  content: "\f515";
}
.z-icon-sort-up::before {
  content: "\f0de";
}
.z-icon-sort-asc::before {
  content: "\f0de";
}
.z-icon-comment-dots::before {
  content: "\f4ad";
}
.z-icon-commenting::before {
  content: "\f4ad";
}
.z-icon-plant-wilt::before {
  content: "\e5aa";
}
.z-icon-diamond::before {
  content: "\f219";
}
.z-icon-face-grin-squint::before {
  content: "\f585";
}
.z-icon-grin-squint::before {
  content: "\f585";
}
.z-icon-hand-holding-dollar::before {
  content: "\f4c0";
}
.z-icon-hand-holding-usd::before {
  content: "\f4c0";
}
.z-icon-bacterium::before {
  content: "\e05a";
}
.z-icon-hand-pointer::before {
  content: "\f25a";
}
.z-icon-drum-steelpan::before {
  content: "\f56a";
}
.z-icon-hand-scissors::before {
  content: "\f257";
}
.z-icon-hands-praying::before {
  content: "\f684";
}
.z-icon-praying-hands::before {
  content: "\f684";
}
.z-icon-arrow-rotate-right::before {
  content: "\f01e";
}
.z-icon-arrow-right-rotate::before {
  content: "\f01e";
}
.z-icon-arrow-rotate-forward::before {
  content: "\f01e";
}
.z-icon-redo::before {
  content: "\f01e";
}
.z-icon-biohazard::before {
  content: "\f780";
}
.z-icon-location-crosshairs::before {
  content: "\f601";
}
.z-icon-location::before {
  content: "\f601";
}
.z-icon-mars-double::before {
  content: "\f227";
}
.z-icon-child-dress::before {
  content: "\e59c";
}
.z-icon-users-between-lines::before {
  content: "\e591";
}
.z-icon-lungs-virus::before {
  content: "\e067";
}
.z-icon-face-grin-tears::before {
  content: "\f588";
}
.z-icon-grin-tears::before {
  content: "\f588";
}
.z-icon-phone::before {
  content: "\f095";
}
.z-icon-calendar-xmark::before {
  content: "\f273";
}
.z-icon-calendar-times::before {
  content: "\f273";
}
.z-icon-child-reaching::before {
  content: "\e59d";
}
.z-icon-head-side-virus::before {
  content: "\e064";
}
.z-icon-user-gear::before {
  content: "\f4fe";
}
.z-icon-user-cog::before {
  content: "\f4fe";
}
.z-icon-arrow-up-1-9::before {
  content: "\f163";
}
.z-icon-sort-numeric-up::before {
  content: "\f163";
}
.z-icon-door-closed::before {
  content: "\f52a";
}
.z-icon-shield-virus::before {
  content: "\e06c";
}
.z-icon-dice-six::before {
  content: "\f526";
}
.z-icon-mosquito-net::before {
  content: "\e52c";
}
.z-icon-bridge-water::before {
  content: "\e4ce";
}
.z-icon-person-booth::before {
  content: "\f756";
}
.z-icon-text-width::before {
  content: "\f035";
}
.z-icon-hat-wizard::before {
  content: "\f6e8";
}
.z-icon-pen-fancy::before {
  content: "\f5ac";
}
.z-icon-person-digging::before {
  content: "\f85e";
}
.z-icon-digging::before {
  content: "\f85e";
}
.z-icon-trash::before {
  content: "\f1f8";
}
.z-icon-gauge-simple::before {
  content: "\f629";
}
.z-icon-gauge-simple-med::before {
  content: "\f629";
}
.z-icon-tachometer-average::before {
  content: "\f629";
}
.z-icon-book-medical::before {
  content: "\f7e6";
}
.z-icon-poo::before {
  content: "\f2fe";
}
.z-icon-quote-right::before {
  content: "\f10e";
}
.z-icon-quote-right-alt::before {
  content: "\f10e";
}
.z-icon-shirt::before {
  content: "\f553";
}
.z-icon-t-shirt::before {
  content: "\f553";
}
.z-icon-tshirt::before {
  content: "\f553";
}
.z-icon-cubes::before {
  content: "\f1b3";
}
.z-icon-divide::before {
  content: "\f529";
}
.z-icon-tenge-sign::before {
  content: "\f7d7";
}
.z-icon-tenge::before {
  content: "\f7d7";
}
.z-icon-headphones::before {
  content: "\f025";
}
.z-icon-hands-holding::before {
  content: "\f4c2";
}
.z-icon-hands-clapping::before {
  content: "\e1a8";
}
.z-icon-republican::before {
  content: "\f75e";
}
.z-icon-arrow-left::before {
  content: "\f060";
}
.z-icon-person-circle-xmark::before {
  content: "\e543";
}
.z-icon-ruler::before {
  content: "\f545";
}
.z-icon-align-left::before {
  content: "\f036";
}
.z-icon-dice-d6::before {
  content: "\f6d1";
}
.z-icon-restroom::before {
  content: "\f7bd";
}
.z-icon-j::before {
  content: "\4a";
}
.z-icon-users-viewfinder::before {
  content: "\e595";
}
.z-icon-file-video::before {
  content: "\f1c8";
}
.z-icon-up-right-from-square::before {
  content: "\f35d";
}
.z-icon-external-link-alt::before {
  content: "\f35d";
}
.z-icon-table-cells::before {
  content: "\f00a";
}
.z-icon-th::before {
  content: "\f00a";
}
.z-icon-file-pdf::before {
  content: "\f1c1";
}
.z-icon-book-bible::before {
  content: "\f647";
}
.z-icon-bible::before {
  content: "\f647";
}
.z-icon-o::before {
  content: "\4f";
}
.z-icon-suitcase-medical::before {
  content: "\f0fa";
}
.z-icon-medkit::before {
  content: "\f0fa";
}
.z-icon-user-secret::before {
  content: "\f21b";
}
.z-icon-otter::before {
  content: "\f700";
}
.z-icon-person-dress::before {
  content: "\f182";
}
.z-icon-female::before {
  content: "\f182";
}
.z-icon-comment-dollar::before {
  content: "\f651";
}
.z-icon-business-time::before {
  content: "\f64a";
}
.z-icon-briefcase-clock::before {
  content: "\f64a";
}
.z-icon-table-cells-large::before {
  content: "\f009";
}
.z-icon-th-large::before {
  content: "\f009";
}
.z-icon-book-tanakh::before {
  content: "\f827";
}
.z-icon-tanakh::before {
  content: "\f827";
}
.z-icon-phone-volume::before {
  content: "\f2a0";
}
.z-icon-volume-control-phone::before {
  content: "\f2a0";
}
.z-icon-hat-cowboy-side::before {
  content: "\f8c1";
}
.z-icon-clipboard-user::before {
  content: "\f7f3";
}
.z-icon-child::before {
  content: "\f1ae";
}
.z-icon-lira-sign::before {
  content: "\f195";
}
.z-icon-satellite::before {
  content: "\f7bf";
}
.z-icon-plane-lock::before {
  content: "\e558";
}
.z-icon-tag::before {
  content: "\f02b";
}
.z-icon-comment::before {
  content: "\f075";
}
.z-icon-cake-candles::before {
  content: "\f1fd";
}
.z-icon-birthday-cake::before {
  content: "\f1fd";
}
.z-icon-cake::before {
  content: "\f1fd";
}
.z-icon-envelope::before {
  content: "\f0e0";
}
.z-icon-angles-up::before {
  content: "\f102";
}
.z-icon-angle-double-up::before {
  content: "\f102";
}
.z-icon-paperclip::before {
  content: "\f0c6";
}
.z-icon-arrow-right-to-city::before {
  content: "\e4b3";
}
.z-icon-ribbon::before {
  content: "\f4d6";
}
.z-icon-lungs::before {
  content: "\f604";
}
.z-icon-arrow-up-9-1::before {
  content: "\f887";
}
.z-icon-sort-numeric-up-alt::before {
  content: "\f887";
}
.z-icon-litecoin-sign::before {
  content: "\e1d3";
}
.z-icon-border-none::before {
  content: "\f850";
}
.z-icon-circle-nodes::before {
  content: "\e4e2";
}
.z-icon-parachute-box::before {
  content: "\f4cd";
}
.z-icon-indent::before {
  content: "\f03c";
}
.z-icon-truck-field-un::before {
  content: "\e58e";
}
.z-icon-hourglass::before {
  content: "\f254";
}
.z-icon-hourglass-empty::before {
  content: "\f254";
}
.z-icon-mountain::before {
  content: "\f6fc";
}
.z-icon-user-doctor::before {
  content: "\f0f0";
}
.z-icon-user-md::before {
  content: "\f0f0";
}
.z-icon-circle-info::before {
  content: "\f05a";
}
.z-icon-info-circle::before {
  content: "\f05a";
}
.z-icon-cloud-meatball::before {
  content: "\f73b";
}
.z-icon-camera::before {
  content: "\f030";
}
.z-icon-camera-alt::before {
  content: "\f030";
}
.z-icon-square-virus::before {
  content: "\e578";
}
.z-icon-meteor::before {
  content: "\f753";
}
.z-icon-car-on::before {
  content: "\e4dd";
}
.z-icon-sleigh::before {
  content: "\f7cc";
}
.z-icon-arrow-down-1-9::before {
  content: "\f162";
}
.z-icon-sort-numeric-asc::before {
  content: "\f162";
}
.z-icon-sort-numeric-down::before {
  content: "\f162";
}
.z-icon-hand-holding-droplet::before {
  content: "\f4c1";
}
.z-icon-hand-holding-water::before {
  content: "\f4c1";
}
.z-icon-water::before {
  content: "\f773";
}
.z-icon-calendar-check::before {
  content: "\f274";
}
.z-icon-braille::before {
  content: "\f2a1";
}
.z-icon-prescription-bottle-medical::before {
  content: "\f486";
}
.z-icon-prescription-bottle-alt::before {
  content: "\f486";
}
.z-icon-landmark::before {
  content: "\f66f";
}
.z-icon-truck::before {
  content: "\f0d1";
}
.z-icon-crosshairs::before {
  content: "\f05b";
}
.z-icon-person-cane::before {
  content: "\e53c";
}
.z-icon-tent::before {
  content: "\e57d";
}
.z-icon-vest-patches::before {
  content: "\e086";
}
.z-icon-check-double::before {
  content: "\f560";
}
.z-icon-arrow-down-a-z::before {
  content: "\f15d";
}
.z-icon-sort-alpha-asc::before {
  content: "\f15d";
}
.z-icon-sort-alpha-down::before {
  content: "\f15d";
}
.z-icon-money-bill-wheat::before {
  content: "\e52a";
}
.z-icon-cookie::before {
  content: "\f563";
}
.z-icon-arrow-rotate-left::before {
  content: "\f0e2";
}
.z-icon-arrow-left-rotate::before {
  content: "\f0e2";
}
.z-icon-arrow-rotate-back::before {
  content: "\f0e2";
}
.z-icon-arrow-rotate-backward::before {
  content: "\f0e2";
}
.z-icon-undo::before {
  content: "\f0e2";
}
.z-icon-hard-drive::before {
  content: "\f0a0";
}
.z-icon-hdd::before {
  content: "\f0a0";
}
.z-icon-face-grin-squint-tears::before {
  content: "\f586";
}
.z-icon-grin-squint-tears::before {
  content: "\f586";
}
.z-icon-dumbbell::before {
  content: "\f44b";
}
.z-icon-rectangle-list::before {
  content: "\f022";
}
.z-icon-list-alt::before {
  content: "\f022";
}
.z-icon-tarp-droplet::before {
  content: "\e57c";
}
.z-icon-house-medical-circle-check::before {
  content: "\e511";
}
.z-icon-person-skiing-nordic::before {
  content: "\f7ca";
}
.z-icon-skiing-nordic::before {
  content: "\f7ca";
}
.z-icon-calendar-plus::before {
  content: "\f271";
}
.z-icon-plane-arrival::before {
  content: "\f5af";
}
.z-icon-circle-left::before {
  content: "\f359";
}
.z-icon-arrow-alt-circle-left::before {
  content: "\f359";
}
.z-icon-train-subway::before {
  content: "\f239";
}
.z-icon-subway::before {
  content: "\f239";
}
.z-icon-chart-gantt::before {
  content: "\e0e4";
}
.z-icon-indian-rupee-sign::before {
  content: "\e1bc";
}
.z-icon-indian-rupee::before {
  content: "\e1bc";
}
.z-icon-inr::before {
  content: "\e1bc";
}
.z-icon-crop-simple::before {
  content: "\f565";
}
.z-icon-crop-alt::before {
  content: "\f565";
}
.z-icon-money-bill-1::before {
  content: "\f3d1";
}
.z-icon-money-bill-alt::before {
  content: "\f3d1";
}
.z-icon-left-long::before {
  content: "\f30a";
}
.z-icon-long-arrow-alt-left::before {
  content: "\f30a";
}
.z-icon-dna::before {
  content: "\f471";
}
.z-icon-virus-slash::before {
  content: "\e075";
}
.z-icon-minus::before {
  content: "\f068";
}
.z-icon-subtract::before {
  content: "\f068";
}
.z-icon-chess::before {
  content: "\f439";
}
.z-icon-arrow-left-long::before {
  content: "\f177";
}
.z-icon-long-arrow-left::before {
  content: "\f177";
}
.z-icon-plug-circle-check::before {
  content: "\e55c";
}
.z-icon-street-view::before {
  content: "\f21d";
}
.z-icon-franc-sign::before {
  content: "\e18f";
}
.z-icon-volume-off::before {
  content: "\f026";
}
.z-icon-hands-asl-interpreting::before {
  content: "\f2a3";
}
.z-icon-american-sign-language-interpreting::before {
  content: "\f2a3";
}
.z-icon-asl-interpreting::before {
  content: "\f2a3";
}
.z-icon-hands-american-sign-language-interpreting::before {
  content: "\f2a3";
}
.z-icon-gear::before {
  content: "\f013";
}
.z-icon-cog::before {
  content: "\f013";
}
.z-icon-droplet-slash::before {
  content: "\f5c7";
}
.z-icon-tint-slash::before {
  content: "\f5c7";
}
.z-icon-mosque::before {
  content: "\f678";
}
.z-icon-mosquito::before {
  content: "\e52b";
}
.z-icon-star-of-david::before {
  content: "\f69a";
}
.z-icon-person-military-rifle::before {
  content: "\e54b";
}
.z-icon-cart-shopping::before {
  content: "\f07a";
}
.z-icon-shopping-cart::before {
  content: "\f07a";
}
.z-icon-vials::before {
  content: "\f493";
}
.z-icon-plug-circle-plus::before {
  content: "\e55f";
}
.z-icon-place-of-worship::before {
  content: "\f67f";
}
.z-icon-grip-vertical::before {
  content: "\f58e";
}
.z-icon-arrow-turn-up::before {
  content: "\f148";
}
.z-icon-level-up::before {
  content: "\f148";
}
.z-icon-u::before {
  content: "\55";
}
.z-icon-square-root-variable::before {
  content: "\f698";
}
.z-icon-square-root-alt::before {
  content: "\f698";
}
.z-icon-clock::before {
  content: "\f017";
}
.z-icon-clock-four::before {
  content: "\f017";
}
.z-icon-backward-step::before {
  content: "\f048";
}
.z-icon-step-backward::before {
  content: "\f048";
}
.z-icon-pallet::before {
  content: "\f482";
}
.z-icon-faucet::before {
  content: "\e005";
}
.z-icon-baseball-bat-ball::before {
  content: "\f432";
}
.z-icon-s::before {
  content: "\53";
}
.z-icon-timeline::before {
  content: "\e29c";
}
.z-icon-keyboard::before {
  content: "\f11c";
}
.z-icon-caret-down::before {
  content: "\f0d7";
}
.z-icon-house-chimney-medical::before {
  content: "\f7f2";
}
.z-icon-clinic-medical::before {
  content: "\f7f2";
}
.z-icon-temperature-three-quarters::before {
  content: "\f2c8";
}
.z-icon-temperature-3::before {
  content: "\f2c8";
}
.z-icon-thermometer-3::before {
  content: "\f2c8";
}
.z-icon-thermometer-three-quarters::before {
  content: "\f2c8";
}
.z-icon-mobile-screen::before {
  content: "\f3cf";
}
.z-icon-mobile-android-alt::before {
  content: "\f3cf";
}
.z-icon-plane-up::before {
  content: "\e22d";
}
.z-icon-piggy-bank::before {
  content: "\f4d3";
}
.z-icon-battery-half::before {
  content: "\f242";
}
.z-icon-battery-3::before {
  content: "\f242";
}
.z-icon-mountain-city::before {
  content: "\e52e";
}
.z-icon-coins::before {
  content: "\f51e";
}
.z-icon-khanda::before {
  content: "\f66d";
}
.z-icon-sliders::before {
  content: "\f1de";
}
.z-icon-sliders-h::before {
  content: "\f1de";
}
.z-icon-folder-tree::before {
  content: "\f802";
}
.z-icon-network-wired::before {
  content: "\f6ff";
}
.z-icon-map-pin::before {
  content: "\f276";
}
.z-icon-hamsa::before {
  content: "\f665";
}
.z-icon-cent-sign::before {
  content: "\e3f5";
}
.z-icon-flask::before {
  content: "\f0c3";
}
.z-icon-person-pregnant::before {
  content: "\e31e";
}
.z-icon-wand-sparkles::before {
  content: "\f72b";
}
.z-icon-ellipsis-vertical::before {
  content: "\f142";
}
.z-icon-ellipsis-v::before {
  content: "\f142";
}
.z-icon-ticket::before {
  content: "\f145";
}
.z-icon-power-off::before {
  content: "\f011";
}
.z-icon-right-long::before {
  content: "\f30b";
}
.z-icon-long-arrow-alt-right::before {
  content: "\f30b";
}
.z-icon-flag-usa::before {
  content: "\f74d";
}
.z-icon-laptop-file::before {
  content: "\e51d";
}
.z-icon-tty::before {
  content: "\f1e4";
}
.z-icon-teletype::before {
  content: "\f1e4";
}
.z-icon-diagram-next::before {
  content: "\e476";
}
.z-icon-person-rifle::before {
  content: "\e54e";
}
.z-icon-house-medical-circle-exclamation::before {
  content: "\e512";
}
.z-icon-closed-captioning::before {
  content: "\f20a";
}
.z-icon-person-hiking::before {
  content: "\f6ec";
}
.z-icon-hiking::before {
  content: "\f6ec";
}
.z-icon-venus-double::before {
  content: "\f226";
}
.z-icon-images::before {
  content: "\f302";
}
.z-icon-calculator::before {
  content: "\f1ec";
}
.z-icon-people-pulling::before {
  content: "\e535";
}
.z-icon-n::before {
  content: "\4e";
}
.z-icon-cable-car::before {
  content: "\f7da";
}
.z-icon-tram::before {
  content: "\f7da";
}
.z-icon-cloud-rain::before {
  content: "\f73d";
}
.z-icon-building-circle-xmark::before {
  content: "\e4d4";
}
.z-icon-ship::before {
  content: "\f21a";
}
.z-icon-arrows-down-to-line::before {
  content: "\e4b8";
}
.z-icon-download::before {
  content: "\f019";
}
.z-icon-face-grin::before {
  content: "\f580";
}
.z-icon-grin::before {
  content: "\f580";
}
.z-icon-delete-left::before {
  content: "\f55a";
}
.z-icon-backspace::before {
  content: "\f55a";
}
.z-icon-eye-dropper::before {
  content: "\f1fb";
}
.z-icon-eye-dropper-empty::before {
  content: "\f1fb";
}
.z-icon-eyedropper::before {
  content: "\f1fb";
}
.z-icon-file-circle-check::before {
  content: "\e5a0";
}
.z-icon-forward::before {
  content: "\f04e";
}
.z-icon-mobile::before {
  content: "\f3ce";
}
.z-icon-mobile-android::before {
  content: "\f3ce";
}
.z-icon-mobile-phone::before {
  content: "\f3ce";
}
.z-icon-face-meh::before {
  content: "\f11a";
}
.z-icon-meh::before {
  content: "\f11a";
}
.z-icon-align-center::before {
  content: "\f037";
}
.z-icon-book-skull::before {
  content: "\f6b7";
}
.z-icon-book-dead::before {
  content: "\f6b7";
}
.z-icon-id-card::before {
  content: "\f2c2";
}
.z-icon-drivers-license::before {
  content: "\f2c2";
}
.z-icon-outdent::before {
  content: "\f03b";
}
.z-icon-dedent::before {
  content: "\f03b";
}
.z-icon-heart-circle-exclamation::before {
  content: "\e4fe";
}
.z-icon-house::before {
  content: "\f015";
}
.z-icon-home::before {
  content: "\f015";
}
.z-icon-home-alt::before {
  content: "\f015";
}
.z-icon-home-lg-alt::before {
  content: "\f015";
}
.z-icon-calendar-week::before {
  content: "\f784";
}
.z-icon-laptop-medical::before {
  content: "\f812";
}
.z-icon-b::before {
  content: "\42";
}
.z-icon-file-medical::before {
  content: "\f477";
}
.z-icon-dice-one::before {
  content: "\f525";
}
.z-icon-kiwi-bird::before {
  content: "\f535";
}
.z-icon-arrow-right-arrow-left::before {
  content: "\f0ec";
}
.z-icon-exchange::before {
  content: "\f0ec";
}
.z-icon-rotate-right::before {
  content: "\f2f9";
}
.z-icon-redo-alt::before {
  content: "\f2f9";
}
.z-icon-rotate-forward::before {
  content: "\f2f9";
}
.z-icon-utensils::before {
  content: "\f2e7";
}
.z-icon-cutlery::before {
  content: "\f2e7";
}
.z-icon-arrow-up-wide-short::before {
  content: "\f161";
}
.z-icon-sort-amount-up::before {
  content: "\f161";
}
.z-icon-mill-sign::before {
  content: "\e1ed";
}
.z-icon-bowl-rice::before {
  content: "\e2eb";
}
.z-icon-skull::before {
  content: "\f54c";
}
.z-icon-tower-broadcast::before {
  content: "\f519";
}
.z-icon-broadcast-tower::before {
  content: "\f519";
}
.z-icon-truck-pickup::before {
  content: "\f63c";
}
.z-icon-up-long::before {
  content: "\f30c";
}
.z-icon-long-arrow-alt-up::before {
  content: "\f30c";
}
.z-icon-stop::before {
  content: "\f04d";
}
.z-icon-code-merge::before {
  content: "\f387";
}
.z-icon-upload::before {
  content: "\f093";
}
.z-icon-hurricane::before {
  content: "\f751";
}
.z-icon-mound::before {
  content: "\e52d";
}
.z-icon-toilet-portable::before {
  content: "\e583";
}
.z-icon-compact-disc::before {
  content: "\f51f";
}
.z-icon-file-arrow-down::before {
  content: "\f56d";
}
.z-icon-file-download::before {
  content: "\f56d";
}
.z-icon-caravan::before {
  content: "\f8ff";
}
.z-icon-shield-cat::before {
  content: "\e572";
}
.z-icon-bolt::before {
  content: "\f0e7";
}
.z-icon-zap::before {
  content: "\f0e7";
}
.z-icon-glass-water::before {
  content: "\e4f4";
}
.z-icon-oil-well::before {
  content: "\e532";
}
.z-icon-vault::before {
  content: "\e2c5";
}
.z-icon-mars::before {
  content: "\f222";
}
.z-icon-toilet::before {
  content: "\f7d8";
}
.z-icon-plane-circle-xmark::before {
  content: "\e557";
}
.z-icon-yen-sign::before {
  content: "\f157";
}
.z-icon-cny::before {
  content: "\f157";
}
.z-icon-jpy::before {
  content: "\f157";
}
.z-icon-rmb::before {
  content: "\f157";
}
.z-icon-yen::before {
  content: "\f157";
}
.z-icon-ruble-sign::before {
  content: "\f158";
}
.z-icon-rouble::before {
  content: "\f158";
}
.z-icon-rub::before {
  content: "\f158";
}
.z-icon-ruble::before {
  content: "\f158";
}
.z-icon-sun::before {
  content: "\f185";
}
.z-icon-guitar::before {
  content: "\f7a6";
}
.z-icon-face-laugh-wink::before {
  content: "\f59c";
}
.z-icon-laugh-wink::before {
  content: "\f59c";
}
.z-icon-horse-head::before {
  content: "\f7ab";
}
.z-icon-bore-hole::before {
  content: "\e4c3";
}
.z-icon-industry::before {
  content: "\f275";
}
.z-icon-circle-down::before {
  content: "\f358";
}
.z-icon-arrow-alt-circle-down::before {
  content: "\f358";
}
.z-icon-arrows-turn-to-dots::before {
  content: "\e4c1";
}
.z-icon-florin-sign::before {
  content: "\e184";
}
.z-icon-arrow-down-short-wide::before {
  content: "\f884";
}
.z-icon-sort-amount-desc::before {
  content: "\f884";
}
.z-icon-sort-amount-down-alt::before {
  content: "\f884";
}
.z-icon-less-than::before {
  content: "\3c";
}
.z-icon-angle-down::before {
  content: "\f107";
}
.z-icon-car-tunnel::before {
  content: "\e4de";
}
.z-icon-head-side-cough::before {
  content: "\e061";
}
.z-icon-grip-lines::before {
  content: "\f7a4";
}
.z-icon-thumbs-down::before {
  content: "\f165";
}
.z-icon-user-lock::before {
  content: "\f502";
}
.z-icon-arrow-right-long::before {
  content: "\f178";
}
.z-icon-long-arrow-right::before {
  content: "\f178";
}
.z-icon-anchor-circle-xmark::before {
  content: "\e4ac";
}
.z-icon-ellipsis::before {
  content: "\f141";
}
.z-icon-ellipsis-h::before {
  content: "\f141";
}
.z-icon-chess-pawn::before {
  content: "\f443";
}
.z-icon-kit-medical::before {
  content: "\f479";
}
.z-icon-first-aid::before {
  content: "\f479";
}
.z-icon-person-through-window::before {
  content: "\e5a9";
}
.z-icon-toolbox::before {
  content: "\f552";
}
.z-icon-hands-holding-circle::before {
  content: "\e4fb";
}
.z-icon-bug::before {
  content: "\f188";
}
.z-icon-credit-card::before {
  content: "\f09d";
}
.z-icon-credit-card-alt::before {
  content: "\f09d";
}
.z-icon-car::before {
  content: "\f1b9";
}
.z-icon-automobile::before {
  content: "\f1b9";
}
.z-icon-hand-holding-hand::before {
  content: "\e4f7";
}
.z-icon-book-open-reader::before {
  content: "\f5da";
}
.z-icon-book-reader::before {
  content: "\f5da";
}
.z-icon-mountain-sun::before {
  content: "\e52f";
}
.z-icon-arrows-left-right-to-line::before {
  content: "\e4ba";
}
.z-icon-dice-d20::before {
  content: "\f6cf";
}
.z-icon-truck-droplet::before {
  content: "\e58c";
}
.z-icon-file-circle-xmark::before {
  content: "\e5a1";
}
.z-icon-temperature-arrow-up::before {
  content: "\e040";
}
.z-icon-temperature-up::before {
  content: "\e040";
}
.z-icon-medal::before {
  content: "\f5a2";
}
.z-icon-bed::before {
  content: "\f236";
}
.z-icon-square-h::before {
  content: "\f0fd";
}
.z-icon-h-square::before {
  content: "\f0fd";
}
.z-icon-podcast::before {
  content: "\f2ce";
}
.z-icon-temperature-full::before {
  content: "\f2c7";
}
.z-icon-temperature-4::before {
  content: "\f2c7";
}
.z-icon-thermometer-4::before {
  content: "\f2c7";
}
.z-icon-thermometer-full::before {
  content: "\f2c7";
}
.z-icon-bell::before {
  content: "\f0f3";
}
.z-icon-superscript::before {
  content: "\f12b";
}
.z-icon-plug-circle-xmark::before {
  content: "\e560";
}
.z-icon-star-of-life::before {
  content: "\f621";
}
.z-icon-phone-slash::before {
  content: "\f3dd";
}
.z-icon-paint-roller::before {
  content: "\f5aa";
}
.z-icon-handshake-angle::before {
  content: "\f4c4";
}
.z-icon-hands-helping::before {
  content: "\f4c4";
}
.z-icon-location-dot::before {
  content: "\f3c5";
}
.z-icon-map-marker-alt::before {
  content: "\f3c5";
}
.z-icon-file::before {
  content: "\f15b";
}
.z-icon-greater-than::before {
  content: "\3e";
}
.z-icon-person-swimming::before {
  content: "\f5c4";
}
.z-icon-swimmer::before {
  content: "\f5c4";
}
.z-icon-arrow-down::before {
  content: "\f063";
}
.z-icon-droplet::before {
  content: "\f043";
}
.z-icon-tint::before {
  content: "\f043";
}
.z-icon-eraser::before {
  content: "\f12d";
}
.z-icon-earth-americas::before {
  content: "\f57d";
}
.z-icon-earth::before {
  content: "\f57d";
}
.z-icon-earth-america::before {
  content: "\f57d";
}
.z-icon-globe-americas::before {
  content: "\f57d";
}
.z-icon-person-burst::before {
  content: "\e53b";
}
.z-icon-dove::before {
  content: "\f4ba";
}
.z-icon-battery-empty::before {
  content: "\f244";
}
.z-icon-battery-0::before {
  content: "\f244";
}
.z-icon-socks::before {
  content: "\f696";
}
.z-icon-inbox::before {
  content: "\f01c";
}
.z-icon-section::before {
  content: "\e447";
}
.z-icon-gauge-high::before {
  content: "\f625";
}
.z-icon-tachometer-alt::before {
  content: "\f625";
}
.z-icon-tachometer-alt-fast::before {
  content: "\f625";
}
.z-icon-envelope-open-text::before {
  content: "\f658";
}
.z-icon-hospital::before {
  content: "\f0f8";
}
.z-icon-hospital-alt::before {
  content: "\f0f8";
}
.z-icon-hospital-wide::before {
  content: "\f0f8";
}
.z-icon-wine-bottle::before {
  content: "\f72f";
}
.z-icon-chess-rook::before {
  content: "\f447";
}
.z-icon-bars-staggered::before {
  content: "\f550";
}
.z-icon-reorder::before {
  content: "\f550";
}
.z-icon-stream::before {
  content: "\f550";
}
.z-icon-dharmachakra::before {
  content: "\f655";
}
.z-icon-hotdog::before {
  content: "\f80f";
}
.z-icon-person-walking-with-cane::before {
  content: "\f29d";
}
.z-icon-blind::before {
  content: "\f29d";
}
.z-icon-drum::before {
  content: "\f569";
}
.z-icon-ice-cream::before {
  content: "\f810";
}
.z-icon-heart-circle-bolt::before {
  content: "\e4fc";
}
.z-icon-fax::before {
  content: "\f1ac";
}
.z-icon-paragraph::before {
  content: "\f1dd";
}
.z-icon-check-to-slot::before {
  content: "\f772";
}
.z-icon-vote-yea::before {
  content: "\f772";
}
.z-icon-star-half::before {
  content: "\f089";
}
.z-icon-boxes-stacked::before {
  content: "\f468";
}
.z-icon-boxes::before {
  content: "\f468";
}
.z-icon-boxes-alt::before {
  content: "\f468";
}
.z-icon-link::before {
  content: "\f0c1";
}
.z-icon-chain::before {
  content: "\f0c1";
}
.z-icon-ear-listen::before {
  content: "\f2a2";
}
.z-icon-assistive-listening-systems::before {
  content: "\f2a2";
}
.z-icon-tree-city::before {
  content: "\e587";
}
.z-icon-play::before {
  content: "\f04b";
}
.z-icon-font::before {
  content: "\f031";
}
.z-icon-rupiah-sign::before {
  content: "\e23d";
}
.z-icon-magnifying-glass::before {
  content: "\f002";
}
.z-icon-search::before {
  content: "\f002";
}
.z-icon-table-tennis-paddle-ball::before {
  content: "\f45d";
}
.z-icon-ping-pong-paddle-ball::before {
  content: "\f45d";
}
.z-icon-table-tennis::before {
  content: "\f45d";
}
.z-icon-person-dots-from-line::before {
  content: "\f470";
}
.z-icon-diagnoses::before {
  content: "\f470";
}
.z-icon-trash-can-arrow-up::before {
  content: "\f82a";
}
.z-icon-trash-restore-alt::before {
  content: "\f82a";
}
.z-icon-naira-sign::before {
  content: "\e1f6";
}
.z-icon-cart-arrow-down::before {
  content: "\f218";
}
.z-icon-walkie-talkie::before {
  content: "\f8ef";
}
.z-icon-file-pen::before {
  content: "\f31c";
}
.z-icon-file-edit::before {
  content: "\f31c";
}
.z-icon-receipt::before {
  content: "\f543";
}
.z-icon-square-pen::before {
  content: "\f14b";
}
.z-icon-pen-square::before {
  content: "\f14b";
}
.z-icon-pencil-square::before {
  content: "\f14b";
}
.z-icon-suitcase-rolling::before {
  content: "\f5c1";
}
.z-icon-person-circle-exclamation::before {
  content: "\e53f";
}
.z-icon-chevron-down::before {
  content: "\f078";
}
.z-icon-battery-full::before {
  content: "\f240";
}
.z-icon-battery::before {
  content: "\f240";
}
.z-icon-battery-5::before {
  content: "\f240";
}
.z-icon-skull-crossbones::before {
  content: "\f714";
}
.z-icon-code-compare::before {
  content: "\e13a";
}
.z-icon-list-ul::before {
  content: "\f0ca";
}
.z-icon-list-dots::before {
  content: "\f0ca";
}
.z-icon-school-lock::before {
  content: "\e56f";
}
.z-icon-tower-cell::before {
  content: "\e585";
}
.z-icon-down-long::before {
  content: "\f309";
}
.z-icon-long-arrow-alt-down::before {
  content: "\f309";
}
.z-icon-ranking-star::before {
  content: "\e561";
}
.z-icon-chess-king::before {
  content: "\f43f";
}
.z-icon-person-harassing::before {
  content: "\e549";
}
.z-icon-brazilian-real-sign::before {
  content: "\e46c";
}
.z-icon-landmark-dome::before {
  content: "\f752";
}
.z-icon-landmark-alt::before {
  content: "\f752";
}
.z-icon-arrow-up::before {
  content: "\f062";
}
.z-icon-tv::before {
  content: "\f26c";
}
.z-icon-television::before {
  content: "\f26c";
}
.z-icon-tv-alt::before {
  content: "\f26c";
}
.z-icon-shrimp::before {
  content: "\e448";
}
.z-icon-list-check::before {
  content: "\f0ae";
}
.z-icon-tasks::before {
  content: "\f0ae";
}
.z-icon-jug-detergent::before {
  content: "\e519";
}
.z-icon-circle-user::before {
  content: "\f2bd";
}
.z-icon-user-circle::before {
  content: "\f2bd";
}
.z-icon-user-shield::before {
  content: "\f505";
}
.z-icon-wind::before {
  content: "\f72e";
}
.z-icon-car-burst::before {
  content: "\f5e1";
}
.z-icon-car-crash::before {
  content: "\f5e1";
}
.z-icon-y::before {
  content: "\59";
}
.z-icon-person-snowboarding::before {
  content: "\f7ce";
}
.z-icon-snowboarding::before {
  content: "\f7ce";
}
.z-icon-truck-fast::before {
  content: "\f48b";
}
.z-icon-shipping-fast::before {
  content: "\f48b";
}
.z-icon-fish::before {
  content: "\f578";
}
.z-icon-user-graduate::before {
  content: "\f501";
}
.z-icon-circle-half-stroke::before {
  content: "\f042";
}
.z-icon-adjust::before {
  content: "\f042";
}
.z-icon-clapperboard::before {
  content: "\e131";
}
.z-icon-circle-radiation::before {
  content: "\f7ba";
}
.z-icon-radiation-alt::before {
  content: "\f7ba";
}
.z-icon-baseball::before {
  content: "\f433";
}
.z-icon-baseball-ball::before {
  content: "\f433";
}
.z-icon-jet-fighter-up::before {
  content: "\e518";
}
.z-icon-diagram-project::before {
  content: "\f542";
}
.z-icon-project-diagram::before {
  content: "\f542";
}
.z-icon-copy::before {
  content: "\f0c5";
}
.z-icon-volume-xmark::before {
  content: "\f6a9";
}
.z-icon-volume-mute::before {
  content: "\f6a9";
}
.z-icon-volume-times::before {
  content: "\f6a9";
}
.z-icon-hand-sparkles::before {
  content: "\e05d";
}
.z-icon-grip::before {
  content: "\f58d";
}
.z-icon-grip-horizontal::before {
  content: "\f58d";
}
.z-icon-share-from-square::before {
  content: "\f14d";
}
.z-icon-share-square::before {
  content: "\f14d";
}
.z-icon-child-combatant::before {
  content: "\e4e0";
}
.z-icon-child-rifle::before {
  content: "\e4e0";
}
.z-icon-gun::before {
  content: "\e19b";
}
.z-icon-square-phone::before {
  content: "\f098";
}
.z-icon-phone-square::before {
  content: "\f098";
}
.z-icon-plus::before {
  content: "\2b";
}
.z-icon-add::before {
  content: "\2b";
}
.z-icon-expand::before {
  content: "\f065";
}
.z-icon-computer::before {
  content: "\e4e5";
}
.z-icon-xmark::before {
  content: "\f00d";
}
.z-icon-close::before {
  content: "\f00d";
}
.z-icon-multiply::before {
  content: "\f00d";
}
.z-icon-remove::before {
  content: "\f00d";
}
.z-icon-times::before {
  content: "\f00d";
}
.z-icon-arrows-up-down-left-right::before {
  content: "\f047";
}
.z-icon-arrows::before {
  content: "\f047";
}
.z-icon-chalkboard-user::before {
  content: "\f51c";
}
.z-icon-chalkboard-teacher::before {
  content: "\f51c";
}
.z-icon-peso-sign::before {
  content: "\e222";
}
.z-icon-building-shield::before {
  content: "\e4d8";
}
.z-icon-baby::before {
  content: "\f77c";
}
.z-icon-users-line::before {
  content: "\e592";
}
.z-icon-quote-left::before {
  content: "\f10d";
}
.z-icon-quote-left-alt::before {
  content: "\f10d";
}
.z-icon-tractor::before {
  content: "\f722";
}
.z-icon-trash-arrow-up::before {
  content: "\f829";
}
.z-icon-trash-restore::before {
  content: "\f829";
}
.z-icon-arrow-down-up-lock::before {
  content: "\e4b0";
}
.z-icon-lines-leaning::before {
  content: "\e51e";
}
.z-icon-ruler-combined::before {
  content: "\f546";
}
.z-icon-copyright::before {
  content: "\f1f9";
}
.z-icon-equals::before {
  content: "\3d";
}
.z-icon-blender::before {
  content: "\f517";
}
.z-icon-teeth::before {
  content: "\f62e";
}
.z-icon-shekel-sign::before {
  content: "\f20b";
}
.z-icon-ils::before {
  content: "\f20b";
}
.z-icon-shekel::before {
  content: "\f20b";
}
.z-icon-sheqel::before {
  content: "\f20b";
}
.z-icon-sheqel-sign::before {
  content: "\f20b";
}
.z-icon-map::before {
  content: "\f279";
}
.z-icon-rocket::before {
  content: "\f135";
}
.z-icon-photo-film::before {
  content: "\f87c";
}
.z-icon-photo-video::before {
  content: "\f87c";
}
.z-icon-folder-minus::before {
  content: "\f65d";
}
.z-icon-store::before {
  content: "\f54e";
}
.z-icon-arrow-trend-up::before {
  content: "\e098";
}
.z-icon-plug-circle-minus::before {
  content: "\e55e";
}
.z-icon-sign-hanging::before {
  content: "\f4d9";
}
.z-icon-sign::before {
  content: "\f4d9";
}
.z-icon-bezier-curve::before {
  content: "\f55b";
}
.z-icon-bell-slash::before {
  content: "\f1f6";
}
.z-icon-tablet::before {
  content: "\f3fb";
}
.z-icon-tablet-android::before {
  content: "\f3fb";
}
.z-icon-school-flag::before {
  content: "\e56e";
}
.z-icon-fill::before {
  content: "\f575";
}
.z-icon-angle-up::before {
  content: "\f106";
}
.z-icon-drumstick-bite::before {
  content: "\f6d7";
}
.z-icon-holly-berry::before {
  content: "\f7aa";
}
.z-icon-chevron-left::before {
  content: "\f053";
}
.z-icon-bacteria::before {
  content: "\e059";
}
.z-icon-hand-lizard::before {
  content: "\f258";
}
.z-icon-notdef::before {
  content: "\e1fe";
}
.z-icon-disease::before {
  content: "\f7fa";
}
.z-icon-briefcase-medical::before {
  content: "\f469";
}
.z-icon-genderless::before {
  content: "\f22d";
}
.z-icon-chevron-right::before {
  content: "\f054";
}
.z-icon-retweet::before {
  content: "\f079";
}
.z-icon-car-rear::before {
  content: "\f5de";
}
.z-icon-car-alt::before {
  content: "\f5de";
}
.z-icon-pump-soap::before {
  content: "\e06b";
}
.z-icon-video-slash::before {
  content: "\f4e2";
}
.z-icon-battery-quarter::before {
  content: "\f243";
}
.z-icon-battery-2::before {
  content: "\f243";
}
.z-icon-radio::before {
  content: "\f8d7";
}
.z-icon-baby-carriage::before {
  content: "\f77d";
}
.z-icon-carriage-baby::before {
  content: "\f77d";
}
.z-icon-traffic-light::before {
  content: "\f637";
}
.z-icon-thermometer::before {
  content: "\f491";
}
.z-icon-vr-cardboard::before {
  content: "\f729";
}
.z-icon-hand-middle-finger::before {
  content: "\f806";
}
.z-icon-percent::before {
  content: "\25";
}
.z-icon-percentage::before {
  content: "\25";
}
.z-icon-truck-moving::before {
  content: "\f4df";
}
.z-icon-glass-water-droplet::before {
  content: "\e4f5";
}
.z-icon-display::before {
  content: "\e163";
}
.z-icon-face-smile::before {
  content: "\f118";
}
.z-icon-smile::before {
  content: "\f118";
}
.z-icon-thumbtack::before {
  content: "\f08d";
}
.z-icon-thumb-tack::before {
  content: "\f08d";
}
.z-icon-trophy::before {
  content: "\f091";
}
.z-icon-person-praying::before {
  content: "\f683";
}
.z-icon-pray::before {
  content: "\f683";
}
.z-icon-hammer::before {
  content: "\f6e3";
}
.z-icon-hand-peace::before {
  content: "\f25b";
}
.z-icon-rotate::before {
  content: "\f2f1";
}
.z-icon-sync-alt::before {
  content: "\f2f1";
}
.z-icon-spinner::before {
  content: "\f110";
}
.z-icon-robot::before {
  content: "\f544";
}
.z-icon-peace::before {
  content: "\f67c";
}
.z-icon-gears::before {
  content: "\f085";
}
.z-icon-cogs::before {
  content: "\f085";
}
.z-icon-warehouse::before {
  content: "\f494";
}
.z-icon-arrow-up-right-dots::before {
  content: "\e4b7";
}
.z-icon-splotch::before {
  content: "\f5bc";
}
.z-icon-face-grin-hearts::before {
  content: "\f584";
}
.z-icon-grin-hearts::before {
  content: "\f584";
}
.z-icon-dice-four::before {
  content: "\f524";
}
.z-icon-sim-card::before {
  content: "\f7c4";
}
.z-icon-transgender::before {
  content: "\f225";
}
.z-icon-transgender-alt::before {
  content: "\f225";
}
.z-icon-mercury::before {
  content: "\f223";
}
.z-icon-arrow-turn-down::before {
  content: "\f149";
}
.z-icon-level-down::before {
  content: "\f149";
}
.z-icon-person-falling-burst::before {
  content: "\e547";
}
.z-icon-award::before {
  content: "\f559";
}
.z-icon-ticket-simple::before {
  content: "\f3ff";
}
.z-icon-ticket-alt::before {
  content: "\f3ff";
}
.z-icon-building::before {
  content: "\f1ad";
}
.z-icon-angles-left::before {
  content: "\f100";
}
.z-icon-angle-double-left::before {
  content: "\f100";
}
.z-icon-qrcode::before {
  content: "\f029";
}
.z-icon-clock-rotate-left::before {
  content: "\f1da";
}
.z-icon-history::before {
  content: "\f1da";
}
.z-icon-face-grin-beam-sweat::before {
  content: "\f583";
}
.z-icon-grin-beam-sweat::before {
  content: "\f583";
}
.z-icon-file-export::before {
  content: "\f56e";
}
.z-icon-arrow-right-from-file::before {
  content: "\f56e";
}
.z-icon-shield::before {
  content: "\f132";
}
.z-icon-shield-blank::before {
  content: "\f132";
}
.z-icon-arrow-up-short-wide::before {
  content: "\f885";
}
.z-icon-sort-amount-up-alt::before {
  content: "\f885";
}
.z-icon-house-medical::before {
  content: "\e3b2";
}
.z-icon-golf-ball-tee::before {
  content: "\f450";
}
.z-icon-golf-ball::before {
  content: "\f450";
}
.z-icon-circle-chevron-left::before {
  content: "\f137";
}
.z-icon-chevron-circle-left::before {
  content: "\f137";
}
.z-icon-house-chimney-window::before {
  content: "\e00d";
}
.z-icon-pen-nib::before {
  content: "\f5ad";
}
.z-icon-tent-arrow-turn-left::before {
  content: "\e580";
}
.z-icon-tents::before {
  content: "\e582";
}
.z-icon-wand-magic::before {
  content: "\f0d0";
}
.z-icon-magic::before {
  content: "\f0d0";
}
.z-icon-dog::before {
  content: "\f6d3";
}
.z-icon-carrot::before {
  content: "\f787";
}
.z-icon-moon::before {
  content: "\f186";
}
.z-icon-wine-glass-empty::before {
  content: "\f5ce";
}
.z-icon-wine-glass-alt::before {
  content: "\f5ce";
}
.z-icon-cheese::before {
  content: "\f7ef";
}
.z-icon-yin-yang::before {
  content: "\f6ad";
}
.z-icon-music::before {
  content: "\f001";
}
.z-icon-code-commit::before {
  content: "\f386";
}
.z-icon-temperature-low::before {
  content: "\f76b";
}
.z-icon-person-biking::before {
  content: "\f84a";
}
.z-icon-biking::before {
  content: "\f84a";
}
.z-icon-broom::before {
  content: "\f51a";
}
.z-icon-shield-heart::before {
  content: "\e574";
}
.z-icon-gopuram::before {
  content: "\f664";
}
.z-icon-earth-oceania::before {
  content: "\e47b";
}
.z-icon-globe-oceania::before {
  content: "\e47b";
}
.z-icon-square-xmark::before {
  content: "\f2d3";
}
.z-icon-times-square::before {
  content: "\f2d3";
}
.z-icon-xmark-square::before {
  content: "\f2d3";
}
.z-icon-hashtag::before {
  content: "\23";
}
.z-icon-up-right-and-down-left-from-center::before {
  content: "\f424";
}
.z-icon-expand-alt::before {
  content: "\f424";
}
.z-icon-oil-can::before {
  content: "\f613";
}
.z-icon-t::before {
  content: "\54";
}
.z-icon-hippo::before {
  content: "\f6ed";
}
.z-icon-chart-column::before {
  content: "\e0e3";
}
.z-icon-infinity::before {
  content: "\f534";
}
.z-icon-vial-circle-check::before {
  content: "\e596";
}
.z-icon-person-arrow-down-to-line::before {
  content: "\e538";
}
.z-icon-voicemail::before {
  content: "\f897";
}
.z-icon-fan::before {
  content: "\f863";
}
.z-icon-person-walking-luggage::before {
  content: "\e554";
}
.z-icon-up-down::before {
  content: "\f338";
}
.z-icon-arrows-alt-v::before {
  content: "\f338";
}
.z-icon-cloud-moon-rain::before {
  content: "\f73c";
}
.z-icon-calendar::before {
  content: "\f133";
}
.z-icon-trailer::before {
  content: "\e041";
}
.z-icon-bahai::before {
  content: "\f666";
}
.z-icon-haykal::before {
  content: "\f666";
}
.z-icon-sd-card::before {
  content: "\f7c2";
}
.z-icon-dragon::before {
  content: "\f6d5";
}
.z-icon-shoe-prints::before {
  content: "\f54b";
}
.z-icon-circle-plus::before {
  content: "\f055";
}
.z-icon-plus-circle::before {
  content: "\f055";
}
.z-icon-face-grin-tongue-wink::before {
  content: "\f58b";
}
.z-icon-grin-tongue-wink::before {
  content: "\f58b";
}
.z-icon-hand-holding::before {
  content: "\f4bd";
}
.z-icon-plug-circle-exclamation::before {
  content: "\e55d";
}
.z-icon-link-slash::before {
  content: "\f127";
}
.z-icon-chain-broken::before {
  content: "\f127";
}
.z-icon-chain-slash::before {
  content: "\f127";
}
.z-icon-unlink::before {
  content: "\f127";
}
.z-icon-clone::before {
  content: "\f24d";
}
.z-icon-person-walking-arrow-loop-left::before {
  content: "\e551";
}
.z-icon-arrow-up-z-a::before {
  content: "\f882";
}
.z-icon-sort-alpha-up-alt::before {
  content: "\f882";
}
.z-icon-fire-flame-curved::before {
  content: "\f7e4";
}
.z-icon-fire-alt::before {
  content: "\f7e4";
}
.z-icon-tornado::before {
  content: "\f76f";
}
.z-icon-file-circle-plus::before {
  content: "\e494";
}
.z-icon-book-quran::before {
  content: "\f687";
}
.z-icon-quran::before {
  content: "\f687";
}
.z-icon-anchor::before {
  content: "\f13d";
}
.z-icon-border-all::before {
  content: "\f84c";
}
.z-icon-face-angry::before {
  content: "\f556";
}
.z-icon-angry::before {
  content: "\f556";
}
.z-icon-cookie-bite::before {
  content: "\f564";
}
.z-icon-arrow-trend-down::before {
  content: "\e097";
}
.z-icon-rss::before {
  content: "\f09e";
}
.z-icon-feed::before {
  content: "\f09e";
}
.z-icon-draw-polygon::before {
  content: "\f5ee";
}
.z-icon-scale-balanced::before {
  content: "\f24e";
}
.z-icon-balance-scale::before {
  content: "\f24e";
}
.z-icon-gauge-simple-high::before {
  content: "\f62a";
}
.z-icon-tachometer::before {
  content: "\f62a";
}
.z-icon-tachometer-fast::before {
  content: "\f62a";
}
.z-icon-shower::before {
  content: "\f2cc";
}
.z-icon-desktop::before {
  content: "\f390";
}
.z-icon-desktop-alt::before {
  content: "\f390";
}
.z-icon-m::before {
  content: "\4d";
}
.z-icon-table-list::before {
  content: "\f00b";
}
.z-icon-th-list::before {
  content: "\f00b";
}
.z-icon-comment-sms::before {
  content: "\f7cd";
}
.z-icon-sms::before {
  content: "\f7cd";
}
.z-icon-book::before {
  content: "\f02d";
}
.z-icon-user-plus::before {
  content: "\f234";
}
.z-icon-check::before {
  content: "\f00c";
}
.z-icon-battery-three-quarters::before {
  content: "\f241";
}
.z-icon-battery-4::before {
  content: "\f241";
}
.z-icon-house-circle-check::before {
  content: "\e509";
}
.z-icon-angle-left::before {
  content: "\f104";
}
.z-icon-diagram-successor::before {
  content: "\e47a";
}
.z-icon-truck-arrow-right::before {
  content: "\e58b";
}
.z-icon-arrows-split-up-and-left::before {
  content: "\e4bc";
}
.z-icon-hand-fist::before {
  content: "\f6de";
}
.z-icon-fist-raised::before {
  content: "\f6de";
}
.z-icon-cloud-moon::before {
  content: "\f6c3";
}
.z-icon-briefcase::before {
  content: "\f0b1";
}
.z-icon-person-falling::before {
  content: "\e546";
}
.z-icon-image-portrait::before {
  content: "\f3e0";
}
.z-icon-portrait::before {
  content: "\f3e0";
}
.z-icon-user-tag::before {
  content: "\f507";
}
.z-icon-rug::before {
  content: "\e569";
}
.z-icon-earth-europe::before {
  content: "\f7a2";
}
.z-icon-globe-europe::before {
  content: "\f7a2";
}
.z-icon-cart-flatbed-suitcase::before {
  content: "\f59d";
}
.z-icon-luggage-cart::before {
  content: "\f59d";
}
.z-icon-rectangle-xmark::before {
  content: "\f410";
}
.z-icon-rectangle-times::before {
  content: "\f410";
}
.z-icon-times-rectangle::before {
  content: "\f410";
}
.z-icon-window-close::before {
  content: "\f410";
}
.z-icon-baht-sign::before {
  content: "\e0ac";
}
.z-icon-book-open::before {
  content: "\f518";
}
.z-icon-book-journal-whills::before {
  content: "\f66a";
}
.z-icon-journal-whills::before {
  content: "\f66a";
}
.z-icon-handcuffs::before {
  content: "\e4f8";
}
.z-icon-triangle-exclamation::before {
  content: "\f071";
}
.z-icon-exclamation-triangle::before {
  content: "\f071";
}
.z-icon-warning::before {
  content: "\f071";
}
.z-icon-database::before {
  content: "\f1c0";
}
.z-icon-share::before {
  content: "\f064";
}
.z-icon-arrow-turn-right::before {
  content: "\f064";
}
.z-icon-mail-forward::before {
  content: "\f064";
}
.z-icon-bottle-droplet::before {
  content: "\e4c4";
}
.z-icon-mask-face::before {
  content: "\e1d7";
}
.z-icon-hill-rockslide::before {
  content: "\e508";
}
.z-icon-right-left::before {
  content: "\f362";
}
.z-icon-exchange-alt::before {
  content: "\f362";
}
.z-icon-paper-plane::before {
  content: "\f1d8";
}
.z-icon-road-circle-exclamation::before {
  content: "\e565";
}
.z-icon-dungeon::before {
  content: "\f6d9";
}
.z-icon-align-right::before {
  content: "\f038";
}
.z-icon-money-bill-1-wave::before {
  content: "\f53b";
}
.z-icon-money-bill-wave-alt::before {
  content: "\f53b";
}
.z-icon-life-ring::before {
  content: "\f1cd";
}
.z-icon-hands::before {
  content: "\f2a7";
}
.z-icon-sign-language::before {
  content: "\f2a7";
}
.z-icon-signing::before {
  content: "\f2a7";
}
.z-icon-calendar-day::before {
  content: "\f783";
}
.z-icon-water-ladder::before {
  content: "\f5c5";
}
.z-icon-ladder-water::before {
  content: "\f5c5";
}
.z-icon-swimming-pool::before {
  content: "\f5c5";
}
.z-icon-arrows-up-down::before {
  content: "\f07d";
}
.z-icon-arrows-v::before {
  content: "\f07d";
}
.z-icon-face-grimace::before {
  content: "\f57f";
}
.z-icon-grimace::before {
  content: "\f57f";
}
.z-icon-wheelchair-move::before {
  content: "\e2ce";
}
.z-icon-wheelchair-alt::before {
  content: "\e2ce";
}
.z-icon-turn-down::before {
  content: "\f3be";
}
.z-icon-level-down-alt::before {
  content: "\f3be";
}
.z-icon-person-walking-arrow-right::before {
  content: "\e552";
}
.z-icon-square-envelope::before {
  content: "\f199";
}
.z-icon-envelope-square::before {
  content: "\f199";
}
.z-icon-dice::before {
  content: "\f522";
}
.z-icon-bowling-ball::before {
  content: "\f436";
}
.z-icon-brain::before {
  content: "\f5dc";
}
.z-icon-bandage::before {
  content: "\f462";
}
.z-icon-band-aid::before {
  content: "\f462";
}
.z-icon-calendar-minus::before {
  content: "\f272";
}
.z-icon-circle-xmark::before {
  content: "\f057";
}
.z-icon-times-circle::before {
  content: "\f057";
}
.z-icon-xmark-circle::before {
  content: "\f057";
}
.z-icon-gifts::before {
  content: "\f79c";
}
.z-icon-hotel::before {
  content: "\f594";
}
.z-icon-earth-asia::before {
  content: "\f57e";
}
.z-icon-globe-asia::before {
  content: "\f57e";
}
.z-icon-id-card-clip::before {
  content: "\f47f";
}
.z-icon-id-card-alt::before {
  content: "\f47f";
}
.z-icon-magnifying-glass-plus::before {
  content: "\f00e";
}
.z-icon-search-plus::before {
  content: "\f00e";
}
.z-icon-thumbs-up::before {
  content: "\f164";
}
.z-icon-user-clock::before {
  content: "\f4fd";
}
.z-icon-hand-dots::before {
  content: "\f461";
}
.z-icon-allergies::before {
  content: "\f461";
}
.z-icon-file-invoice::before {
  content: "\f570";
}
.z-icon-window-minimize::before {
  content: "\f2d1";
}
.z-icon-mug-saucer::before {
  content: "\f0f4";
}
.z-icon-coffee::before {
  content: "\f0f4";
}
.z-icon-brush::before {
  content: "\f55d";
}
.z-icon-mask::before {
  content: "\f6fa";
}
.z-icon-magnifying-glass-minus::before {
  content: "\f010";
}
.z-icon-search-minus::before {
  content: "\f010";
}
.z-icon-ruler-vertical::before {
  content: "\f548";
}
.z-icon-user-large::before {
  content: "\f406";
}
.z-icon-user-alt::before {
  content: "\f406";
}
.z-icon-train-tram::before {
  content: "\e5b4";
}
.z-icon-user-nurse::before {
  content: "\f82f";
}
.z-icon-syringe::before {
  content: "\f48e";
}
.z-icon-cloud-sun::before {
  content: "\f6c4";
}
.z-icon-stopwatch-20::before {
  content: "\e06f";
}
.z-icon-square-full::before {
  content: "\f45c";
}
.z-icon-magnet::before {
  content: "\f076";
}
.z-icon-jar::before {
  content: "\e516";
}
.z-icon-note-sticky::before {
  content: "\f249";
}
.z-icon-sticky-note::before {
  content: "\f249";
}
.z-icon-bug-slash::before {
  content: "\e490";
}
.z-icon-arrow-up-from-water-pump::before {
  content: "\e4b6";
}
.z-icon-bone::before {
  content: "\f5d7";
}
.z-icon-user-injured::before {
  content: "\f728";
}
.z-icon-face-sad-tear::before {
  content: "\f5b4";
}
.z-icon-sad-tear::before {
  content: "\f5b4";
}
.z-icon-plane::before {
  content: "\f072";
}
.z-icon-tent-arrows-down::before {
  content: "\e581";
}
.z-icon-exclamation::before {
  content: "\21";
}
.z-icon-arrows-spin::before {
  content: "\e4bb";
}
.z-icon-print::before {
  content: "\f02f";
}
.z-icon-turkish-lira-sign::before {
  content: "\e2bb";
}
.z-icon-try::before {
  content: "\e2bb";
}
.z-icon-turkish-lira::before {
  content: "\e2bb";
}
.z-icon-dollar-sign::before {
  content: "\24";
}
.z-icon-dollar::before {
  content: "\24";
}
.z-icon-usd::before {
  content: "\24";
}
.z-icon-x::before {
  content: "\58";
}
.z-icon-magnifying-glass-dollar::before {
  content: "\f688";
}
.z-icon-search-dollar::before {
  content: "\f688";
}
.z-icon-users-gear::before {
  content: "\f509";
}
.z-icon-users-cog::before {
  content: "\f509";
}
.z-icon-person-military-pointing::before {
  content: "\e54a";
}
.z-icon-building-columns::before {
  content: "\f19c";
}
.z-icon-bank::before {
  content: "\f19c";
}
.z-icon-institution::before {
  content: "\f19c";
}
.z-icon-museum::before {
  content: "\f19c";
}
.z-icon-university::before {
  content: "\f19c";
}
.z-icon-umbrella::before {
  content: "\f0e9";
}
.z-icon-trowel::before {
  content: "\e589";
}
.z-icon-d::before {
  content: "\44";
}
.z-icon-stapler::before {
  content: "\e5af";
}
.z-icon-masks-theater::before {
  content: "\f630";
}
.z-icon-theater-masks::before {
  content: "\f630";
}
.z-icon-kip-sign::before {
  content: "\e1c4";
}
.z-icon-hand-point-left::before {
  content: "\f0a5";
}
.z-icon-handshake-simple::before {
  content: "\f4c6";
}
.z-icon-handshake-alt::before {
  content: "\f4c6";
}
.z-icon-jet-fighter::before {
  content: "\f0fb";
}
.z-icon-fighter-jet::before {
  content: "\f0fb";
}
.z-icon-square-share-nodes::before {
  content: "\f1e1";
}
.z-icon-share-alt-square::before {
  content: "\f1e1";
}
.z-icon-barcode::before {
  content: "\f02a";
}
.z-icon-plus-minus::before {
  content: "\e43c";
}
.z-icon-video::before {
  content: "\f03d";
}
.z-icon-video-camera::before {
  content: "\f03d";
}
.z-icon-graduation-cap::before {
  content: "\f19d";
}
.z-icon-mortar-board::before {
  content: "\f19d";
}
.z-icon-hand-holding-medical::before {
  content: "\e05c";
}
.z-icon-person-circle-check::before {
  content: "\e53e";
}
.z-icon-turn-up::before {
  content: "\f3bf";
}
.z-icon-level-up-alt::before {
  content: "\f3bf";
}
.z-icon-monero:before {
  content: "\f3d0";
}
.z-icon-hooli:before {
  content: "\f427";
}
.z-icon-yelp:before {
  content: "\f1e9";
}
.z-icon-cc-visa:before {
  content: "\f1f0";
}
.z-icon-lastfm:before {
  content: "\f202";
}
.z-icon-shopware:before {
  content: "\f5b5";
}
.z-icon-creative-commons-nc:before {
  content: "\f4e8";
}
.z-icon-aws:before {
  content: "\f375";
}
.z-icon-redhat:before {
  content: "\f7bc";
}
.z-icon-yoast:before {
  content: "\f2b1";
}
.z-icon-cloudflare:before {
  content: "\e07d";
}
.z-icon-ups:before {
  content: "\f7e0";
}
.z-icon-wpexplorer:before {
  content: "\f2de";
}
.z-icon-dyalog:before {
  content: "\f399";
}
.z-icon-bity:before {
  content: "\f37a";
}
.z-icon-stackpath:before {
  content: "\f842";
}
.z-icon-buysellads:before {
  content: "\f20d";
}
.z-icon-first-order:before {
  content: "\f2b0";
}
.z-icon-modx:before {
  content: "\f285";
}
.z-icon-guilded:before {
  content: "\e07e";
}
.z-icon-vnv:before {
  content: "\f40b";
}
.z-icon-square-js:before {
  content: "\f3b9";
}
.z-icon-js-square:before {
  content: "\f3b9";
}
.z-icon-microsoft:before {
  content: "\f3ca";
}
.z-icon-qq:before {
  content: "\f1d6";
}
.z-icon-orcid:before {
  content: "\f8d2";
}
.z-icon-java:before {
  content: "\f4e4";
}
.z-icon-invision:before {
  content: "\f7b0";
}
.z-icon-creative-commons-pd-alt:before {
  content: "\f4ed";
}
.z-icon-centercode:before {
  content: "\f380";
}
.z-icon-glide-g:before {
  content: "\f2a6";
}
.z-icon-drupal:before {
  content: "\f1a9";
}
.z-icon-hire-a-helper:before {
  content: "\f3b0";
}
.z-icon-creative-commons-by:before {
  content: "\f4e7";
}
.z-icon-unity:before {
  content: "\e049";
}
.z-icon-whmcs:before {
  content: "\f40d";
}
.z-icon-rocketchat:before {
  content: "\f3e8";
}
.z-icon-vk:before {
  content: "\f189";
}
.z-icon-untappd:before {
  content: "\f405";
}
.z-icon-mailchimp:before {
  content: "\f59e";
}
.z-icon-css3-alt:before {
  content: "\f38b";
}
.z-icon-square-reddit:before {
  content: "\f1a2";
}
.z-icon-reddit-square:before {
  content: "\f1a2";
}
.z-icon-vimeo-v:before {
  content: "\f27d";
}
.z-icon-contao:before {
  content: "\f26d";
}
.z-icon-square-font-awesome:before {
  content: "\e5ad";
}
.z-icon-deskpro:before {
  content: "\f38f";
}
.z-icon-sistrix:before {
  content: "\f3ee";
}
.z-icon-square-instagram:before {
  content: "\e055";
}
.z-icon-instagram-square:before {
  content: "\e055";
}
.z-icon-battle-net:before {
  content: "\f835";
}
.z-icon-the-red-yeti:before {
  content: "\f69d";
}
.z-icon-square-hacker-news:before {
  content: "\f3af";
}
.z-icon-hacker-news-square:before {
  content: "\f3af";
}
.z-icon-edge:before {
  content: "\f282";
}
.z-icon-threads:before {
  content: "\e618";
}
.z-icon-napster:before {
  content: "\f3d2";
}
.z-icon-square-snapchat:before {
  content: "\f2ad";
}
.z-icon-snapchat-square:before {
  content: "\f2ad";
}
.z-icon-google-plus-g:before {
  content: "\f0d5";
}
.z-icon-artstation:before {
  content: "\f77a";
}
.z-icon-markdown:before {
  content: "\f60f";
}
.z-icon-sourcetree:before {
  content: "\f7d3";
}
.z-icon-google-plus:before {
  content: "\f2b3";
}
.z-icon-diaspora:before {
  content: "\f791";
}
.z-icon-foursquare:before {
  content: "\f180";
}
.z-icon-stack-overflow:before {
  content: "\f16c";
}
.z-icon-github-alt:before {
  content: "\f113";
}
.z-icon-phoenix-squadron:before {
  content: "\f511";
}
.z-icon-pagelines:before {
  content: "\f18c";
}
.z-icon-algolia:before {
  content: "\f36c";
}
.z-icon-red-river:before {
  content: "\f3e3";
}
.z-icon-creative-commons-sa:before {
  content: "\f4ef";
}
.z-icon-safari:before {
  content: "\f267";
}
.z-icon-google:before {
  content: "\f1a0";
}
.z-icon-square-font-awesome-stroke:before {
  content: "\f35c";
}
.z-icon-font-awesome-alt:before {
  content: "\f35c";
}
.z-icon-atlassian:before {
  content: "\f77b";
}
.z-icon-linkedin-in:before {
  content: "\f0e1";
}
.z-icon-digital-ocean:before {
  content: "\f391";
}
.z-icon-nimblr:before {
  content: "\f5a8";
}
.z-icon-chromecast:before {
  content: "\f838";
}
.z-icon-evernote:before {
  content: "\f839";
}
.z-icon-hacker-news:before {
  content: "\f1d4";
}
.z-icon-creative-commons-sampling:before {
  content: "\f4f0";
}
.z-icon-adversal:before {
  content: "\f36a";
}
.z-icon-creative-commons:before {
  content: "\f25e";
}
.z-icon-watchman-monitoring:before {
  content: "\e087";
}
.z-icon-fonticons:before {
  content: "\f280";
}
.z-icon-weixin:before {
  content: "\f1d7";
}
.z-icon-shirtsinbulk:before {
  content: "\f214";
}
.z-icon-codepen:before {
  content: "\f1cb";
}
.z-icon-git-alt:before {
  content: "\f841";
}
.z-icon-lyft:before {
  content: "\f3c3";
}
.z-icon-rev:before {
  content: "\f5b2";
}
.z-icon-windows:before {
  content: "\f17a";
}
.z-icon-wizards-of-the-coast:before {
  content: "\f730";
}
.z-icon-square-viadeo:before {
  content: "\f2aa";
}
.z-icon-viadeo-square:before {
  content: "\f2aa";
}
.z-icon-meetup:before {
  content: "\f2e0";
}
.z-icon-centos:before {
  content: "\f789";
}
.z-icon-adn:before {
  content: "\f170";
}
.z-icon-cloudsmith:before {
  content: "\f384";
}
.z-icon-pied-piper-alt:before {
  content: "\f1a8";
}
.z-icon-square-dribbble:before {
  content: "\f397";
}
.z-icon-dribbble-square:before {
  content: "\f397";
}
.z-icon-codiepie:before {
  content: "\f284";
}
.z-icon-node:before {
  content: "\f419";
}
.z-icon-mix:before {
  content: "\f3cb";
}
.z-icon-steam:before {
  content: "\f1b6";
}
.z-icon-cc-apple-pay:before {
  content: "\f416";
}
.z-icon-scribd:before {
  content: "\f28a";
}
.z-icon-debian:before {
  content: "\e60b";
}
.z-icon-openid:before {
  content: "\f19b";
}
.z-icon-instalod:before {
  content: "\e081";
}
.z-icon-expeditedssl:before {
  content: "\f23e";
}
.z-icon-sellcast:before {
  content: "\f2da";
}
.z-icon-square-twitter:before {
  content: "\f081";
}
.z-icon-twitter-square:before {
  content: "\f081";
}
.z-icon-r-project:before {
  content: "\f4f7";
}
.z-icon-delicious:before {
  content: "\f1a5";
}
.z-icon-freebsd:before {
  content: "\f3a4";
}
.z-icon-vuejs:before {
  content: "\f41f";
}
.z-icon-accusoft:before {
  content: "\f369";
}
.z-icon-ioxhost:before {
  content: "\f208";
}
.z-icon-fonticons-fi:before {
  content: "\f3a2";
}
.z-icon-app-store:before {
  content: "\f36f";
}
.z-icon-cc-mastercard:before {
  content: "\f1f1";
}
.z-icon-itunes-note:before {
  content: "\f3b5";
}
.z-icon-golang:before {
  content: "\e40f";
}
.z-icon-kickstarter:before {
  content: "\f3bb";
}
.z-icon-grav:before {
  content: "\f2d6";
}
.z-icon-weibo:before {
  content: "\f18a";
}
.z-icon-uncharted:before {
  content: "\e084";
}
.z-icon-firstdraft:before {
  content: "\f3a1";
}
.z-icon-square-youtube:before {
  content: "\f431";
}
.z-icon-youtube-square:before {
  content: "\f431";
}
.z-icon-wikipedia-w:before {
  content: "\f266";
}
.z-icon-wpressr:before {
  content: "\f3e4";
}
.z-icon-rendact:before {
  content: "\f3e4";
}
.z-icon-angellist:before {
  content: "\f209";
}
.z-icon-galactic-republic:before {
  content: "\f50c";
}
.z-icon-nfc-directional:before {
  content: "\e530";
}
.z-icon-skype:before {
  content: "\f17e";
}
.z-icon-joget:before {
  content: "\f3b7";
}
.z-icon-fedora:before {
  content: "\f798";
}
.z-icon-stripe-s:before {
  content: "\f42a";
}
.z-icon-meta:before {
  content: "\e49b";
}
.z-icon-laravel:before {
  content: "\f3bd";
}
.z-icon-hotjar:before {
  content: "\f3b1";
}
.z-icon-bluetooth-b:before {
  content: "\f294";
}
.z-icon-sticker-mule:before {
  content: "\f3f7";
}
.z-icon-creative-commons-zero:before {
  content: "\f4f3";
}
.z-icon-hips:before {
  content: "\f452";
}
.z-icon-behance:before {
  content: "\f1b4";
}
.z-icon-reddit:before {
  content: "\f1a1";
}
.z-icon-discord:before {
  content: "\f392";
}
.z-icon-chrome:before {
  content: "\f268";
}
.z-icon-app-store-ios:before {
  content: "\f370";
}
.z-icon-cc-discover:before {
  content: "\f1f2";
}
.z-icon-wpbeginner:before {
  content: "\f297";
}
.z-icon-confluence:before {
  content: "\f78d";
}
.z-icon-mdb:before {
  content: "\f8ca";
}
.z-icon-dochub:before {
  content: "\f394";
}
.z-icon-accessible-icon:before {
  content: "\f368";
}
.z-icon-ebay:before {
  content: "\f4f4";
}
.z-icon-amazon:before {
  content: "\f270";
}
.z-icon-unsplash:before {
  content: "\e07c";
}
.z-icon-yarn:before {
  content: "\f7e3";
}
.z-icon-square-steam:before {
  content: "\f1b7";
}
.z-icon-steam-square:before {
  content: "\f1b7";
}
.z-icon-500px:before {
  content: "\f26e";
}
.z-icon-square-vimeo:before {
  content: "\f194";
}
.z-icon-vimeo-square:before {
  content: "\f194";
}
.z-icon-asymmetrik:before {
  content: "\f372";
}
.z-icon-font-awesome:before {
  content: "\f2b4";
}
.z-icon-font-awesome-flag:before {
  content: "\f2b4";
}
.z-icon-font-awesome-logo-full:before {
  content: "\f2b4";
}
.z-icon-gratipay:before {
  content: "\f184";
}
.z-icon-apple:before {
  content: "\f179";
}
.z-icon-hive:before {
  content: "\e07f";
}
.z-icon-gitkraken:before {
  content: "\f3a6";
}
.z-icon-keybase:before {
  content: "\f4f5";
}
.z-icon-apple-pay:before {
  content: "\f415";
}
.z-icon-padlet:before {
  content: "\e4a0";
}
.z-icon-amazon-pay:before {
  content: "\f42c";
}
.z-icon-square-github:before {
  content: "\f092";
}
.z-icon-github-square:before {
  content: "\f092";
}
.z-icon-stumbleupon:before {
  content: "\f1a4";
}
.z-icon-fedex:before {
  content: "\f797";
}
.z-icon-phoenix-framework:before {
  content: "\f3dc";
}
.z-icon-shopify:before {
  content: "\e057";
}
.z-icon-neos:before {
  content: "\f612";
}
.z-icon-square-threads:before {
  content: "\e619";
}
.z-icon-hackerrank:before {
  content: "\f5f7";
}
.z-icon-researchgate:before {
  content: "\f4f8";
}
.z-icon-swift:before {
  content: "\f8e1";
}
.z-icon-angular:before {
  content: "\f420";
}
.z-icon-speakap:before {
  content: "\f3f3";
}
.z-icon-angrycreative:before {
  content: "\f36e";
}
.z-icon-y-combinator:before {
  content: "\f23b";
}
.z-icon-empire:before {
  content: "\f1d1";
}
.z-icon-envira:before {
  content: "\f299";
}
.z-icon-square-gitlab:before {
  content: "\e5ae";
}
.z-icon-gitlab-square:before {
  content: "\e5ae";
}
.z-icon-studiovinari:before {
  content: "\f3f8";
}
.z-icon-pied-piper:before {
  content: "\f2ae";
}
.z-icon-wordpress:before {
  content: "\f19a";
}
.z-icon-product-hunt:before {
  content: "\f288";
}
.z-icon-firefox:before {
  content: "\f269";
}
.z-icon-linode:before {
  content: "\f2b8";
}
.z-icon-goodreads:before {
  content: "\f3a8";
}
.z-icon-square-odnoklassniki:before {
  content: "\f264";
}
.z-icon-odnoklassniki-square:before {
  content: "\f264";
}
.z-icon-jsfiddle:before {
  content: "\f1cc";
}
.z-icon-sith:before {
  content: "\f512";
}
.z-icon-themeisle:before {
  content: "\f2b2";
}
.z-icon-page4:before {
  content: "\f3d7";
}
.z-icon-hashnode:before {
  content: "\e499";
}
.z-icon-react:before {
  content: "\f41b";
}
.z-icon-cc-paypal:before {
  content: "\f1f4";
}
.z-icon-squarespace:before {
  content: "\f5be";
}
.z-icon-cc-stripe:before {
  content: "\f1f5";
}
.z-icon-creative-commons-share:before {
  content: "\f4f2";
}
.z-icon-bitcoin:before {
  content: "\f379";
}
.z-icon-keycdn:before {
  content: "\f3ba";
}
.z-icon-opera:before {
  content: "\f26a";
}
.z-icon-itch-io:before {
  content: "\f83a";
}
.z-icon-umbraco:before {
  content: "\f8e8";
}
.z-icon-galactic-senate:before {
  content: "\f50d";
}
.z-icon-ubuntu:before {
  content: "\f7df";
}
.z-icon-draft2digital:before {
  content: "\f396";
}
.z-icon-stripe:before {
  content: "\f429";
}
.z-icon-houzz:before {
  content: "\f27c";
}
.z-icon-gg:before {
  content: "\f260";
}
.z-icon-dhl:before {
  content: "\f790";
}
.z-icon-square-pinterest:before {
  content: "\f0d3";
}
.z-icon-pinterest-square:before {
  content: "\f0d3";
}
.z-icon-xing:before {
  content: "\f168";
}
.z-icon-blackberry:before {
  content: "\f37b";
}
.z-icon-creative-commons-pd:before {
  content: "\f4ec";
}
.z-icon-playstation:before {
  content: "\f3df";
}
.z-icon-quinscape:before {
  content: "\f459";
}
.z-icon-less:before {
  content: "\f41d";
}
.z-icon-blogger-b:before {
  content: "\f37d";
}
.z-icon-opencart:before {
  content: "\f23d";
}
.z-icon-vine:before {
  content: "\f1ca";
}
.z-icon-paypal:before {
  content: "\f1ed";
}
.z-icon-gitlab:before {
  content: "\f296";
}
.z-icon-typo3:before {
  content: "\f42b";
}
.z-icon-reddit-alien:before {
  content: "\f281";
}
.z-icon-yahoo:before {
  content: "\f19e";
}
.z-icon-dailymotion:before {
  content: "\e052";
}
.z-icon-affiliatetheme:before {
  content: "\f36b";
}
.z-icon-pied-piper-pp:before {
  content: "\f1a7";
}
.z-icon-bootstrap:before {
  content: "\f836";
}
.z-icon-odnoklassniki:before {
  content: "\f263";
}
.z-icon-nfc-symbol:before {
  content: "\e531";
}
.z-icon-ethereum:before {
  content: "\f42e";
}
.z-icon-speaker-deck:before {
  content: "\f83c";
}
.z-icon-creative-commons-nc-eu:before {
  content: "\f4e9";
}
.z-icon-patreon:before {
  content: "\f3d9";
}
.z-icon-avianex:before {
  content: "\f374";
}
.z-icon-ello:before {
  content: "\f5f1";
}
.z-icon-gofore:before {
  content: "\f3a7";
}
.z-icon-bimobject:before {
  content: "\f378";
}
.z-icon-facebook-f:before {
  content: "\f39e";
}
.z-icon-square-google-plus:before {
  content: "\f0d4";
}
.z-icon-google-plus-square:before {
  content: "\f0d4";
}
.z-icon-mandalorian:before {
  content: "\f50f";
}
.z-icon-first-order-alt:before {
  content: "\f50a";
}
.z-icon-osi:before {
  content: "\f41a";
}
.z-icon-google-wallet:before {
  content: "\f1ee";
}
.z-icon-d-and-d-beyond:before {
  content: "\f6ca";
}
.z-icon-periscope:before {
  content: "\f3da";
}
.z-icon-fulcrum:before {
  content: "\f50b";
}
.z-icon-cloudscale:before {
  content: "\f383";
}
.z-icon-forumbee:before {
  content: "\f211";
}
.z-icon-mizuni:before {
  content: "\f3cc";
}
.z-icon-schlix:before {
  content: "\f3ea";
}
.z-icon-square-xing:before {
  content: "\f169";
}
.z-icon-xing-square:before {
  content: "\f169";
}
.z-icon-bandcamp:before {
  content: "\f2d5";
}
.z-icon-wpforms:before {
  content: "\f298";
}
.z-icon-cloudversify:before {
  content: "\f385";
}
.z-icon-usps:before {
  content: "\f7e1";
}
.z-icon-megaport:before {
  content: "\f5a3";
}
.z-icon-magento:before {
  content: "\f3c4";
}
.z-icon-spotify:before {
  content: "\f1bc";
}
.z-icon-optin-monster:before {
  content: "\f23c";
}
.z-icon-fly:before {
  content: "\f417";
}
.z-icon-aviato:before {
  content: "\f421";
}
.z-icon-itunes:before {
  content: "\f3b4";
}
.z-icon-cuttlefish:before {
  content: "\f38c";
}
.z-icon-blogger:before {
  content: "\f37c";
}
.z-icon-flickr:before {
  content: "\f16e";
}
.z-icon-viber:before {
  content: "\f409";
}
.z-icon-soundcloud:before {
  content: "\f1be";
}
.z-icon-digg:before {
  content: "\f1a6";
}
.z-icon-tencent-weibo:before {
  content: "\f1d5";
}
.z-icon-symfony:before {
  content: "\f83d";
}
.z-icon-maxcdn:before {
  content: "\f136";
}
.z-icon-etsy:before {
  content: "\f2d7";
}
.z-icon-facebook-messenger:before {
  content: "\f39f";
}
.z-icon-audible:before {
  content: "\f373";
}
.z-icon-think-peaks:before {
  content: "\f731";
}
.z-icon-bilibili:before {
  content: "\e3d9";
}
.z-icon-erlang:before {
  content: "\f39d";
}
.z-icon-x-twitter:before {
  content: "\e61b";
}
.z-icon-cotton-bureau:before {
  content: "\f89e";
}
.z-icon-dashcube:before {
  content: "\f210";
}
.z-icon-42-group:before {
  content: "\e080";
}
.z-icon-innosoft:before {
  content: "\e080";
}
.z-icon-stack-exchange:before {
  content: "\f18d";
}
.z-icon-elementor:before {
  content: "\f430";
}
.z-icon-square-pied-piper:before {
  content: "\e01e";
}
.z-icon-pied-piper-square:before {
  content: "\e01e";
}
.z-icon-creative-commons-nd:before {
  content: "\f4eb";
}
.z-icon-palfed:before {
  content: "\f3d8";
}
.z-icon-superpowers:before {
  content: "\f2dd";
}
.z-icon-resolving:before {
  content: "\f3e7";
}
.z-icon-xbox:before {
  content: "\f412";
}
.z-icon-searchengin:before {
  content: "\f3eb";
}
.z-icon-tiktok:before {
  content: "\e07b";
}
.z-icon-square-facebook:before {
  content: "\f082";
}
.z-icon-facebook-square:before {
  content: "\f082";
}
.z-icon-renren:before {
  content: "\f18b";
}
.z-icon-linux:before {
  content: "\f17c";
}
.z-icon-glide:before {
  content: "\f2a5";
}
.z-icon-linkedin:before {
  content: "\f08c";
}
.z-icon-hubspot:before {
  content: "\f3b2";
}
.z-icon-deploydog:before {
  content: "\f38e";
}
.z-icon-twitch:before {
  content: "\f1e8";
}
.z-icon-ravelry:before {
  content: "\f2d9";
}
.z-icon-mixer:before {
  content: "\e056";
}
.z-icon-square-lastfm:before {
  content: "\f203";
}
.z-icon-lastfm-square:before {
  content: "\f203";
}
.z-icon-vimeo:before {
  content: "\f40a";
}
.z-icon-mendeley:before {
  content: "\f7b3";
}
.z-icon-uniregistry:before {
  content: "\f404";
}
.z-icon-figma:before {
  content: "\f799";
}
.z-icon-creative-commons-remix:before {
  content: "\f4ee";
}
.z-icon-cc-amazon-pay:before {
  content: "\f42d";
}
.z-icon-dropbox:before {
  content: "\f16b";
}
.z-icon-instagram:before {
  content: "\f16d";
}
.z-icon-cmplid:before {
  content: "\e360";
}
.z-icon-facebook:before {
  content: "\f09a";
}
.z-icon-gripfire:before {
  content: "\f3ac";
}
.z-icon-jedi-order:before {
  content: "\f50e";
}
.z-icon-uikit:before {
  content: "\f403";
}
.z-icon-fort-awesome-alt:before {
  content: "\f3a3";
}
.z-icon-phabricator:before {
  content: "\f3db";
}
.z-icon-ussunnah:before {
  content: "\f407";
}
.z-icon-earlybirds:before {
  content: "\f39a";
}
.z-icon-trade-federation:before {
  content: "\f513";
}
.z-icon-autoprefixer:before {
  content: "\f41c";
}
.z-icon-whatsapp:before {
  content: "\f232";
}
.z-icon-slideshare:before {
  content: "\f1e7";
}
.z-icon-google-play:before {
  content: "\f3ab";
}
.z-icon-viadeo:before {
  content: "\f2a9";
}
.z-icon-line:before {
  content: "\f3c0";
}
.z-icon-google-drive:before {
  content: "\f3aa";
}
.z-icon-servicestack:before {
  content: "\f3ec";
}
.z-icon-simplybuilt:before {
  content: "\f215";
}
.z-icon-bitbucket:before {
  content: "\f171";
}
.z-icon-imdb:before {
  content: "\f2d8";
}
.z-icon-deezer:before {
  content: "\e077";
}
.z-icon-raspberry-pi:before {
  content: "\f7bb";
}
.z-icon-jira:before {
  content: "\f7b1";
}
.z-icon-docker:before {
  content: "\f395";
}
.z-icon-screenpal:before {
  content: "\e570";
}
.z-icon-bluetooth:before {
  content: "\f293";
}
.z-icon-gitter:before {
  content: "\f426";
}
.z-icon-d-and-d:before {
  content: "\f38d";
}
.z-icon-microblog:before {
  content: "\e01a";
}
.z-icon-cc-diners-club:before {
  content: "\f24c";
}
.z-icon-gg-circle:before {
  content: "\f261";
}
.z-icon-pied-piper-hat:before {
  content: "\f4e5";
}
.z-icon-kickstarter-k:before {
  content: "\f3bc";
}
.z-icon-yandex:before {
  content: "\f413";
}
.z-icon-readme:before {
  content: "\f4d5";
}
.z-icon-html5:before {
  content: "\f13b";
}
.z-icon-sellsy:before {
  content: "\f213";
}
.z-icon-sass:before {
  content: "\f41e";
}
.z-icon-wirsindhandwerk:before {
  content: "\e2d0";
}
.z-icon-wsh:before {
  content: "\e2d0";
}
.z-icon-buromobelexperte:before {
  content: "\f37f";
}
.z-icon-salesforce:before {
  content: "\f83b";
}
.z-icon-octopus-deploy:before {
  content: "\e082";
}
.z-icon-medapps:before {
  content: "\f3c6";
}
.z-icon-ns8:before {
  content: "\f3d5";
}
.z-icon-pinterest-p:before {
  content: "\f231";
}
.z-icon-apper:before {
  content: "\f371";
}
.z-icon-fort-awesome:before {
  content: "\f286";
}
.z-icon-waze:before {
  content: "\f83f";
}
.z-icon-cc-jcb:before {
  content: "\f24b";
}
.z-icon-snapchat:before {
  content: "\f2ab";
}
.z-icon-snapchat-ghost:before {
  content: "\f2ab";
}
.z-icon-fantasy-flight-games:before {
  content: "\f6dc";
}
.z-icon-rust:before {
  content: "\e07a";
}
.z-icon-wix:before {
  content: "\f5cf";
}
.z-icon-square-behance:before {
  content: "\f1b5";
}
.z-icon-behance-square:before {
  content: "\f1b5";
}
.z-icon-supple:before {
  content: "\f3f9";
}
.z-icon-rebel:before {
  content: "\f1d0";
}
.z-icon-css3:before {
  content: "\f13c";
}
.z-icon-staylinked:before {
  content: "\f3f5";
}
.z-icon-kaggle:before {
  content: "\f5fa";
}
.z-icon-space-awesome:before {
  content: "\e5ac";
}
.z-icon-deviantart:before {
  content: "\f1bd";
}
.z-icon-cpanel:before {
  content: "\f388";
}
.z-icon-goodreads-g:before {
  content: "\f3a9";
}
.z-icon-square-git:before {
  content: "\f1d2";
}
.z-icon-git-square:before {
  content: "\f1d2";
}
.z-icon-square-tumblr:before {
  content: "\f174";
}
.z-icon-tumblr-square:before {
  content: "\f174";
}
.z-icon-trello:before {
  content: "\f181";
}
.z-icon-creative-commons-nc-jp:before {
  content: "\f4ea";
}
.z-icon-get-pocket:before {
  content: "\f265";
}
.z-icon-perbyte:before {
  content: "\e083";
}
.z-icon-grunt:before {
  content: "\f3ad";
}
.z-icon-weebly:before {
  content: "\f5cc";
}
.z-icon-connectdevelop:before {
  content: "\f20e";
}
.z-icon-leanpub:before {
  content: "\f212";
}
.z-icon-black-tie:before {
  content: "\f27e";
}
.z-icon-themeco:before {
  content: "\f5c6";
}
.z-icon-python:before {
  content: "\f3e2";
}
.z-icon-android:before {
  content: "\f17b";
}
.z-icon-bots:before {
  content: "\e340";
}
.z-icon-free-code-camp:before {
  content: "\f2c5";
}
.z-icon-hornbill:before {
  content: "\f592";
}
.z-icon-js:before {
  content: "\f3b8";
}
.z-icon-ideal:before {
  content: "\e013";
}
.z-icon-git:before {
  content: "\f1d3";
}
.z-icon-dev:before {
  content: "\f6cc";
}
.z-icon-sketch:before {
  content: "\f7c6";
}
.z-icon-yandex-international:before {
  content: "\f414";
}
.z-icon-cc-amex:before {
  content: "\f1f3";
}
.z-icon-uber:before {
  content: "\f402";
}
.z-icon-github:before {
  content: "\f09b";
}
.z-icon-php:before {
  content: "\f457";
}
.z-icon-alipay:before {
  content: "\f642";
}
.z-icon-youtube:before {
  content: "\f167";
}
.z-icon-skyatlas:before {
  content: "\f216";
}
.z-icon-firefox-browser:before {
  content: "\e007";
}
.z-icon-replyd:before {
  content: "\f3e6";
}
.z-icon-suse:before {
  content: "\f7d6";
}
.z-icon-jenkins:before {
  content: "\f3b6";
}
.z-icon-twitter:before {
  content: "\f099";
}
.z-icon-rockrms:before {
  content: "\f3e9";
}
.z-icon-pinterest:before {
  content: "\f0d2";
}
.z-icon-buffer:before {
  content: "\f837";
}
.z-icon-npm:before {
  content: "\f3d4";
}
.z-icon-yammer:before {
  content: "\f840";
}
.z-icon-btc:before {
  content: "\f15a";
}
.z-icon-dribbble:before {
  content: "\f17d";
}
.z-icon-stumbleupon-circle:before {
  content: "\f1a3";
}
.z-icon-internet-explorer:before {
  content: "\f26b";
}
.z-icon-stubber:before {
  content: "\e5c7";
}
.z-icon-telegram:before {
  content: "\f2c6";
}
.z-icon-telegram-plane:before {
  content: "\f2c6";
}
.z-icon-old-republic:before {
  content: "\f510";
}
.z-icon-odysee:before {
  content: "\e5c6";
}
.z-icon-square-whatsapp:before {
  content: "\f40c";
}
.z-icon-whatsapp-square:before {
  content: "\f40c";
}
.z-icon-node-js:before {
  content: "\f3d3";
}
.z-icon-edge-legacy:before {
  content: "\e078";
}
.z-icon-slack:before {
  content: "\f198";
}
.z-icon-slack-hash:before {
  content: "\f198";
}
.z-icon-medrt:before {
  content: "\f3c8";
}
.z-icon-usb:before {
  content: "\f287";
}
.z-icon-tumblr:before {
  content: "\f173";
}
.z-icon-vaadin:before {
  content: "\f408";
}
.z-icon-quora:before {
  content: "\f2c4";
}
.z-icon-square-x-twitter:before {
  content: "\e61a";
}
.z-icon-reacteurope:before {
  content: "\f75d";
}
.z-icon-medium:before {
  content: "\f23a";
}
.z-icon-medium-m:before {
  content: "\f23a";
}
.z-icon-amilia:before {
  content: "\f36d";
}
.z-icon-mixcloud:before {
  content: "\f289";
}
.z-icon-flipboard:before {
  content: "\f44d";
}
.z-icon-viacoin:before {
  content: "\f237";
}
.z-icon-critical-role:before {
  content: "\f6c9";
}
.z-icon-sitrox:before {
  content: "\e44a";
}
.z-icon-discourse:before {
  content: "\f393";
}
.z-icon-joomla:before {
  content: "\f1aa";
}
.z-icon-mastodon:before {
  content: "\f4f6";
}
.z-icon-airbnb:before {
  content: "\f834";
}
.z-icon-wolf-pack-battalion:before {
  content: "\f514";
}
.z-icon-buy-n-large:before {
  content: "\f8a6";
}
.z-icon-gulp:before {
  content: "\f3ae";
}
.z-icon-creative-commons-sampling-plus:before {
  content: "\f4f1";
}
.z-icon-strava:before {
  content: "\f428";
}
.z-icon-ember:before {
  content: "\f423";
}
.z-icon-canadian-maple-leaf:before {
  content: "\f785";
}
.z-icon-teamspeak:before {
  content: "\f4f9";
}
.z-icon-pushed:before {
  content: "\f3e1";
}
.z-icon-wordpress-simple:before {
  content: "\f411";
}
.z-icon-nutritionix:before {
  content: "\f3d6";
}
.z-icon-wodu:before {
  content: "\e088";
}
.z-icon-google-pay:before {
  content: "\e079";
}
.z-icon-intercom:before {
  content: "\f7af";
}
.z-icon-zhihu:before {
  content: "\f63f";
}
.z-icon-korvue:before {
  content: "\f42f";
}
.z-icon-pix:before {
  content: "\e43a";
}
.z-icon-steam-symbol:before {
  content: "\f3f6";
}
.sr-only,
.z-icon-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.sr-only-focusable:not(:focus),
.z-icon-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.z-icon-address-book-o:before {
  content: "\f2b9";
}
.z-icon-address-card-o:before {
  content: "\f2bb";
}
.z-icon-area-chart:before {
  content: "\f1fe";
}
.z-icon-arrow-circle-o-down:before {
  content: "\f358";
}
.z-icon-arrow-circle-o-left:before {
  content: "\f359";
}
.z-icon-arrow-circle-o-right:before {
  content: "\f35a";
}
.z-icon-arrow-circle-o-up:before {
  content: "\f35b";
}
.z-icon-arrows-alt:before {
  content: "\f31e";
}
.z-icon-arrows-h:before {
  content: "\f07e";
}
.z-icon-arrows-v:before {
  content: "\f07d";
}
.z-icon-arrows:before {
  content: "\f0b2";
}
.z-icon-asl-interpreting:before {
  content: "\f2a3";
}
.z-icon-automobile:before {
  content: "\f1b9";
}
.z-icon-bank:before {
  content: "\f19c";
}
.z-icon-bar-chart-o:before {
  content: "\e0e3";
}
.z-icon-bar-chart:before {
  content: "\e0e3";
}
.z-icon-bathtub:before {
  content: "\f2cd";
}
.z-icon-battery-0:before {
  content: "\f244";
}
.z-icon-battery-1:before {
  content: "\f243";
}
.z-icon-battery-2:before {
  content: "\f242";
}
.z-icon-battery-3:before {
  content: "\f241";
}
.z-icon-battery-4:before {
  content: "\f240";
}
.z-icon-battery:before {
  content: "\f240";
}
.z-icon-behance-square:before {
  content: "\f1b5";
}
.z-icon-bell-o:before {
  content: "\f0f3";
}
.z-icon-bell-slash-o:before {
  content: "\f1f6";
}
.z-icon-bitbucket-square:before {
  content: "\f171";
}
.z-icon-bitcoin:before {
  content: "\f15a";
}
.z-icon-bookmark-o:before {
  content: "\f02e";
}
.z-icon-building-o:before {
  content: "\f1ad";
}
.z-icon-cab:before {
  content: "\f1ba";
}
.z-icon-calendar-check-o:before {
  content: "\f274";
}
.z-icon-calendar-minus-o:before {
  content: "\f272";
}
.z-icon-calendar-o:before {
  content: "\f133";
}
.z-icon-calendar-plus-o:before {
  content: "\f271";
}
.z-icon-calendar-times-o:before {
  content: "\f273";
}
.z-icon-calendar:before {
  content: "\f073";
}
.z-icon-caret-square-o-down:before {
  content: "\f150";
}
.z-icon-caret-square-o-left:before {
  content: "\f191";
}
.z-icon-caret-square-o-right:before {
  content: "\f152";
}
.z-icon-caret-square-o-up:before {
  content: "\f151";
}
.z-icon-cc:before {
  content: "\f20a";
}
.z-icon-chain-broken:before {
  content: "\f127";
}
.z-icon-chain:before {
  content: "\f0c1";
}
.z-icon-check-circle-o:before {
  content: "\f058";
}
.z-icon-check-square-o:before {
  content: "\f14a";
}
.z-icon-circle-o-notch:before {
  content: "\f1ce";
}
.z-icon-circle-o:before {
  content: "\f111";
}
.z-icon-circle-thin:before {
  content: "\f111";
}
.z-icon-clipboard:before {
  content: "\f0ea";
}
.z-icon-clock-o:before {
  content: "\f017";
}
.z-icon-close:before {
  content: "\f00d";
}
.z-icon-cloud-download:before {
  content: "\f0ed";
}
.z-icon-cloud-upload:before {
  content: "\f0ee";
}
.z-icon-cny:before {
  content: "\f157";
}
.z-icon-code-fork:before {
  content: "\f126";
}
.z-icon-comment-o:before {
  content: "\f075";
}
.z-icon-commenting-o:before {
  content: "\f4ad";
}
.z-icon-commenting:before {
  content: "\f4ad";
}
.z-icon-comments-o:before {
  content: "\f086";
}
.z-icon-compress:before {
  content: "\f422";
}
.z-icon-credit-card-alt:before {
  content: "\f09d";
}
.z-icon-cut:before {
  content: "\f0c4";
}
.z-icon-cutlery:before {
  content: "\f2e7";
}
.z-icon-dashboard:before {
  content: "\f625";
}
.z-icon-deafness:before {
  content: "\f2a4";
}
.z-icon-dedent:before {
  content: "\f03b";
}
.z-icon-diamond:before {
  content: "\f3a5";
}
.z-icon-dollar:before {
  content: "\24";
}
.z-icon-dot-circle-o:before {
  content: "\f192";
}
.z-icon-drivers-license-o:before {
  content: "\f2c2";
}
.z-icon-drivers-license:before {
  content: "\f2c2";
}
.z-icon-edit:before {
  content: "\f044";
}
.z-icon-eercast:before {
  content: "\f2da";
}
.z-icon-envelope-o:before {
  content: "\f0e0";
}
.z-icon-envelope-open-o:before {
  content: "\f2b6";
}
.z-icon-eur:before {
  content: "\f153";
}
.z-icon-euro:before {
  content: "\f153";
}
.z-icon-exchange:before {
  content: "\f362";
}
.z-icon-expand:before {
  content: "\f424";
}
.z-icon-external-link-square:before {
  content: "\f360";
}
.z-icon-external-link:before {
  content: "\f35d";
}
.z-icon-eye-slash:before {
  content: "\f070";
}
.z-icon-eye:before {
  content: "\f06e";
}
.z-icon-eyedropper:before {
  content: "\f1fb";
}
.z-icon-fa:before {
  content: "\f2b4";
}
.z-icon-facebook-f:before {
  content: "\f39e";
}
.z-icon-facebook-official:before {
  content: "\f09a";
}
.z-icon-facebook-square:before {
  content: "\f082";
}
.z-icon-facebook:before {
  content: "\f39e";
}
.z-icon-feed:before {
  content: "\f09e";
}
.z-icon-file-archive-o:before {
  content: "\f1c6";
}
.z-icon-file-audio-o:before {
  content: "\f1c7";
}
.z-icon-file-code-o:before {
  content: "\f1c9";
}
.z-icon-file-excel-o:before {
  content: "\f1c3";
}
.z-icon-file-image-o:before {
  content: "\f1c5";
}
.z-icon-file-movie-o:before {
  content: "\f1c8";
}
.z-icon-file-o:before {
  content: "\f15b";
}
.z-icon-file-pdf-o:before {
  content: "\f1c1";
}
.z-icon-file-photo-o:before {
  content: "\f1c5";
}
.z-icon-file-picture-o:before {
  content: "\f1c5";
}
.z-icon-file-powerpoint-o:before {
  content: "\f1c4";
}
.z-icon-file-sound-o:before {
  content: "\f1c7";
}
.z-icon-file-text-o:before {
  content: "\f15c";
}
.z-icon-file-text:before {
  content: "\f15c";
}
.z-icon-file-video-o:before {
  content: "\f1c8";
}
.z-icon-file-word-o:before {
  content: "\f1c2";
}
.z-icon-file-zip-o:before {
  content: "\f1c6";
}
.z-icon-files-o:before {
  content: "\f0c5";
}
.z-icon-flag-o:before {
  content: "\f024";
}
.z-icon-flash:before {
  content: "\f0e7";
}
.z-icon-floppy-o:before {
  content: "\f0c7";
}
.z-icon-folder-o:before {
  content: "\f07b";
}
.z-icon-folder-open-o:before {
  content: "\f07c";
}
.z-icon-frown-o:before {
  content: "\f119";
}
.z-icon-futbol-o:before {
  content: "\f1e3";
}
.z-icon-gbp:before {
  content: "\f154";
}
.z-icon-ge:before {
  content: "\f1d1";
}
.z-icon-gear:before {
  content: "\f013";
}
.z-icon-gears:before {
  content: "\f085";
}
.z-icon-git-square:before {
  content: "\f1d2";
}
.z-icon-github-square:before {
  content: "\f092";
}
.z-icon-gittip:before {
  content: "\f184";
}
.z-icon-glass:before {
  content: "\f000";
}
.z-icon-globe:before {
  content: "\f57d";
}
.z-icon-google-plus-circle:before {
  content: "\f2b3";
}
.z-icon-google-plus-official:before {
  content: "\f2b3";
}
.z-icon-google-plus-square:before {
  content: "\f0d4";
}
.z-icon-google-plus:before {
  content: "\f0d5";
}
.z-icon-group:before {
  content: "\f0c0";
}
.z-icon-hand-grab-o:before {
  content: "\f255";
}
.z-icon-hand-lizard-o:before {
  content: "\f258";
}
.z-icon-hand-o-down:before {
  content: "\f0a7";
}
.z-icon-hand-o-left:before {
  content: "\f0a5";
}
.z-icon-hand-o-right:before {
  content: "\f0a4";
}
.z-icon-hand-o-up:before {
  content: "\f0a6";
}
.z-icon-hand-paper-o:before {
  content: "\f256";
}
.z-icon-hand-peace-o:before {
  content: "\f25b";
}
.z-icon-hand-pointer-o:before {
  content: "\f25a";
}
.z-icon-hand-rock-o:before {
  content: "\f255";
}
.z-icon-hand-scissors-o:before {
  content: "\f257";
}
.z-icon-hand-spock-o:before {
  content: "\f259";
}
.z-icon-hand-stop-o:before {
  content: "\f256";
}
.z-icon-handshake-o:before {
  content: "\f2b5";
}
.z-icon-hard-of-hearing:before {
  content: "\f2a4";
}
.z-icon-hdd-o:before {
  content: "\f0a0";
}
.z-icon-header:before {
  content: "\f1dc";
}
.z-icon-heart-o:before {
  content: "\f004";
}
.z-icon-home:before {
  content: "\f015";
}
.z-icon-hospital-o:before {
  content: "\f0f8";
}
.z-icon-hotel:before {
  content: "\f236";
}
.z-icon-hourglass-1:before {
  content: "\f251";
}
.z-icon-hourglass-2:before {
  content: "\f252";
}
.z-icon-hourglass-3:before {
  content: "\f253";
}
.z-icon-hourglass-o:before {
  content: "\f254";
}
.z-icon-id-card-o:before {
  content: "\f2c2";
}
.z-icon-ils:before {
  content: "\f20b";
}
.z-icon-image:before {
  content: "\f03e";
}
.z-icon-inr:before {
  content: "\e1bc";
}
.z-icon-institution:before {
  content: "\f19c";
}
.z-icon-intersex:before {
  content: "\f224";
}
.z-icon-jpy:before {
  content: "\f157";
}
.z-icon-keyboard-o:before {
  content: "\f11c";
}
.z-icon-krw:before {
  content: "\f159";
}
.z-icon-lastfm-square:before {
  content: "\f203";
}
.z-icon-legal:before {
  content: "\f0e3";
}
.z-icon-lemon-o:before {
  content: "\f094";
}
.z-icon-level-down:before {
  content: "\f3be";
}
.z-icon-level-up:before {
  content: "\f3bf";
}
.z-icon-life-bouy:before {
  content: "\f1cd";
}
.z-icon-life-buoy:before {
  content: "\f1cd";
}
.z-icon-life-saver:before {
  content: "\f1cd";
}
.z-icon-lightbulb-o:before {
  content: "\f0eb";
}
.z-icon-line-chart:before {
  content: "\f201";
}
.z-icon-linkedin-square:before {
  content: "\f08c";
}
.z-icon-linkedin:before {
  content: "\f0e1";
}
.z-icon-list-alt:before {
  content: "\f022";
}
.z-icon-long-arrow-down:before {
  content: "\f309";
}
.z-icon-long-arrow-left:before {
  content: "\f30a";
}
.z-icon-long-arrow-right:before {
  content: "\f30b";
}
.z-icon-long-arrow-up:before {
  content: "\f30c";
}
.z-icon-magic:before {
  content: "\e2ca";
}
.z-icon-mail-forward:before {
  content: "\f064";
}
.z-icon-mail-reply-all:before {
  content: "\f122";
}
.z-icon-mail-reply:before {
  content: "\f3e5";
}
.z-icon-map-marker:before {
  content: "\f3c5";
}
.z-icon-map-o:before {
  content: "\f279";
}
.z-icon-meh-o:before {
  content: "\f11a";
}
.z-icon-minus-square-o:before {
  content: "\f146";
}
.z-icon-mobile-phone:before {
  content: "\f3cd";
}
.z-icon-mobile:before {
  content: "\f3cd";
}
.z-icon-money:before {
  content: "\f3d1";
}
.z-icon-moon-o:before {
  content: "\f186";
}
.z-icon-mortar-board:before {
  content: "\f19d";
}
.z-icon-navicon:before {
  content: "\f0c9";
}
.z-icon-newspaper-o:before {
  content: "\f1ea";
}
.z-icon-odnoklassniki-square:before {
  content: "\f264";
}
.z-icon-paper-plane-o:before {
  content: "\f1d8";
}
.z-icon-pause-circle-o:before {
  content: "\f28b";
}
.z-icon-pencil-square-o:before {
  content: "\f044";
}
.z-icon-pencil-square:before {
  content: "\f14b";
}
.z-icon-photo:before {
  content: "\f03e";
}
.z-icon-picture-o:before {
  content: "\f03e";
}
.z-icon-pie-chart:before {
  content: "\f200";
}
.z-icon-pinterest-square:before {
  content: "\f0d3";
}
.z-icon-play-circle-o:before {
  content: "\f144";
}
.z-icon-plus-square-o:before {
  content: "\f0fe";
}
.z-icon-question-circle-o:before {
  content: "\f059";
}
.z-icon-ra:before {
  content: "\f1d0";
}
.z-icon-reddit-square:before {
  content: "\f1a2";
}
.z-icon-refresh:before {
  content: "\f021";
}
.z-icon-remove:before {
  content: "\f00d";
}
.z-icon-reorder:before {
  content: "\f0c9";
}
.z-icon-repeat:before {
  content: "\f01e";
}
.z-icon-resistance:before {
  content: "\f1d0";
}
.z-icon-rmb:before {
  content: "\f157";
}
.z-icon-rotate-left:before {
  content: "\f0e2";
}
.z-icon-rotate-right:before {
  content: "\f01e";
}
.z-icon-rouble:before {
  content: "\f158";
}
.z-icon-rub:before {
  content: "\f158";
}
.z-icon-ruble:before {
  content: "\f158";
}
.z-icon-rupee:before {
  content: "\e1bc";
}
.z-icon-s15:before {
  content: "\f2cd";
}
.z-icon-save:before {
  content: "\f0c7";
}
.z-icon-send-o:before {
  content: "\f1d8";
}
.z-icon-send:before {
  content: "\f1d8";
}
.z-icon-share-square-o:before {
  content: "\f14d";
}
.z-icon-shekel:before {
  content: "\f20b";
}
.z-icon-sheqel:before {
  content: "\f20b";
}
.z-icon-sign-in:before {
  content: "\f2f6";
}
.z-icon-sign-out:before {
  content: "\f2f5";
}
.z-icon-signing:before {
  content: "\f2a7";
}
.z-icon-smile-o:before {
  content: "\f118";
}
.z-icon-snapchat-ghost:before {
  content: "\f2ab";
}
.z-icon-snapchat-square:before {
  content: "\f2ad";
}
.z-icon-snowflake-o:before {
  content: "\f2dc";
}
.z-icon-soccer-ball-o:before {
  content: "\f1e3";
}
.z-icon-sort-alpha-asc:before {
  content: "\f15d";
}
.z-icon-sort-alpha-desc:before {
  content: "\f881";
}
.z-icon-sort-amount-asc:before {
  content: "\f884";
}
.z-icon-sort-amount-desc:before {
  content: "\f160";
}
.z-icon-sort-asc:before {
  content: "\f0de";
}
.z-icon-sort-desc:before {
  content: "\f0dd";
}
.z-icon-sort-numeric-asc:before {
  content: "\f162";
}
.z-icon-sort-numeric-desc:before {
  content: "\f886";
}
.z-icon-square-o:before {
  content: "\f0c8";
}
.z-icon-star-half-empty:before {
  content: "\f5c0";
}
.z-icon-star-half-full:before {
  content: "\f5c0";
}
.z-icon-star-half-o:before {
  content: "\f5c0";
}
.z-icon-star-o:before {
  content: "\f005";
}
.z-icon-steam-square:before {
  content: "\f1b7";
}
.z-icon-sticky-note-o:before {
  content: "\f249";
}
.z-icon-stop-circle-o:before {
  content: "\f28d";
}
.z-icon-sun-o:before {
  content: "\f185";
}
.z-icon-support:before {
  content: "\f1cd";
}
.z-icon-tablet:before {
  content: "\f3fa";
}
.z-icon-tachometer:before {
  content: "\f625";
}
.z-icon-tasks:before {
  content: "\f828";
}
.z-icon-television:before {
  content: "\f26c";
}
.z-icon-thermometer-0:before {
  content: "\f2cb";
}
.z-icon-thermometer-1:before {
  content: "\f2ca";
}
.z-icon-thermometer-2:before {
  content: "\f2c9";
}
.z-icon-thermometer-3:before {
  content: "\f2c8";
}
.z-icon-thermometer-4:before {
  content: "\f2c7";
}
.z-icon-thermometer:before {
  content: "\f2c7";
}
.z-icon-thumb-tack:before {
  content: "\f08d";
}
.z-icon-thumbs-o-down:before {
  content: "\f165";
}
.z-icon-thumbs-o-up:before {
  content: "\f164";
}
.z-icon-times-circle-o:before {
  content: "\f057";
}
.z-icon-times-rectangle-o:before {
  content: "\f410";
}
.z-icon-times-rectangle:before {
  content: "\f410";
}
.z-icon-toggle-down:before {
  content: "\f150";
}
.z-icon-toggle-left:before {
  content: "\f191";
}
.z-icon-toggle-right:before {
  content: "\f152";
}
.z-icon-toggle-up:before {
  content: "\f151";
}
.z-icon-transgender-alt:before {
  content: "\f225";
}
.z-icon-transgender:before {
  content: "\f224";
}
.z-icon-trash-o:before {
  content: "\f2ed";
}
.z-icon-trash:before {
  content: "\f2ed";
}
.z-icon-try:before {
  content: "\e2bb";
}
.z-icon-tumblr-square:before {
  content: "\f174";
}
.z-icon-turkish-lira:before {
  content: "\e2bb";
}
.z-icon-twitter-square:before {
  content: "\f081";
}
.z-icon-unlink:before {
  content: "\f127";
}
.z-icon-unlock-alt:before {
  content: "\f09c";
}
.z-icon-unsorted:before {
  content: "\f0dc";
}
.z-icon-usd:before {
  content: "\24";
}
.z-icon-user-circle-o:before {
  content: "\f2bd";
}
.z-icon-user-o:before {
  content: "\f007";
}
.z-icon-vcard-o:before {
  content: "\f2bb";
}
.z-icon-vcard:before {
  content: "\f2bb";
}
.z-icon-viadeo-square:before {
  content: "\f2aa";
}
.z-icon-video-camera:before {
  content: "\f03d";
}
.z-icon-vimeo-square:before {
  content: "\f194";
}
.z-icon-vimeo:before {
  content: "\f27d";
}
.z-icon-volume-control-phone:before {
  content: "\f2a0";
}
.z-icon-warning:before {
  content: "\f071";
}
.z-icon-wechat:before {
  content: "\f1d7";
}
.z-icon-wheelchair-alt:before {
  content: "\f368";
}
.z-icon-window-close-o:before {
  content: "\f410";
}
.z-icon-won:before {
  content: "\f159";
}
.z-icon-xing-square:before {
  content: "\f169";
}
.z-icon-y-combinator-square:before {
  content: "\f1d4";
}
.z-icon-yc-square:before {
  content: "\f1d4";
}
.z-icon-yc:before {
  content: "\f23b";
}
.z-icon-yen:before {
  content: "\f157";
}
.z-icon-youtube-play:before {
  content: "\f167";
}
.z-icon-youtube-square:before {
  content: "\f431";
}
.z-icon-yen {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-wrench {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-won {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-window-minimize {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-window-close {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-wifi {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-wheelchair {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-warning {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-volume-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-volume-off {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-volume-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-volume-control-phone {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-video-camera {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-venus-mars {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-venus-double {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-venus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-vcard {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-users {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user-times {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user-secret {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user-plus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user-md {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-user {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-usd {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-upload {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-unsorted {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-unlock-alt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-unlock {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-unlink {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-university {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-universal-access {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-undo {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-underline {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-umbrella {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tv {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-turkish-lira {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tty {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-try {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-truck {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-trophy {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tripadvisor {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tree {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-trash {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-transgender-alt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-transgender {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-train {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-trademark {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-toggle-on {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-toggle-off {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tint {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-times-rectangle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-times-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-times {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ticket {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thumbs-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thumbs-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thumb-tack {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-three-quarters {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-quarter {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-half {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-full {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-empty {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-4 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-3 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-2 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-1 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer-0 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-thermometer {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-th-list {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-th-large {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-th {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-text-width {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-text-height {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-terminal {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-television {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-taxi {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tasks {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tags {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tag {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tachometer {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-tablet {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-table {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-support {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-superscript {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-suitcase {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-subway {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-subscript {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-strikethrough {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-street-view {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-stop-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-stop {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sticky-note {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-stethoscope {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-step-forward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-step-backward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-star-half {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-star {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-spoon {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-spinner {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-space-shuttle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-numeric-desc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-numeric-asc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-desc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-asc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-amount-desc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-amount-asc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-alpha-desc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort-alpha-asc {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sort {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sliders {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sitemap {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-signing {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-signal {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sign-out {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sign-language {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sign-in {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shower {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shopping-cart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shopping-basket {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shopping-bag {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ship {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shield {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-sheqel {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-shekel {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-share-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-share-alt-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-share-alt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-share {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-server {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-send {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-search-plus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-search-minus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-search {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-scissors {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-s15 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rupee {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ruble {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rub {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rss-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rss {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rouble {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rotate-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rotate-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rocket {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-road {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-rmb {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-retweet {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-reply-all {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-reply {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-repeat {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-reorder {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-remove {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-refresh {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-recycle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-random {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-quote-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-quote-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-question-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-question {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-qrcode {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-puzzle-piece {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-print {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-power-off {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-podcast {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-plus-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-plus-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-plus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-plug {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-play-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-play {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-plane {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-pie-chart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-phone-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-phone {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-percent {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-pencil-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-pencil {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paw {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-pause-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-pause {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paste {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paragraph {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paperclip {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paper-plane {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-paint-brush {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-outdent {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-neuter {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-navicon {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-music {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mouse-pointer {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-motorcycle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mortar-board {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-money {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mobile-phone {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mobile {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-minus-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-minus-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-minus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-microphone-slash {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-microphone {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-microchip {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mercury {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-medkit {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-meanpath {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mars-stroke-v {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mars-stroke-h {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mars-stroke {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mars-double {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mars {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-map-signs {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-map-pin {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-map-marker {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-map {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-male {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mail-reply-all {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mail-reply {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-mail-forward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-magnet {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-magic {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-low-vision {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-long-arrow-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-long-arrow-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-long-arrow-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-long-arrow-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-lock {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-location-arrow {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-list-ul {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-list-ol {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-list {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-link {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-line-chart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-life-saver {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-life-ring {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-life-buoy {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-life-bouy {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-level-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-level-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-legal {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-leaf {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-laptop {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-language {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-krw {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-key {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-jpy {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-italic {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-intersex {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-institution {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-inr {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-info-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-info {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-industry {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-indent {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-inbox {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ils {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-id-card {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-i-cursor {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-start {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-o {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-half {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-end {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-3 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-2 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass-1 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hourglass {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hotel {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-home {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-history {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-heartbeat {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-heart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-headphones {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-header {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hashtag {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-hard-of-hearing {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-h-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-group {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-graduation-cap {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-globe {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-glass {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gift {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-genderless {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gears {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gear {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gbp {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gavel {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-gamepad {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-forward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-font {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-folder-open {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-folder {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-flask {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-flash {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-flag-checkered {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-flag {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fire-extinguisher {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fire {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-filter {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-film {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-file-text {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-file {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fighter-jet {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-female {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-feed {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fax {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fast-forward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-fast-backward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-eyedropper {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-external-link-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-external-link {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-expand {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-exclamation-triangle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-exclamation-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-exclamation {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-exchange {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-euro {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-eur {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-eraser {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-envelope-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-envelope-open {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-envelope {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ellipsis-v {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ellipsis-h {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-eject {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-drivers-license {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-download {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-dollar {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-desktop {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-dedent {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-deafness {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-deaf {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-database {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-dashboard {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cutlery {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cut {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cubes {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cube {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-crosshairs {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-crop {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-credit-card-alt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-copy {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-compress {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-comments {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-commenting {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-comment {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-columns {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cogs {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cog {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-coffee {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-code-fork {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-code {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cny {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cloud-upload {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cloud-download {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cloud {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-close {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-clipboard {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-circle-o-notch {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-child {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-circle-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-circle-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-circle-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chevron-circle-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-check-square {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-check-circle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-check {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chain-broken {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-chain {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-certificate {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cart-plus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cart-arrow-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-caret-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-caret-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-caret-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-caret-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-car {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-camera-retro {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-camera {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-calendar {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-calculator {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-cab {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bus {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bullseye {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bullhorn {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-building {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bug {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-briefcase {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-braille {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bookmark {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-book {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bomb {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bolt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bold {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-blind {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-birthday-cake {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-binoculars {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bicycle {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bell-slash {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bell {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-beer {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bed {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-three-quarters {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-quarter {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-half {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-full {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-empty {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-4 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-3 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-2 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-1 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery-0 {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-battery {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bathtub {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bath {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bars {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-barcode {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bar-chart-o {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bar-chart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-bank {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ban {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-balance-scale {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-backward {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-automobile {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-audio-description {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-at {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-asterisk {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-assistive-listening-systems {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-asl-interpreting {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrows-v {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrows-h {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrows-alt {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrows {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-circle-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-circle-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-circle-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-arrow-circle-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-area-chart {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-archive {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-double-up {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-double-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-double-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-angle-double-down {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-anchor {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-american-sign-language-interpreting {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-ambulance {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-align-right {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-align-left {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-align-justify {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-align-center {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-adjust {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-address-card {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-address-book {
  font-family: FontAwesome;
  font-weight: 900;
}
.z-icon-window-restore {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-window-maximize {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-window-close-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-vcard-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-user-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-user-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-trash-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-toggle-up {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-toggle-right {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-toggle-left {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-toggle-down {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-times-rectangle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-times-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-thumbs-o-up {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-thumbs-o-down {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-sun-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-stop-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-sticky-note-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-star-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-star-half-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-star-half-full {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-star-half-empty {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-soccer-ball-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-snowflake-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-smile-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-share-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-send-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-save {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-registered {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-question-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-plus-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-play-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-picture-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-photo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pencil-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pause-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-paper-plane-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-object-ungroup {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-object-group {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-newspaper-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-moon-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-minus-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-meh-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-map-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-list-alt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-lightbulb-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-lemon-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-keyboard-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-image {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-id-card-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-id-badge {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hospital-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-heart-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hdd-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-handshake-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-stop-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-spock-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-scissors-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-rock-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-pointer-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-peace-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-paper-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-o-up {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-o-right {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-o-left {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-o-down {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-lizard-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hand-grab-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-futbol-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-frown-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-folder-open-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-folder-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-floppy-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-flag-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-files-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-zip-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-word-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-video-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-text-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-sound-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-powerpoint-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-picture-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-photo-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-pdf-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-movie-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-image-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-excel-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-code-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-audio-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-file-archive-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-eye-slash {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-eye {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-envelope-open-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-envelope-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-edit {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-drivers-license-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-dot-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-diamond {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-credit-card {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-copyright {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-compass {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-comments-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-commenting-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-comment-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-clone {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-clock-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-circle-thin {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-check-square-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-check-circle-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-caret-square-o-up {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-caret-square-o-right {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-caret-square-o-left {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-caret-square-o-down {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-calendar-times-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-calendar-plus-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-calendar-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-calendar-minus-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-calendar-check-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-building-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bookmark-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bell-slash-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bell-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-arrow-circle-o-up {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-arrow-circle-o-right {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-arrow-circle-o-left {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-arrow-circle-o-down {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-address-card-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-address-book-o {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-youtube-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-youtube-play {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-youtube {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-yoast {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-yelp {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-yc-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-yc {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-yahoo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-y-combinator-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-y-combinator {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-xing-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-xing {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wpforms {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wpexplorer {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wpbeginner {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wordpress {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-windows {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wikipedia-w {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wheelchair-alt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-whatsapp {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-weixin {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-weibo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-wechat {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-vk {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-vine {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-vimeo-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-vimeo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-viadeo-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-viadeo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-viacoin {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-usb {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-twitter-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-twitter {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-twitch {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-tumblr-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-tumblr {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-trello {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-themeisle {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-tencent-weibo {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-telegram {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-superpowers {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-stumbleupon-circle {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-stumbleupon {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-steam-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-steam {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-stack-overflow {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-stack-exchange {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-spotify {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-soundcloud {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-snapchat-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-snapchat-ghost {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-snapchat {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-slideshare {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-slack {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-skype {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-skyatlas {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-simplybuilt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-shirtsinbulk {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-sellsy {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-scribd {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-safari {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-resistance {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-renren {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-reddit-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-reddit-alien {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-reddit {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-rebel {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-ravelry {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-ra {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-quora {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-qq {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-product-hunt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pinterest-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pinterest-p {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pinterest {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pied-piper-pp {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pied-piper-alt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pied-piper {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-paypal {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-pagelines {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-optin-monster {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-opera {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-openid {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-opencart {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-odnoklassniki-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-odnoklassniki {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-modx {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-mixcloud {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-meetup {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-medium {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-maxcdn {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-linux {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-linode {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-linkedin-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-linkedin {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-leanpub {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-lastfm-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-lastfm {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-jsfiddle {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-joomla {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-ioxhost {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-internet-explorer {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-instagram {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-imdb {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-html5 {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-houzz {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-hacker-news {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-grav {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-gratipay {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google-wallet {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google-plus-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google-plus-official {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google-plus-circle {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google-plus {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-google {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-glide-g {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-glide {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-gittip {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-gitlab {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-github-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-github-alt {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-github {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-git-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-git {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-gg-circle {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-gg {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-get-pocket {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-ge {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-free-code-camp {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-foursquare {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-forumbee {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-fort-awesome {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-fonticons {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-font-awesome {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-flickr {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-first-order {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-firefox {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-facebook-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-facebook-official {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-facebook-f {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-facebook {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-fa {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-expeditedssl {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-etsy {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-envira {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-empire {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-eercast {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-edge {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-drupal {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-dropbox {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-dribbble {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-digg {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-deviantart {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-delicious {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-dashcube {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-css3 {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-creative-commons {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-contao {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-connectdevelop {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-codiepie {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-codepen {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-chrome {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-visa {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-stripe {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-paypal {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-mastercard {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-jcb {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-discover {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-diners-club {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-cc-amex {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-buysellads {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-btc {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bluetooth-b {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bluetooth {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-black-tie {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bitcoin {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bitbucket-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bitbucket {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-behance-square {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-behance {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-bandcamp {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-apple {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-angellist {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-android {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-amazon {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-adn {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-500px {
  font-family: FontAwesome;
  font-weight: 400;
}
.z-icon-circle-o:before {
  content: "\f10c";
}
.z-icon-envelope-o:before {
  content: "\f003";
}
.z-icon-flag-o:before {
  content: "\f11d";
}
.z-icon-question-circle-o:before {
  content: "\f29c";
}
.z-icon-times-circle-o:before {
  content: "\f05c";
}
.z-icon-user-o:before {
  content: "\f2c0";
}
[class*="z-icon-"] {
  font-family: ZK85Icons, FontAwesome;
}
.fas,
.z-icon-solid {
  font-family: FontAwesome;
  font-weight: 900;
}
.far,
.z-icon-regular {
  font-family: FontAwesome;
  font-weight: 400;
}
.fab,
.z-icon-brands {
  font-family: FontAwesome;
  font-weight: 400;
}
