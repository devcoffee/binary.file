<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-sliderbuttons-button {
  position: absolute;
  border-style: solid;
}
.z-sliderbuttons-tooltip {
  font-family: var(--zk-base-title-font-family);
  position: absolute;
  display: none;
  color: var(--zk-text-color-default3);
  vertical-align: top;
  line-height: 1;
  font-size: var(--zk-font-size-medium);
}
.z-sliderbuttons-area {
  position: absolute;
}
