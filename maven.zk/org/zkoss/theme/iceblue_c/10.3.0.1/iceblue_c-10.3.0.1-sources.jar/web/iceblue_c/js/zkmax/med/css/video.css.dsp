<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-video {
  display: inline-block;
}
.z-video-real {
  width: 100%;
  height: 100%;
}
.z-video-cover {
  object-fit: cover;
}
.z-video-light-on-video {
  position: relative;
  z-index: 1001;
}
.z-video-dim-background {
  background: black;
  opacity: 0.8;
}
