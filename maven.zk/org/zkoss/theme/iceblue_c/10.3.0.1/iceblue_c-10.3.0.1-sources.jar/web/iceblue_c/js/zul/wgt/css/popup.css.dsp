<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-popup {
  position: absolute;
  top: 0;
  left: 0;
}
.z-popup-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  height: 100%;
  padding: var(--zk-popup-padding);
  line-height: var(--zk-base-line-height);
  border: 1px solid var(--zk-popup-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  background-color: var(--zk-popup-background-color);
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
}
.z-notification {
  position: absolute;
  top: 0;
  left: 0;
}
.z-notification-icon {
  position: absolute;
  z-index: 1;
}
.z-notification-icon.z-icon-times-circle,
.z-notification-icon.z-icon-exclamation-circle,
.z-notification-icon.z-icon-info-circle {
  width: 32px;
  height: 32px;
  top: 50%;
  font-size: 32px;
  line-height: 32px;
  margin-top: -16px;
  left: 16px;
}
.z-notification-pointer + .z-notification-icon {
  left: 12px;
}
.z-notification-left + .z-notification-icon {
  left: 24px;
}
.z-notification-up + .z-notification-icon {
  margin-top: -12px;
}
.z-notification-down + .z-notification-icon {
  margin-top: -22px;
}
.z-notification-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  width: 288px;
  min-height: 80px;
  padding: var(--zk-notification-content-padding);
  position: relative;
  overflow: hidden;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  -webkit-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -moz-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -o-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -ms-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  box-shadow: 0 0 16px rgba(0,0,0,0.16);
}
.z-notification-content::before {
  content: "";
  display: block;
  width: 6px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
}
.z-notification-pointer ~ .z-notification-content {
  display: table-cell;
  width: 260px;
  height: var(--zk-notification-pointer-content-height);
  min-height: var(--zk-notification-pointer-content-height);
  padding: var(--zk-notification-pointer-content-padding);
  vertical-align: middle;
}
.z-notification-pointer {
  display: none;
  width: 0;
  height: 0;
  border: 10px solid transparent;
  position: absolute;
  z-index: 100;
}
.z-notification-left,
.z-notification-right,
.z-notification-up,
.z-notification-down {
  border: 10px solid transparent;
}
.z-notification-info .z-notification-icon {
  color: var(--zk-notification-info-color);
}
.z-notification-info .z-notification-close > .z-notification-icon {
  color: var(--zk-notification-info-text-color);
}
.z-notification-info .z-notification-content {
  color: var(--zk-notification-info-text-color);
  background-color: var(--zk-notification-info-background-color);
}
.z-notification-info .z-notification-content::before {
  background-color: var(--zk-notification-info-color);
}
.z-notification-info .z-notification-left {
  border-right-color: var(--zk-notification-info-color);
}
.z-notification-info .z-notification-right {
  border-left-color: var(--zk-notification-info-background-color);
}
.z-notification-info .z-notification-up {
  border-bottom-color: var(--zk-notification-info-background-color);
}
.z-notification-info .z-notification-down {
  border-top-color: var(--zk-notification-info-background-color);
}
.z-notification-warning .z-notification-icon {
  color: var(--zk-notification-warning-color);
}
.z-notification-warning .z-notification-close > .z-notification-icon {
  color: var(--zk-notification-warning-text-color);
}
.z-notification-warning .z-notification-content {
  color: var(--zk-notification-warning-text-color);
  background-color: var(--zk-notification-warning-background-color);
}
.z-notification-warning .z-notification-content::before {
  background-color: var(--zk-notification-warning-color);
}
.z-notification-warning .z-notification-left {
  border-right-color: var(--zk-notification-warning-color);
}
.z-notification-warning .z-notification-right {
  border-left-color: var(--zk-notification-warning-background-color);
}
.z-notification-warning .z-notification-up {
  border-bottom-color: var(--zk-notification-warning-background-color);
}
.z-notification-warning .z-notification-down {
  border-top-color: var(--zk-notification-warning-background-color);
}
.z-notification-error .z-notification-icon {
  color: var(--zk-notification-error-color);
}
.z-notification-error .z-notification-close > .z-notification-icon {
  color: var(--zk-notification-error-text-color);
}
.z-notification-error .z-notification-content {
  color: var(--zk-notification-error-text-color);
  background-color: var(--zk-notification-error-background-color);
}
.z-notification-error .z-notification-content::before {
  background-color: var(--zk-notification-error-color);
}
.z-notification-error .z-notification-left {
  border-right-color: var(--zk-notification-error-color);
}
.z-notification-error .z-notification-right {
  border-left-color: var(--zk-notification-error-background-color);
}
.z-notification-error .z-notification-up {
  border-bottom-color: var(--zk-notification-error-background-color);
}
.z-notification-error .z-notification-down {
  border-top-color: var(--zk-notification-error-background-color);
}
.z-notification-close {
  font-size: var(--zk-notification-close-font-size);
  width: var(--zk-notification-close-icon-size);
  height: var(--zk-notification-close-icon-size);
  padding: 0 2px;
  line-height: var(--zk-notification-close-font-size);
  position: absolute;
  top: 8px;
  right: 8px;
  cursor: pointer;
}
.z-notification-right ~ .z-notification-close {
  right: 16px;
}
.z-notification-up ~ .z-notification-close {
  top: 16px;
}
.z-toast {
  position: relative;
  will-change: opacity;
}
.z-toast-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  width: 320px;
  min-height: 46px;
  padding: 16px 42px 16px 56px;
  position: relative;
  overflow: hidden;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  -webkit-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -moz-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -o-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  -ms-box-shadow: 0 0 16px rgba(0,0,0,0.16);
  box-shadow: 0 0 16px rgba(0,0,0,0.16);
}
.z-toast-content::before {
  content: "";
  display: block;
  width: 6px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
}
.z-toast-close {
  font-size: 18px;
  width: 20px;
  height: 20px;
  padding: 0 2px;
  position: absolute;
  top: 50%;
  right: 12px;
  cursor: pointer;
  margin-top: -10px;
}
.z-toast-icon {
  position: absolute;
  z-index: 1;
}
.z-toast-icon.z-icon-times-circle,
.z-toast-icon.z-icon-exclamation-circle,
.z-toast-icon.z-icon-info-circle {
  width: 32px;
  height: 32px;
  top: 50%;
  font-size: 32px;
  line-height: 32px;
  margin-top: -16px;
  left: 16px;
}
.z-toast-error .z-toast-icon {
  color: var(--zk-notification-error-color);
}
.z-toast-error .z-toast-close > .z-toast-icon,
.z-toast-error .z-toast-content {
  color: var(--zk-notification-error-text-color);
}
.z-toast-error .z-toast-content {
  background-color: var(--zk-notification-error-background-color);
}
.z-toast-error .z-toast-content::before {
  background-color: var(--zk-notification-error-color);
}
.z-toast-info .z-toast-icon {
  color: var(--zk-notification-info-color);
}
.z-toast-info .z-toast-close > .z-toast-icon,
.z-toast-info .z-toast-content {
  color: var(--zk-notification-info-text-color);
}
.z-toast-info .z-toast-content {
  background-color: var(--zk-notification-info-background-color);
}
.z-toast-info .z-toast-content::before {
  background-color: var(--zk-notification-info-color);
}
.z-toast-warning .z-toast-icon {
  color: var(--zk-notification-warning-color);
}
.z-toast-warning .z-toast-close > .z-toast-icon,
.z-toast-warning .z-toast-content {
  color: var(--zk-notification-warning-text-color);
}
.z-toast-warning .z-toast-content {
  background-color: var(--zk-notification-warning-background-color);
}
.z-toast-warning .z-toast-content::before {
  background-color: var(--zk-notification-warning-color);
}
.z-toast-position {
  display: -ms-flexbox;
  display: flex;
  position: fixed;
  -ms-flex-direction: column;
  flex-direction: column;
  z-index: 1800;
}
.z-toast-position > .z-toast {
  margin-top: 10px;
}
.z-toast-position-top-left {
  -ms-flex-direction: column-reverse;
  flex-direction: column-reverse;
  top: 0;
  left: 0;
}
.z-toast-position-top-center {
  -ms-flex-direction: column-reverse;
  flex-direction: column-reverse;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  -ms-transform: translateX(-50%);
}
.z-toast-position-top-right {
  -ms-flex-direction: column-reverse;
  flex-direction: column-reverse;
  top: 0;
  right: 0;
}
.z-toast-position-middle-left {
  top: 50%;
  transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  left: 0;
}
.z-toast-position-middle-center {
  top: 50%;
  transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  left: 50%;
  transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
}
.z-toast-position-middle-right {
  top: 50%;
  transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  right: 0;
}
.z-toast-position-bottom-left {
  bottom: 0;
  left: 0;
}
.z-toast-position-bottom-center {
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  -ms-transform: translateX(-50%);
}
.z-toast-position-bottom-right {
  bottom: 0;
  right: 0;
}
