<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-biglistbox {
  border: 1px solid var(--zk-base-border-color);
  background: var(--zk-mesh-background-color);
  position: relative;
  overflow: hidden;
  zoom: 1;
}
.z-biglistbox-outer {
  border: 1px solid var(--zk-base-border-color);
  border-top: none;
  border-left: none;
  margin: var(--zk-biglistbox-outer-padding);
  background: var(--zk-mesh-background-color);
  position: relative;
}
.z-biglistbox-faker th {
  font-size: 0;
  width: 45px;
  height: 0;
  border: 0;
  margin: 0;
  padding: 0;
  line-height: 0;
  overflow: hidden;
}
.z-biglistbox-head-outer {
  overflow: hidden;
}
.z-biglistbox-head {
  width: 100%;
  border: 0;
  overflow: hidden;
  float: left;
}
.z-biglistbox-head table {
  border-spacing: 0;
}
.z-biglistbox-head table th,
.z-biglistbox-head table td {
  background-clip: padding-box;
}
.z-biglistbox-header {
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
  padding: 0;
  text-align: left;
  position: relative;
  overflow: hidden;
  cursor: default;
  white-space: nowrap;
  background: var(--zk-mesh-title-background-color);
}
.z-biglistbox-header:hover {
  background: var(--zk-mesh-title-hover-background-color);
}
.z-biglistbox-header:active {
  background: var(--zk-mesh-title-active-background-color);
}
.z-biglistbox-header-content {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-mesh-title-color);
  padding: 12px 16px;
  line-height: var(--zk-biglistbox-line-height);
  position: relative;
  white-space: nowrap;
}
.z-biglistbox-header-leftmost {
  border-left: none;
}
.z-biglistbox-body-outer {
  overflow: hidden;
}
.z-biglistbox-body {
  width: 100%;
  border: 0;
  background: var(--zk-mesh-background-color);
  position: relative;
  overflow: hidden;
  float: left;
}
.z-biglistbox-body table {
  border-spacing: 0;
}
.z-biglistbox-body table th,
.z-biglistbox-body table td {
  background-clip: padding-box;
}
.z-biglistbox-body td {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  padding: 12px 16px;
  line-height: var(--zk-biglistbox-line-height);
  overflow: hidden;
  cursor: pointer;
  white-space: nowrap;
}
.z-biglistbox-row {
  background: var(--zk-mesh-background-color);
  border-top: 1px solid var(--zk-mesh-content-border-color);
}
.z-biglistbox-row:hover td {
  color: var(--zk-hover-color);
  background-color: var(--zk-hover-background-color);
  position: relative;
}
.z-biglistbox-row.z-biglistbox-selected td {
  color: var(--zk-selected-color);
  border-color: var(--zk-selected-border-color);
  background-color: var(--zk-selected-background-color);
  position: relative;
}
.z-biglistbox-row.z-biglistbox-selected:hover td {
  color: var(--zk-selected-hover-color);
  border-color: var(--zk-selected-hover-border-color);
  background: var(--zk-selected-hover-background-color);
  position: relative;
}
.z-biglistbox-odd {
  background: var(--zk-mesh-stripe-background-color);
}
.z-biglistbox-sort {
  cursor: pointer;
}
.z-biglistbox-sorticon {
  color: var(--zk-mesh-title-color);
  position: absolute;
  top: -7px;
  left: 50%;
}
.z-biglistbox-hover {
  position: relative;
}
.z-biglistbox-head-shim,
.z-biglistbox-body-shim {
  width: 3px;
  height: 1px;
  overflow: hidden;
  float: left;
}
.z-biglistbox-verticalbar-frozen {
  width: 3px;
  height: 100%;
  background: var(--zk-biglistbox-frozen-background-color);
  position: absolute;
  top: -3px;
}
.z-biglistbox-verticalbar-frozen-ghost {
  width: 1px;
  height: 100%;
  background: var(--zk-biglistbox-frozen-ghost-background-color);
}
.z-biglistbox-verticalbar-tick {
  width: var(--zk-biglistbox-vertical-tick-width);
  height: var(--zk-biglistbox-vertical-tick-height);
  position: absolute;
  font-size: 16px;
  color: var(--zk-biglistbox-scrollbar-text-color);
  background-color: var(--zk-base-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
  bottom: var(--zk-biglistbox-vertical-tick-position-bottom);
  overflow: hidden;
  cursor: col-resize;
  z-index: 20;
  font-family: 'ZK85Icons', sans-serif;
}
.z-biglistbox-verticalbar-tick:before {
  content: '\e910';
  position: absolute;
  left: var(--zk-biglistbox-vertical-tick-before-position-left);
}
.z-biglistbox-verticalbar-tick:hover {
  background-color: var(--zk-biglistbox-scrollbar-hover-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-hover-border-color);
}
.z-biglistbox-verticalbar-tick:active {
  color: var(--zk-text-color-default3);
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-vertical {
  width: var(--zk-biglistbox-size);
  height: 100%;
  position: absolute;
  top: 0;
  right: var(--zk-biglistbox-wscroll-vertical-position-right);
  z-index: 10;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag {
  font-family: 'ZK85Icons', sans-serif;
  width: var(--zk-biglistbox-size);
  height: var(--zk-biglistbox-wscroll-drag-size);
  color: var(--zk-biglistbox-scrollbar-text-color);
  background-color: var(--zk-base-background-color);
  position: absolute;
  overflow: hidden;
  cursor: pointer;
  z-index: 15;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  font-size: 16px;
  position: absolute;
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:hover {
  background-color: var(--zk-biglistbox-scrollbar-hover-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-hover-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:active {
  color: var(--zk-text-color-default3);
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  width: var(--zk-biglistbox-size);
  height: var(--zk-biglistbox-wscroll-button-size);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:before,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:before,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:before,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:before {
  position: relative;
  right: var(--zk-biglistbox-wscroll-button-before-position-right);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  width: var(--zk-biglistbox-size);
  height: var(--zk-biglistbox-wscroll-button-body-size);
  top: var(--zk-biglistbox-wscroll-button-body-position-top);
  border-top: 0;
  border-bottom: 0;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:before {
  content: '\e90d';
  position: absolute;
  top: var(--zk-biglistbox-wscroll-button-body-before-position-top);
  right: var(--zk-biglistbox-wscroll-button-body-before-position-right);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:active {
  top: var(--zk-biglistbox-wscroll-button-body-hover-position-top);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home {
  top: 0;
  -webkit-border-radius: 2px 2px 0 0;
  -moz-border-radius: 2px 2px 0 0;
  -o-border-radius: 2px 2px 0 0;
  -ms-border-radius: 2px 2px 0 0;
  border-radius: 2px 2px 0 0;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:before {
  content: '\e90e';
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up {
  top: var(--zk-biglistbox-wscroll-button-size);
  border-top: 0;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:before {
  content: '\e904';
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:active {
  top: var(--zk-biglistbox-wscroll-button-up-hover-position-top);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down {
  bottom: var(--zk-biglistbox-wscroll-button-size);
  border-bottom: 0;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:before {
  content: '\e90a';
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  bottom: 0;
  -webkit-border-radius: 0 0 2px 2px;
  -moz-border-radius: 0 0 2px 2px;
  -o-border-radius: 0 0 2px 2px;
  -ms-border-radius: 0 0 2px 2px;
  border-radius: 0 0 2px 2px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:before {
  content: '\e903';
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-pos {
  visibility: visible;
  width: 18px;
  height: 115px;
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
  background: contrast(var(--zk-base-background-color));
  opacity: 0.25;
  position: absolute;
  left: 0;
  top: 0;
  z-index: 10;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-endbar {
  width: var(--zk-biglistbox-size);
  height: 8px;
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
  background-color: var(--zk-biglistbox-scrollbar-end-bar-background-color);
  overflow: hidden;
  position: absolute;
  right: 0;
  z-index: 20;
}
.z-biglistbox-wscroll-horizontal {
  width: 100%;
  height: var(--zk-biglistbox-size);
  position: absolute;
  left: 0;
  bottom: var(--zk-biglistbox-wscroll-vertical-position-right);
  z-index: 10;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag {
  font-family: 'ZK85Icons', sans-serif;
  width: var(--zk-biglistbox-wscroll-drag-size);
  height: var(--zk-biglistbox-size);
  color: var(--zk-biglistbox-scrollbar-text-color);
  background-color: var(--zk-base-background-color);
  position: absolute;
  overflow: hidden;
  cursor: pointer;
  z-index: 15;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  font-size: 16px;
  position: absolute;
  top: 0;
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:hover {
  background-color: var(--zk-biglistbox-scrollbar-hover-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-hover-border-color);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:active {
  color: var(--zk-text-color-default3);
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  width: var(--zk-biglistbox-wscroll-button-size);
  height: var(--zk-biglistbox-size);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  width: var(--zk-biglistbox-wscroll-button-body-size);
  height: var(--zk-biglistbox-size);
  left: var(--zk-biglistbox-wscroll-button-body-position-top);
  border-left: 0;
  border-right: 0;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:before {
  content: '\e90f';
  position: absolute;
  left: var(--zk-biglistbox-wscroll-button-body-before-position-top);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:active {
  left: var(--zk-biglistbox-wscroll-button-body-hover-position-top);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home {
  left: 0px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home:before {
  content: '\f048';
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up {
  left: var(--zk-biglistbox-wscroll-button-size);
  border-left: 0;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:before {
  content: '\e906';
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up:active {
  left: var(--zk-biglistbox-wscroll-button-up-hover-position-top);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down {
  right: var(--zk-biglistbox-wscroll-button-size);
  border-right: 0;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down:before {
  content: '\e90c';
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  right: 0;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end:before {
  content: '\f051';
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-pos {
  visibility: visible;
  width: var(--zk-biglistbox-wscroll-horizontal-pos-width);
  height: var(--zk-biglistbox-size);
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
  background: contrast(var(--zk-base-background-color));
  opacity: 0.25;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-endbar {
  width: 7px;
  height: var(--zk-biglistbox-size);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
  background-color: var(--zk-biglistbox-scrollbar-end-bar-background-color);
  position: absolute;
  right: -12px;
  overflow: hidden;
  z-index: 20;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up:hover {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-home:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-head .z-biglistbox-wscroll-up:active {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down:hover,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end:hover,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end:hover {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-down:active,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end:active,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-tail .z-biglistbox-wscroll-end:active {
  color: var(--zk-disabled-color);
  background: var(--zk-disabled-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-border-color);
}
