<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-auxhead th:first-child {
  border-left: none;
}
.z-auxhead th:first-child.z-auxhead-border {
  border-left: 1px solid var(--zk-mesh-title-border-color);
}
.z-auxhead-bar {
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
}
.z-auxheader {
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
  padding: 0;
  background-color: var(--zk-mesh-title-background-color);
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}
.z-auxheader-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-mesh-title-color);
  padding: var(--zk-auxhead-content-padding);
  line-height: var(--zk-base-button-height);
  overflow: hidden;
}
