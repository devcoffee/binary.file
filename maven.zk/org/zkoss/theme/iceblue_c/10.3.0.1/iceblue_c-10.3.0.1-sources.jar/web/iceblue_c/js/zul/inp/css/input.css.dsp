<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-textbox,
.z-decimalbox,
.z-intbox,
.z-longbox,
.z-doublebox {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-input-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-input-color);
  height: var(--zk-input-height);
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-input-padding);
  line-height: var(--zk-input-line-height);
  background: var(--zk-input-background-color);
}
.z-textbox::-webkit-input-placeholder,
.z-decimalbox::-webkit-input-placeholder,
.z-intbox::-webkit-input-placeholder,
.z-longbox::-webkit-input-placeholder,
.z-doublebox::-webkit-input-placeholder {
  color: var(--zk-input-placeholder-color);
}
.z-textbox::-moz-placeholder,
.z-decimalbox::-moz-placeholder,
.z-intbox::-moz-placeholder,
.z-longbox::-moz-placeholder,
.z-doublebox::-moz-placeholder {
  /* FF 19+ */
  color: var(--zk-input-placeholder-color);
  opacity: 1;
}
.z-textbox:-moz-placeholder,
.z-decimalbox:-moz-placeholder,
.z-intbox:-moz-placeholder,
.z-longbox:-moz-placeholder,
.z-doublebox:-moz-placeholder {
  /* FF 4-18 */
  color: var(--zk-input-placeholder-color);
  opacity: 1;
}
.z-textbox:-ms-input-placeholder,
.z-decimalbox:-ms-input-placeholder,
.z-intbox:-ms-input-placeholder,
.z-longbox:-ms-input-placeholder,
.z-doublebox:-ms-input-placeholder {
  /* IE 10+ */
  color: var(--zk-input-placeholder-color);
}
.z-textbox:hover,
.z-decimalbox:hover,
.z-intbox:hover,
.z-longbox:hover,
.z-doublebox:hover {
  border-color: var(--zk-input-hover-border-color);
}
.z-textbox:focus,
.z-decimalbox:focus,
.z-intbox:focus,
.z-longbox:focus,
.z-doublebox:focus {
  border-color: var(--zk-input-focus-border-color);
}
.z-textbox[readonly],
.z-decimalbox[readonly],
.z-intbox[readonly],
.z-longbox[readonly],
.z-doublebox[readonly] {
  color: var(--zk-input-readonly-color);
  background: var(--zk-input-readonly-background-color);
}
.z-textbox[readonly]:hover,
.z-decimalbox[readonly]:hover,
.z-intbox[readonly]:hover,
.z-longbox[readonly]:hover,
.z-doublebox[readonly]:hover {
  border-color: var(--zk-input-border-color);
}
.z-textbox[readonly]:focus,
.z-decimalbox[readonly]:focus,
.z-intbox[readonly]:focus,
.z-longbox[readonly]:focus,
.z-doublebox[readonly]:focus {
  border-color: var(--zk-input-border-color);
}
.z-textbox-invalid,
.z-decimalbox-invalid,
.z-intbox-invalid,
.z-longbox-invalid,
.z-doublebox-invalid {
  border-color: var(--zk-invalid-border-color);
}
.z-textbox[disabled],
.z-decimalbox[disabled],
.z-intbox[disabled],
.z-longbox[disabled],
.z-doublebox[disabled] {
  color: var(--zk-input-disable-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
}
.z-textbox[disabled]:hover,
.z-decimalbox[disabled]:hover,
.z-intbox[disabled]:hover,
.z-longbox[disabled]:hover,
.z-doublebox[disabled]:hover {
  border-color: var(--zk-input-border-color);
}
.z-textbox[disabled]:focus,
.z-decimalbox[disabled]:focus,
.z-intbox[disabled]:focus,
.z-longbox[disabled]:focus,
.z-doublebox[disabled]:focus {
  border-color: var(--zk-input-border-color);
}
.z-textbox-inplace,
.z-decimalbox-inplace,
.z-intbox-inplace,
.z-longbox-inplace,
.z-doublebox-inplace {
  border-color: transparent;
  background: none;
  resize: none;
}
.z-textbox-inplace:hover,
.z-decimalbox-inplace:hover,
.z-intbox-inplace:hover,
.z-longbox-inplace:hover,
.z-doublebox-inplace:hover {
  border-color: transparent;
}
textarea.z-textbox {
  height: auto;
}
.z-errorbox {
  color: var(--zk-errorbox-color);
  width: 260px;
  position: absolute;
  top: 0;
  left: 0;
}
.z-errorbox > .z-errorbox-icon {
  font-size: var(--zk-font-size-large);
  color: var(--zk-errorbox-color);
  position: absolute;
  top: var(--zk-errorbox-inside-icon-position-top);
  left: 7px;
  z-index: 2;
}
.z-errorbox-left + .z-errorbox-icon {
  left: 15px;
}
.z-errorbox-up + .z-errorbox-icon {
  top: var(--zk-errorbox-up-icon-position-top);
}
.z-errorbox-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-errorbox-color);
  width: 100%;
  border: 1px solid var(--zk-errorbox-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-errorbox-content-padding);
  background: var(--zk-errorbox-background-color);
  vertical-align: middle;
  position: relative;
  overflow: hidden;
  cursor: move;
}
.z-errorbox-pointer {
  display: none;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  position: absolute;
  z-index: 100;
}
.z-errorbox-left,
.z-errorbox-right,
.z-errorbox-up,
.z-errorbox-down {
  border: 6px solid transparent;
}
.z-errorbox-left {
  border-right-color: var(--zk-errorbox-background-color);
}
.z-errorbox-right {
  border-left-color: var(--zk-errorbox-background-color);
}
.z-errorbox-up {
  border-bottom-color: var(--zk-errorbox-background-color);
}
.z-errorbox-down {
  border-top-color: var(--zk-errorbox-background-color);
}
.z-errorbox-close {
  font-size: var(--zk-font-size-large);
  width: var(--zk-font-size-large);
  height: var(--zk-font-size-large);
  padding: 0 1px;
  position: absolute;
  top: 10px;
  right: 8px;
  cursor: pointer;
  opacity: 0.6;
}
.z-errorbox-close:hover {
  opacity: 1;
}
/* stylelint-disable-next-line no-descending-specificity */
.z-errorbox-icon {
  position: absolute;
  top: var(--zk-errorbox-icon-position-top);
}
.z-errorbox-right ~ .z-errorbox-close {
  right: 16px;
}
.z-errorbox-up ~ .z-errorbox-close {
  top: 17px;
}
