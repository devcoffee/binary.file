<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-rowlayout {
  width: 100%;
  *zoom: 1;
}
.z-rowlayout:before,
.z-rowlayout:after {
  display: table;
  line-height: 0;
  content: "";
  clear: both;
}
.z-rowchildren[class*="colspan"] {
  display: block;
  float: left;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -o-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
}
@media (max-width: 767px) {
  .z-rowchildren[class*="colspan"] {
    float: none;
  }
}
