<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-frozen {
  background-image: url(${c:encodeThemeURL("~./zul/img/common/bar-bg.png")});
  overflow: hidden;
}
.z-frozen-body {
  overflow: hidden;
  float: left;
}
.z-frozen-inner {
  overflow-x: scroll;
  overflow-y: hidden;
}
.z-frozen-inner div {
  height: 100%;
}
.z-frozen-right {
  overflow: hidden;
  float: right;
}
.z-frozen-col {
  border-left: none !important;
  border-right: 1px solid var(--zk-mesh-title-border-color);
}
.z-frozen-right-col {
  position: sticky !important;
}
.z-frozen-right-col:first-child {
  left: 0;
}
.z-frozen-sticky {
  position: sticky;
  z-index: 1;
}
