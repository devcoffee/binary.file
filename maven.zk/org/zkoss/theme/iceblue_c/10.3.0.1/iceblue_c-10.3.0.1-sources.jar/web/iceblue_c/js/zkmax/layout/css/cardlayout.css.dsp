<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-cardlayout {
  position: relative;
  overflow: hidden;
}
.z-cardlayout-inner {
  position: absolute;
  overflow: hidden;
}
