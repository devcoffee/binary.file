:root {
  --zk-base-font-size: 12px;
  --zk-base-title-font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  --zk-base-content-font-family: var(--zk-base-title-font-family);
  --zk-base-line-height: var(--zk-base-font-size);
  --zk-base-height: 8px;
  --zk-base-icon-height: calc(var(--zk-base-height) * 2);
  --zk-base-button-height: calc(var(--zk-base-height) * 3);
  --zk-base-bar-height: calc(var(--zk-base-height) * 4);
  --zk-base-title-height: calc(var(--zk-base-height) * 5);
  --zk-base-width: 8px;
  --zk-base-icon-width: calc(var(--zk-base-width) * 2);
  --zk-base-button-width: calc(var(--zk-base-width) * 3);
  --zk-base-bar-width: calc(var(--zk-base-width) * 4);
  --zk-font-size-x-large: 18px;
  --zk-font-size-large: 16px;
  --zk-font-size-medium: 12px;
  --zk-font-size-small: 11px;
  --zk-font-size-x-small: 10px;
  --zk-base-border-radius: 4px;
  --zk-border-radius-large: 6px;
  --zk-border-radius-small: 3px;
  --zk-text-color-default: rgba(0, 0, 0, 0.9);
  --zk-text-color-light: rgba(0, 0, 0, 0.57);
  --zk-text-color-lighter: rgba(0, 0, 0, 0.34);
  --zk-text-color-default3: #FFFFFF;
  --zk-text-color-active: #0093F9;
  --zk-color-primary: #0093F9;
  --zk-color-primary-dark: #0064ED;
  --zk-color-primary-light: hsl(from var(--zk-color-primary) h s calc(l + 25));
  --zk-color-primary-lighter: hsl(from var(--zk-color-primary) h s calc(l + 45));
  --zk-color-accent: #FFA516;
  --zk-color-accent2: #FF4051;
  --zk-color-accent3: #261429;
  --zk-color-background1: #F9FCFF;
  --zk-color-background3: #FFFFFF;
  --zk-color-grey-dark: #A8A8A8;
  --zk-color-grey-light: #D9D9D9;
  --zk-color-grey-lighter: #F2F2F2;
  --zk-base-text-color: var(--zk-text-color-default);
  --zk-base-border-color: var(--zk-color-grey-light);
  --zk-base-background-color: var(--zk-color-background3);
  --zk-icon-color: var(--zk-text-color-light);
  --zk-icon-hover-color: var(--zk-text-color-default);
  --zk-icon-disabled-color: var(--zk-text-color-lighter);
  --zk-mesh-auto-paging-row-height: 32px;
  --zk-mesh-auto-paging-row-padding: var(--zk-mesh-body-padding);
  --zk-mesh-auto-paging-row-line-height: var(--zk-mesh-content-line-height);
  --zk-mesh-background-color: var(--zk-color-background3);
  --zk-mesh-stripe-background-color: var(--zk-mesh-background-color);
  --zk-mesh-title-color: var(--zk-text-color-default3);
  --zk-mesh-title-background-color: var(--zk-color-primary);
  --zk-mesh-title-hover-color: var(--zk-mesh-title-color);
  --zk-mesh-title-hover-background-color: var(--zk-color-primary-light);
  --zk-mesh-title-active-color: var(--zk-mesh-title-color);
  --zk-mesh-title-active-background-color: var(--zk-color-primary-dark);
  --zk-mesh-title-border-color: var(--zk-color-primary-dark);
  --zk-mesh-content-border-color: var(--zk-color-grey-lighter);
  --zk-mesh-content-focus-background-color: var(--zk-selected-background-color);
  --zk-mesh-foot-background-color: var(--zk-color-grey-lighter);
  --zk-mesh-group-color: var(--zk-text-color-light);
  --zk-mesh-group-border-color: var(--zk-base-border-color);
  --zk-mesh-group-background-color: var(--zk-color-background3);
  --zk-mesh-group-footer-color: var(--zk-text-color-lighter);
  --zk-mesh-group-footer-background-color: var(--zk-color-background3);
  --zk-mesh-group-open-color: var(--zk-color-primary);
  --zk-mesh-group-open-background-color: var(--zk-color-background3);
  --zk-mesh-group-open-border: 2px solid var(--zk-color-primary);
  --zk-mesh-group-footer-open-color: var(--zk-color-primary-light);
  --zk-grid-detail-content-padding: 0 12px 12px 0;
  --zk-grid-detail-content-before-margin: 0 0 12px 0;
  --zk-auxhead-content-padding: var(--zk-mesh-body-padding);
  --zk-mesh-body-padding: 4px 5px;
  --zk-mesh-empty-body-padding: 9px 5px;
  --zk-mesh-content-line-height: 24px;
  --zk-mesh-column-sort-icon-top: -5px;
  --zk-mesh-column-sort-button-width: 34px;
  --zk-mesh-column-sort-button-height: 32px;
  --zk-mesh-row-detail-outer-padding: 3px 6px;
  --zk-treecell-content-line-height: var(--zk-mesh-content-line-height);
  --zk-listheader-checked-position-left: 2px;
  --zk-listbox-radio-icon-size: 12px;
  --zk-mesh-focus-box-shadow-color: var(--zk-color-accent);
  --zk-mesh-title-focus-box-shadow-color: var(--zk-color-accent);
  --zk-mesh-cell-focus-box-shadow-color: var(--zk-color-primary);
  --zk-mesh-focus-box-shadow: 0 0 0 2px var(--zk-mesh-focus-box-shadow-color);
  --zk-mesh-title-focus-box-shadow: inset 0 0 0 2px var(--zk-mesh-title-focus-box-shadow-color);
  --zk-mesh-cell-focus-box-shadow: inset 0 0 0 2px var(--zk-mesh-cell-focus-box-shadow-color);
  --zk-active-color: var(--zk-text-color-default3);
  --zk-active-border-color: transparent;
  --zk-active-background-color: var(--zk-color-primary-dark);
  --zk-active-gradient-start: var(--zk-active-background-color);
  --zk-active-gradient-end: var(--zk-active-background-color);
  --zk-focus-color: var(--zk-text-color-default3);
  --zk-focus-border-color: var(--zk-color-accent);
  --zk-focus-background-color: var(--zk-color-primary);
  --zk-focus-gradient-start: var(--zk-focus-background-color);
  --zk-focus-gradient-end: var(--zk-focus-background-color);
  --zk-hover-color: var(--zk-base-text-color);
  --zk-hover-border-color: transparent;
  --zk-hover-background-color: var(--zk-color-primary-lighter);
  --zk-hover-gradient-start: var(--zk-hover-background-color);
  --zk-hover-gradient-end: var(--zk-hover-background-color);
  --zk-disabled-color: var(--zk-text-color-lighter);
  --zk-disabled-background-color: var(--zk-color-grey-lighter);
  --zk-disabled-opacity: 1;
  --zk-invalid-border-color: var(--zk-color-accent2);
  --zk-readonly-border-color: var(--zk-base-border-color);
  --zk-readonly-background-color: var(--zk-color-grey-lighter);
  --zk-selected-color: var(--zk-base-text-color);
  --zk-selected-border-color: transparent;
  --zk-selected-background-color: var(--zk-color-primary-light);
  --zk-selected-hover-color: var(--zk-base-text-color);
  --zk-selected-hover-border-color: transparent;
  --zk-selected-hover-background-color: var(--zk-selected-background-color);
  --zk-selected-focus-color: var(--zk-base-text-color);
  --zk-selected-focus-border-color: transparent;
  --zk-selected-focus-background-color: var(--zk-selected-background-color);
  --zk-checked-icon-size: calc(var(--zk-checkbox-size) - 2px);
  --zk-checked-color: var(--zk-color-primary);
  --zk-checked-border-color: var(--zk-base-border-color);
  --zk-checked-background-color: var(--zk-text-color-default3);
  --zk-container-background: var(--zk-color-background1);
  --zk-container-padding: 5px;
  --zk-container-border-color: var(--zk-color-grey-dark);
  --zk-container-border-radius: var(--zk-base-border-radius);
  --zk-container-header-text-size: var(--zk-font-size-medium);
  --zk-container-header-color: var(--zk-text-color-light);
  --zk-container-body-text-size: var(--zk-font-size-medium);
  --zk-container-body-color: var(--zk-text-color-default);
  --zk-container-button-size: var(--zk-font-size-large);
  --zk-container-button-color: var(--zk-text-color-light);
  --zk-container-button-hover-color: var(--zk-text-color-default);
  --zk-container-button-padding: 0;
  --zk-panel-header-padding: 7px 5px 5px;
  --zk-window-header-padding: 3px 0 5px;
  --zk-window-ghost-header-padding: 8px 5px 5px;
  --zk-messagebox-padding-horizontal: 16px;
  --zk-messagebox-padding: 2px var(--zk-messagebox-padding-horizontal) 12px;
  --zk-messagebox-window-padding: var(--zk-container-padding);
  --zk-messagebox-window-width: 360px;
  --zk-messagebox-window-content-padding: 16px 0px;
  --zk-messagebox-header-padding: 5px 8px;
  --zk-messagebox-viewport-margin-bottom: 12px;
  --zk-messagebox-buttons-margin-left: 4px;
  --zk-messagebox-icon-margin-left: 16px;
  --zk-messagebox-icon-size: var(--zk-base-bar-width);
  --zk-borderlayout-header-font-size: var(--zk-font-size-medium);
  --zk-borderlayout-header-height: var(--zk-base-bar-height);
  --zk-borderlayout-header-padding: 8px 4px 9px;
  --zk-borderlayout-header-color: var(--zk-text-color-light);
  --zk-borderlayout-header-background-color: var(--zk-base-background-color);
  --zk-borderlayout-body-line-height: 14px;
  --zk-borderlayout-body-padding: 2px;
  --zk-borderlayout-collapsed-size: 32px;
  --zk-borderlayout-collapsed-padding: 4px;
  --zk-borderlayout-collapsed-icon-color: var(--zk-text-color-light);
  --zk-borderlayout-collapsed-icon-hover-color: var(--zk-text-color-light);
  --zk-borderlayout-icon-font-size: var(--zk-font-size-medium);
  --zk-borderlayout-icon-size: 24px;
  --zk-borderlayout-icon-position-top: 4px;
  --zk-borderlayout-icon-position-right: 3px;
  --zk-caption-font-size: var(--zk-font-size-medium);
  --zk-caption-elements-margin: 4px;
  --zk-caption-button-padding: var(--zk-button-padding);
  --zk-caption-image-max-size: 16px;
  --zk-caption-button-font-size: var(--zk-input-text-size);
  --zk-groupbox-header-font-size: var(--zk-font-size-medium);
  --zk-groupbox-header-color: var(--zk-text-color-light);
  --zk-groupbox-content-padding: var(--zk-container-padding);
  --zk-groupbox-notitle-content-padding: var(--zk-container-padding);
  --zk-groupbox-3d-header-padding: 6px 8px;
  --zk-groupbox-3d-content-padding: var(--zk-container-padding);
  --zk-groupbox-focus-box-shadow-color: var(--zk-color-primary);
  --zk-groupbox-focus-box-shadow: 0 0 0 2px var(--zk-groupbox-focus-box-shadow-color);
  --zk-groupbox-focus-border-radius: var(--zk-base-border-radius);
  --zk-toolbar-horizontal-padding: 13px;
  --zk-toolbar-padding: 4px var(--zk-toolbar-horizontal-padding);
  --zk-toolbar-buttons-spacing: 6px;
  --zk-toolbar-in-tabbox-min-height: 30px;
  --zk-toolbar-overflowpopup-button-size: var(--zk-font-size-large);
  --zk-input-text-size: var(--zk-font-size-medium);
  --zk-input-border-color: var(--zk-base-border-color);
  --zk-input-border-radius: var(--zk-base-border-radius);
  --zk-input-background-color: var(--zk-color-background3);
  --zk-input-height: 24px;
  --zk-input-padding: 4px 5px;
  --zk-input-padding-right: 5px;
  --zk-input-color: var(--zk-text-color-default);
  --zk-input-placeholder-color: var(--zk-text-color-lighter);
  --zk-input-hover-border-color: var(--zk-color-grey-dark);
  --zk-input-focus-border-color: var(--zk-color-primary);
  --zk-input-disable-color: var(--zk-text-color-lighter);
  --zk-input-disable-background-color: var(--zk-color-grey-lighter);
  --zk-input-readonly-color: var(--zk-text-color-default);
  --zk-input-readonly-background-color: var(--zk-color-grey-lighter);
  --zk-input-line-height: 14px;
  --zk-checkbox-size: 18px;
  --zk-checkbox-margin: 0 4px 2px 4px;
  --zk-checkbox-hover-border-color: var(--zk-color-primary);
  --zk-checkbox-switch-margin: 3px 6px 6px;
  --zk-checkbox-switch-width: 38px;
  --zk-checkbox-switch-height: 14px;
  --zk-checkbox-switch-size: 18px;
  --zk-checkbox-switch-step: 26px;
  --zk-checkbox-switch-offset-left: -2px;
  --zk-checkbox-switch-offset-bottom: -2px;
  --zk-checkbox-toggle-size: 20px;
  --zk-button-padding: 2px 11px;
  --zk-button-color: var(--zk-text-color-default3);
  --zk-button-background-color: var(--zk-color-primary);
  --zk-button-border-width: 2px;
  --zk-button-border-color: transparent;
  --zk-button-hover-color: var(--zk-text-color-default3);
  --zk-button-hover-background-color: var(--zk-color-primary-light);
  --zk-button-hover-border-color: transparent;
  --zk-button-focus-color: var(--zk-text-color-default3);
  --zk-button-focus-background-color: var(--zk-color-primary);
  --zk-button-focus-border-color: var(--zk-color-accent);
  --zk-button-active-color: var(--zk-text-color-default3);
  --zk-button-active-background-color: var(--zk-color-primary-dark);
  --zk-button-active-border-color: transparent;
  --zk-button-disable-color: var(--zk-text-color-lighter);
  --zk-button-disable-background-color: var(--zk-color-grey-light);
  --zk-button-disable-border-color: transparent;
  --zk-button-separator-border-color: var(--zk-color-primary-dark);
  --zk-button-disable-separator-border-color: var(--zk-base-border-color);
  --zk-toolbar-button-font-size: var(--zk-font-size-medium);
  --zk-toolbar-button-padding: var(--zk-button-padding);
  --zk-toolbar-button-color: var(--zk-text-color-light);
  --zk-toolbar-button-background-color: transparent;
  --zk-toolbar-button-checked-color: var(--zk-text-color-default3);
  --zk-toolbar-button-checked-background-color: var(--zk-color-primary);
  --zk-combobutton-padding: 4px calc(6px + var(--zk-combobutton-button-width)) 4px 6px;
  --zk-combobutton-button-width: 26px;
  --zk-combobutton-button-icon-left: 5px;
  --zk-combobutton-toolbar-font-size: var(--zk-font-size-medium);
  --zk-combobutton-toolbar-padding: var(--zk-combobutton-padding);
  --zk-combo-button-icon-size: 18px;
  --zk-combo-button-icon-size-large: 18px;
  --zk-combo-button-padding: 2px;
  --zk-combo-button-min-width: 24px;
  --zk-combo-button-icon-color: var(--zk-text-color-default);
  --zk-combo-button-hover-border-color: var(--zk-color-primary-light);
  --zk-combo-button-hover-background-color: var(--zk-color-primary-lighter);
  --zk-combo-button-active-icon-color: var(--zk-text-color-default3);
  --zk-combo-button-active-border-color: var(--zk-color-primary-dark);
  --zk-combo-button-active-background-color: var(--zk-color-primary);
  --zk-combo-popup-border-color: var(--zk-color-primary);
  --zk-combo-popup-item-size: var(--zk-font-size-medium);
  --zk-combo-popup-item-color: var(--zk-text-color-default);
  --zk-combo-popup-icon-size: var(--zk-font-size-large);
  --zk-combo-popup-icon-color: var(--zk-text-color-default);
  --zk-combo-popup-desc-size: var(--zk-font-size-x-small);
  --zk-combo-popup-desc-color: var(--zk-text-color-light);
  --zk-combo-popup-item-hover-background-color: var(--zk-color-primary-lighter);
  --zk-combo-popup-item-selected-color: var(--zk-color-primary);
  --zk-combo-input-height: 24px;
  --zk-combo-input-padding-right: calc(var(--zk-input-padding-right) + var(--zk-combo-button-min-width));
  --zk-spinner-button-width: var(--zk-combo-button-min-width);
  --zk-spinner-button-icon-height: calc(var(--zk-combo-input-height) / 2);
  --zk-spinner-button-icon-transform: translateY(-4px);
  --zk-spinner-button-icon-position-top: 50%;
  --zk-spinner-button-padding: 0;
  --zk-comboitem-padding: 3px;
  --zk-comboitem-empty-height: 20px;
  --zk-comboitem-inner-font-size: var(--zk-font-size-medium);
  --zk-timepicker-button-width: var(--zk-combo-button-min-width);
  --zk-timepicker-height: var(--zk-combo-input-height);
  --zk-timepicker-line-height: var(--zk-font-size-medium);
  --zk-timepicker-padding-right: calc(var(--zk-input-padding-right) + var(--zk-timepicker-button-width));
  --zk-timepicker-button-padding: 3px 0 0;
  --zk-timepicker-popup-padding: 3px;
  --zk-colorbox-button-font-size: var(--zk-font-size-large);
  --zk-colorbox-width: 48px;
  --zk-colorbox-height: 32px;
  --zk-colorbox-menu-image-size: 12px;
  --zk-colorbox-menu-image-margin-right: 14px;
  --zk-colorbox-padding: 3px;
  --zk-colorbox-popup-padding: 0;
  --zk-colorpicker-width: 306px;
  --zk-colorpicker-height: 420px;
  --zk-colorpicker-padding: 4px;
  --zk-colorpicker-main-position-top: 30px;
  --zk-colorpicker-info-height: 114px;
  --zk-colorpicker-info-margin-top: 12px;
  --zk-colorpicker-color-width: 56px;
  --zk-colorpicker-color-height: 72px;
  --zk-colorpicker-color-position-right: 8px;
  --zk-colorpicker-color-item-width: 50px;
  --zk-colorpicker-color-item-height: 33px;
  --zk-colorpicker-input-width: 40px;
  --zk-colorpicker-input-height: 24px;
  --zk-colorpicker-rgb-position-top: 5px;
  --zk-colorpicker-hsv-position-top: 40px;
  --zk-colorpicker-hex-position-top: 76px;
  --zk-colorpicker-hex-input-width: 72px;
  --zk-colorpicker-hex-input-height: 32px;
  --zk-colorpicker-button-width: 42px;
  --zk-colorpicker-button-position-top: 82px;
  --zk-colorpicker-button-position-right: 8px;
  --zk-colorpalette-width: 260px;
  --zk-colorpalette-height: 226px;
  --zk-colorpalette-head-height: 35px;
  --zk-colorpalette-new-color-width: 35px;
  --zk-colorpalette-new-color-height: 30px;
  --zk-colorpalette-new-color-position-right: 77px;
  --zk-colorpalette-input-width: 72px;
  --zk-colorpalette-input-height: 30px;
  --zk-colorpalette-color-size: 12px;
  --zk-colorbox-icon-font-size: var(--zk-font-size-large);
  --zk-colorbox-icon-padding: 3px;
  --zk-colorbox-icon-button-width: 22px;
  --zk-colorbox-icon-button-height: 22px;
  --zk-colorbox-icon-button-position-top: 5px;
  --zk-paletteicon-position-left: 5px;
  --zk-pickericon-position-top-left: 30px;
  --zk-mask-background-color: #E0E1E3;
  --zk-loading-background-color: var(--zk-base-background-color);
  --zk-loading-text-color: var(--zk-text-color-light);
  --zk-loading-indicator-padding: 10px 16px 4px;
  --zk-apply-loading-indicator-padding: 3px 4px 3px 28px;
  --zk-apply-loading-icon-size: 20px;
  --zk-apply-loading-icon-position-left: 2px;
  --zk-loading-icon-size: 20px;
  --zk-loading-icon-margin-bottom: 0;
  --zk-scrollbar-size: 10px;
  --zk-scrollbar-embedded-size: 10px;
  --zk-scrollbar-bar-size: 10px;
  --zk-scrollbar-rail-size: 6px;
  --zk-scrollbar-embedded-color: var(--zk-color-grey-light);
  --zk-scrollbar-border-color: transparent;
  --zk-scrollbar-background-color: var(--zk-color-grey-light);
  --zk-scrollbar-bar-background-color: var(--zk-color-primary);
  --zk-scrollbar-bar-hover-background: var(--zk-color-primary-dark);
  --zk-scrollbar-icon-display: none;
  --zk-scrollbar-button-background: transparent;
  --zk-scrollbar-button-hover-background: transparent;
  --zk-scrollbar-button-color: var(--zk-color-primary);
  --zk-scrollbar-button-hover-color: var(--zk-color-primary-dark);
  --zk-drag-color: var(--zk-text-color-default);
  --zk-drag-background-color: var(--zk-popup-background-color);
  --zk-drag-hover-background-color: var(--zk-color-primary-lighter);
  --zk-drag-allow-icon-color: var(--zk-color-primary);
  --zk-drag-allow-border-color: var(--zk-color-primary);
  --zk-drag-allow-background-color: var(--zk-popup-background-color);
  --zk-drag-disallow-icon-color: var(--zk-text-color-lighter);
  --zk-drag-disallow-border-color: transparent;
  --zk-drag-disallow-background-color: var(--zk-color-grey-lighter);
  --zk-drop-content-padding: 5px 36px 5px 12px;
  --zk-drop-content-line-height: 22px;
  --zk-drop-icon-size: 16px;
  --zk-drop-icon-vertical-align: middle;
  --zk-splitter-size: 8px;
  --zk-splitter-border-color: var(--zk-base-border-color);
  --zk-splitter-background-color: var(--zk-color-background1);
  --zk-splitter-hover-background-color: var(--zk-color-primary-lighter);
  --zk-splitter-button-text-size: 12px;
  --zk-splitter-button-text-color: var(--zk-text-color-lighter);
  --zk-splitter-button-text-hover-color: var(--zk-text-color-lighter);
  --zk-splitter-drag-background-color: var(--zk-color-grey-light);
  --zk-calendar-background-color: var(--zk-color-background3);
  --zk-calendar-today-color: var(--zk-text-color-light);
  --zk-calendar-title-color: var(--zk-base-text-color);
  --zk-calendar-title-hover-color: var(--zk-base-text-color);
  --zk-calendar-cell-color: var(--zk-base-text-color);
  --zk-calendar-cell-hover-background-color: var(--zk-color-primary-lighter);
  --zk-calendar-selected-color: var(--zk-text-color-default3);
  --zk-calendar-selected-hover-color: var(--zk-text-color-default3);
  --zk-calendar-selected-background-color: var(--zk-color-primary);
  --zk-calendar-selected-hover-background-color: var(--zk-color-primary);
  --zk-calendar-week-title-color: var(--zk-text-color-light);
  --zk-weekend-color: var(--zk-base-text-color);
  --zk-weekend-background-color: transparent;
  --zk-weekday-color: var(--zk-base-text-color);
  --zk-weekday-background-color: transparent;
  --zk-weekofyear-color: var(--zk-text-color-lighter);
  --zk-weekofyear-background-color: transparent;
  --zk-calendar-font-size: 14px;
  --zk-calendar-icon-font-size: 16px;
  --zk-calendar-title-font-size: var(--zk-calendar-font-size);
  --zk-calendar-font-size-small: var(--zk-font-size-medium);
  --zk-calendar-padding: 8px 4px;
  --zk-calendar-title-line-height: 26px;
  --zk-calendar-today-title-padding: 4px 0;
  --zk-calendar-cell-width: 32px;
  --zk-calendar-cell-height: 24px;
  --zk-calendar-left-right-position: 0;
  --zk-calendar-today-margin-top: 5px;
  --zk-base-popup-z-index: 88000;
  --zk-popup-padding: 4px 10px;
  --zk-popup-border-color: var(--zk-base-border-color);
  --zk-popup-background-color: var(--zk-color-background3);
  --zk-paging-color: var(--zk-text-color-default);
  --zk-paging-height: 32px;
  --zk-paging-border-color: var(--zk-base-border-color);
  --zk-paging-background-color: var(--zk-color-grey-lighter);
  --zk-paging-item-hover-background-color: var(--zk-color-primary-lighter);
  --zk-paging-item-active-color: var(--zk-text-color-default3);
  --zk-paging-item-active-background-color: var(--zk-color-primary);
  --zk-paging-item-selected-color: var(--zk-color-primary);
  --zk-paging-item-selected-background-color: transparent;
  --zk-paging-button-min-width: 24px;
  --zk-paging-button-height: 24px;
  --zk-paging-button-font-size: var(--zk-font-size-medium);
  --zk-paging-button-padding: 4px 3px;
  --zk-paging-button-margin: 0;
  --zk-paging-button-focus-box-shadow-color: var(--zk-color-primary);
  --zk-paging-button-focus-box-shadow: 0 0 0 2px var(--zk-paging-button-focus-box-shadow-color);
  --zk-paging-button-focus-border-radius: var(--zk-base-border-radius);
  --zk-paging-icon-size: 18px;
  --zk-paging-icon-line-height: 18px;
  --zk-paging-input-height: 24px;
  --zk-paging-input-padding: 0 8px;
  --zk-paging-os-button-padding: 4px 3px;
  --zk-slider-area-size: 6px;
  --zk-slider-background-color: var(--zk-color-grey-light);
  --zk-slider-area-background-color: var(--zk-color-primary);
  --zk-slider-input-color: var(--zk-text-color-active);
  --zk-slider-popup-font-size: var(--zk-font-size-medium);
  --zk-tooltip-color: var(--zk-text-color-default3);
  --zk-tooltip-background-color: var(--zk-color-accent3);
  --zk-errorbox-color: var(--zk-color-accent2);
  --zk-errorbox-border-color: transparent;
  --zk-errorbox-background-color: #FFEAEC;
  --zk-errorbox-inside-icon-position-top: 5px;
  --zk-errorbox-icon-position-top: -6px;
  --zk-errorbox-up-icon-position-top: 13px;
  --zk-errorbox-content-padding: 5px 20px 5px 34px;
  --zk-error-padding: 12px 8px;
  --zk-error-message-content-padding: 6px 0;
  --zk-error-button-font-size: 14px;
  --zk-error-close-button-font-size: 14px;
  --zk-error-number-font-size: var(--zk-font-size-medium);
  --zk-error-button-size: 14px;
  --zk-error-button-margin-left: 5px;
  --zk-notification-info-color: #4AA81B;
  --zk-notification-warning-color: #E37601;
  --zk-notification-error-color: #F53142;
  --zk-notification-info-text-color: var(--zk-base-text-color);
  --zk-notification-warning-text-color: var(--zk-base-text-color);
  --zk-notification-error-text-color: var(--zk-base-text-color);
  --zk-notification-info-background-color: var(--zk-base-background-color);
  --zk-notification-warning-background-color: var(--zk-base-background-color);
  --zk-notification-error-background-color: var(--zk-base-background-color);
  --zk-notification-content-padding: 32px 16px 32px 56px;
  --zk-notification-pointer-content-height: 50px;
  --zk-notification-pointer-content-padding: 8px 34px 8px 48px;
  --zk-notification-close-font-size: 14px;
  --zk-notification-close-icon-size: 14px;
  --zk-progressmeter-border-color: var(--zk-base-border-color);
  --zk-progressmeter-background-color: var(--zk-color-primary);
  --zk-loadingbar-color: var(--zk-color-primary);
  --zk-loadingbar-secondary-color: var(--zk-color-primary-light);
  --zk-loadingbar-height: 6px;
  --zk-tabbox-background-color: var(--zk-color-background3);
  --zk-tabbox-icon-padding: 5px 0;
  --zk-tabbox-icon-vertical-padding: 4px 0;
  --zk-tabbox-icon-size: 24px;
  --zk-tabbox-tabs-background-color: var(--zk-color-background3);
  --zk-tabbox-toolbar-background-color: var(--zk-tabbox-tabs-background-color);
  --zk-tabbox-tab-color: var(--zk-text-color-light);
  --zk-tabbox-tab-background-color: var(--zk-color-background3);
  --zk-tabbox-tab-hover-color: var(--zk-text-color-default);
  --zk-tabbox-tab-hover-background-color: var(--zk-color-background3);
  --zk-tabbox-tab-button-font-size: var(--zk-font-size-medium);
  --zk-tabbox-tab-button-color: var(--zk-icon-color);
  --zk-tabbox-tab-button-hover-color: var(--zk-icon-hover-color);
  --zk-tabbox-tab-button-text-spacing: 8px;
  --zk-tabbox-tab-separator-color: var(--zk-base-border-color);
  --zk-tabbox-tab-min-height: 32px;
  --zk-tabbox-tab-padding: 3px 13px;
  --zk-tabbox-tab-vertical-padding: 3px 13px;
  --zk-tabbox-tab-font-size: var(--zk-font-size-medium);
  --zk-tabbox-tab-accordion-button-right: 0;
  --zk-tabbox-selected-radius: 0;
  --zk-tabbox-selected-color: var(--zk-color-primary);
  --zk-tabbox-selected-border-color: var(--zk-color-primary);
  --zk-tabbox-selected-hover-color: var(--zk-color-primary-dark);
  --zk-tabbox-selected-background-color: var(--zk-color-background3);
  --zk-tabbox-selected-hover-background-color: var(--zk-color-background3);
  --zk-tabbox-scroll-icon-color: var(--zk-icon-color);
  --zk-tabbox-scroll-icon-hover-color: var(--zk-icon-hover-color);
  --zk-menu-background: var(--zk-base-background-color);
  --zk-menu-item-color: var(--zk-text-color-light);
  --zk-menu-item-background: var(--zk-base-background-color);
  --zk-menu-item-hover-color: var(--zk-text-color-light);
  --zk-menu-item-hover-background: var(--zk-hover-background-color);
  --zk-menu-item-active-color: var(--zk-active-color);
  --zk-menu-item-active-background: var(--zk-color-primary);
  --zk-menu-separator-border-color: var(--zk-base-border-color);
  --zk-menu-separator-background-color: var(--zk-color-grey-light);
  --zk-menu-popup-background: var(--zk-color-background3);
  --zk-menu-popup-item-color: var(--zk-text-color-light);
  --zk-menu-popup-item-background: var(--zk-color-background3);
  --zk-menu-popup-item-hover-color: var(--zk-text-color-light);
  --zk-menu-popup-item-hover-background: var(--zk-hover-background-color);
  --zk-menu-popup-item-active-color: var(--zk-active-color);
  --zk-menu-popup-item-active-background: var(--zk-color-primary);
  --zk-menu-popup-separator-border: var(--zk-color-grey-light);
  --zk-menu-image-size: var(--zk-menu-icon-size);
  --zk-menu-checked-color: var(--zk-checked-background-color);
  --zk-menu-checked-background-color: var(--zk-checked-color);
  --zk-menu-scrollable-icon-color: var(--zk-icon-color);
  --zk-menu-scrollable-icon-hover-color: var(--zk-icon-hover-color);
  --zk-menubar-padding: 0;
  --zk-menubar-horizontal-margin: 2px 0;
  --zk-menubar-horizontal-separator-line-height: 26px;
  --zk-menubar-horizontal-separator-margin: 2px 4px;
  --zk-menu-text-font-size: var(--zk-font-size-medium);
  --zk-menu-icon-size: 18px;
  --zk-menu-content-padding: 2px 6px;
  --zk-menu-content-line-height: 14px;
  --zk-menu-content-min-height: 24px;
  --zk-menu-icon-position-top: 2px;
  --zk-menu-icon-margin-right: 5px;
  --zk-menu-content-padding-right: 26px;
  --zk-menu-popup-item-icon-size: 14px;
  --zk-menu-popup-item-icon-position-top: 3px;
  --zk-menu-popup-item-icon-position-left: 8px;
  --zk-nav-image-size: 20px;
  --zk-nav-color: var(--zk-text-color-light);
  --zk-nav-hover-color: var(--zk-text-color-default);
  --zk-nav-border-color: var(--zk-base-border-color);
  --zk-nav-background-color: var(--zk-color-background3);
  --zk-nav-hover-background-color: var(--zk-nav-background-color);
  --zk-nav-selected-color: var(--zk-color-primary);
  --zk-nav-selected-background-color: var(--zk-nav-background-color);
  --zk-nav-popup-color: var(--zk-text-color-light);
  --zk-nav-popup-hover-color: var(--zk-text-color-default);
  --zk-nav-popup-background-color: var(--zk-color-background3);
  --zk-nav-popup-hover-background-color: var(--zk-nav-background-color);
  --zk-nav-popup-selected-color: var(--zk-color-primary);
  --zk-nav-popup-selected-background-color: var(--zk-nav-popup-background-color);
  --zk-nav-popup-padding: 0 4px 6px;
  --zk-nav-separator-color: var(--zk-color-grey-light);
  --zk-nav-collapsed-width: 32px;
  --zk-nav-badge-text-color: var(--zk-text-color-light);
  --zk-nav-badge-background-color: var(--zk-color-grey-light);
  --zk-navbar-padding: 0;
  --zk-navbar-horizontal-padding: 0 2px;
  --zk-navbar-horizontal-line-height: 36px;
  --zk-nav-content-padding: 6px 12px;
  --zk-nav-icon-margin-right: 8px;
  --zk-nav-text-font-size: var(--zk-font-size-medium);
  --zk-nav-info-position-top: 8px;
  --zk-nav-info-position-right: 16px;
  --zk-nav-text-popup-height: 38px;
  --zk-nav-text-popup-padding: 10px 18px 4px;
  --zk-nav-text-popup-line-height: 20px;
  --zk-navbar-collapsed-info-position-top: -2px;
  --zk-navitem-focus-box-shadow-color: var(--zk-color-primary);
  --zk-navitem-focus-box-shadow: 0 0 0 2px var(--zk-navitem-focus-box-shadow-color);
  --zk-chosenbox-icon-size: 16px;
  --zk-chosenbox-item-size: var(--zk-font-size-medium);
  --zk-chosenbox-item-color: var(--zk-text-color-default3);
  --zk-chosenbox-item-border-color: var(--zk-color-primary-dark);
  --zk-chosenbox-item-background-color: var(--zk-color-primary);
  --zk-chosenbox-item-focus-background-color: var(--zk-color-primary-dark);
  --zk-chosenbox-item-disabled-color: var(--zk-text-color-lighter);
  --zk-chosenbox-item-disabled-border-color: var(--zk-base-border-color);
  --zk-chosenbox-item-disabled-background-color: var(--zk-color-grey-light);
  --zk-chosenbox-popup-hover-background-color: var(--zk-color-primary-lighter);
  --zk-chosenbox-create-icon-size: var(--zk-font-size-large);
  --zk-chosenbox-create-icon-color: var(--zk-color-primary);
  --zk-chosenbox-padding: 0 0 2px 0;
  --zk-chosenbox-min-height: 25px;
  --zk-chosenbox-item-margin: 1px 0 0 2px;
  --zk-chosenbox-item-padding: 0;
  --zk-chosenbox-item-content-padding: 0 2px;
  --zk-chosenbox-item-content-margin-right: 16px;
  --zk-chosenbox-button-position-top: -1px;
  --zk-chosenbox-button-position-right: 2px;
  --zk-chosenbox-input-width: 17px;
  --zk-chosenbox-input-height: 17px;
  --zk-chosenbox-input-padding: 1px 2px 2px;
  --zk-chosenbox-popup-padding: 3px;
  --zk-chosenbox-option-padding: 1px 8px;
  --zk-chosenbox-option-min-height: 16px;
  --zk-biglistbox-frozen-background-color: var(--zk-color-grey-light);
  --zk-biglistbox-frozen-ghost-background-color: var(--zk-color-primary);
  --zk-biglistbox-scrollbar-border-color: var(--zk-base-border-color);
  --zk-biglistbox-scrollbar-text-color: var(--zk-text-color-light);
  --zk-biglistbox-scrollbar-end-bar-background-color: var(--zk-color-grey-lighter);
  --zk-biglistbox-scrollbar-hover-background-color: var(--zk-color-primary-lighter);
  --zk-biglistbox-scrollbar-active-background-color: var(--zk-color-primary);
  --zk-biglistbox-scrollbar-active-border-color: var(--zk-base-border-color);
  --zk-biglistbox-scrollbar-hover-border-color: var(--zk-color-grey-dark);
  --zk-biglistbox-outer-padding: 0 15px 15px 0;
  --zk-biglistbox-line-height: 19px;
  --zk-biglistbox-size: 15px;
  --zk-biglistbox-vertical-tick-width: 7px;
  --zk-biglistbox-vertical-tick-height: 15px;
  --zk-biglistbox-vertical-tick-position-bottom: 0;
  --zk-biglistbox-vertical-tick-before-position-left: -5px;
  --zk-biglistbox-wscroll-vertical-position-right: -16px;
  --zk-biglistbox-wscroll-drag-size: 119px;
  --zk-biglistbox-wscroll-button-size: 16px;
  --zk-biglistbox-wscroll-button-before-position-right: 2px;
  --zk-biglistbox-wscroll-button-body-size: 55px;
  --zk-biglistbox-wscroll-button-body-position-top: 32px;
  --zk-biglistbox-wscroll-button-body-before-position-top: 19px;
  --zk-biglistbox-wscroll-button-body-before-position-right: -1px;
  --zk-biglistbox-wscroll-button-body-hover-position-top: 31px;
  --zk-biglistbox-wscroll-button-up-hover-position-top: 15px;
  --zk-biglistbox-wscroll-horizontal-pos-width: 119px;
  --zk-rating-icon: #4a4a4a;
  --zk-rating-icon-size: 20px;
  --zk-rating-icon-font-size: 14px;
  --zk-rating-icon-padding: 3px 2px;
  --zk-rating-icon-hover: var(--zk-text-color-active);
  --zk-rating-icon-hover-text-shadow: #3393f9;
  --zk-rating-icon-selected: var(--zk-text-color-active);
  --zk-rating-disabled: var(--zk-color-grey-light);
  --zk-rating-disabled-selected: #b4d8ff;
  --zk-golden-layout-background-color: var(--zk-color-background1);
  --zk-golden-layout-border-color: #d2d2d2;
  --zk-golden-layout-header-color: var(--zk-text-color-light);
  --zk-golden-layout-header-hover-color: var(--zk-text-color-default);
  --zk-golden-layout-header-active-hover-color: var(--zk-color-primary-dark);
  --zk-golden-layout-header-background-color: var(--zk-color-background3);
  --zk-golden-layout-selected-border-color: var(--zk-color-primary);
  --zk-golden-layout-selected-background-color: var(--zk-color-background3);
  --zk-golden-layout-panel-background-color: var(--zk-color-background3);
  --zk-golden-layout-proxy-box-shadow-color: rgba(0, 0, 0, 0.19);
  --zk-golden-layout-droptarget-indicator-border-color: var(--zk-color-primary);
  --zk-golden-layout-droptarget-indicator-background-color: rgba(0, 147, 249, 0.15);
  --zk-golden-layout-splitter-dragging: var(--zk-color-grey-light);
  --zk-golden-layout-line-height: 24px;
  --zk-golden-layout-min-height: 30px;
  --zk-golden-layout-font-size: var(--zk-font-size-medium);
  --zk-golden-layout-tab-padding: 4px 12px 3px;
  --zk-golden-layout-close-tab-top: 0;
  --zk-golden-layout-active-tab-margin: -1px -13px;
  --zk-golden-layout-control-padding: 0;
  --zk-golden-layout-control-li-padding: 9px 11px 2px 5px;
  --zk-golden-layout-drop-tab-after-margin: -10px -12px;
  --zk-organigram-line: 1px solid #9B9B9B;
  --zk-orgnode-padding: 4px 10px;
  --zk-orgnode-color: var(--zk-text-color-default);
  --zk-orgnode-background-color: var(--zk-color-background3);
  --zk-orgnode-hover-background-color: #E8F5FF;
  --zk-orgnode-selected-color: #FFFFFF;
  --zk-orgnode-selected-background-color: var(--zk-color-primary);
  --zk-orgnode-disabled-color: #B0B0B0;
  --zk-orgnode-disabled-background-color: var(--zk-color-grey-lighter);
  --zk-orgnode-border: 1px solid rgba(0, 0, 0, 0.15);
  --zk-orgnode-border-radius: 4px;
  --zk-signature-border-color: var(--zk-base-border-color);
  --zk-signature-border-radius: var(--zk-base-border-radius);
  --zk-signature-toolbar-right: 10px;
  --zk-signature-toolbar-bottom: 6px;
  --zk-signature-toolbar-button-spacing: 5px;
  --zk-signature-toolbar-button-icon-font-size: 16px;
  --zk-drawer-mask-background-color: #000;
  --zk-drawer-mask-opacity: 0.5;
  --zk-drawer-title-text-color: var(--zk-text-color-light);
  --zk-drawer-title-line-color: var(--zk-color-grey-light);
  --zk-drawer-title-padding: 9px 8px;
  --zk-drawer-title-font-size: var(--zk-font-size-medium);
  --zk-drawer-close-button-size: 12px;
  --zk-drawer-close-button-right: 8px;
  --zk-drawer-close-button-top: 9px;
  --zk-drawer-background-color: var(--zk-color-background3);
  --zk-drawer-shadow-color: rgba(0, 0, 0, 0.3);
  --zk-drawer-container-padding: 8px;
  --zk-rangeslider-track-color: var(--zk-color-grey-light);
  --zk-rangeslider-empty-background-color: #FFF;
  --zk-rangeslider-shadow-color: rgba(0, 0, 0, 0.3);
  --zk-rangeslider-button-size: 16px;
  --zk-rangeslider-button-border-width: 2px;
  --zk-rangeslider-button-color: var(--zk-color-primary);
  --zk-rangeslider-button-hover-color: var(--zk-color-primary-light);
  --zk-rangeslider-button-active-color: var(--zk-color-primary-dark);
  --zk-rangeslider-button-focus-border-color: var(--zk-color-accent);
  --zk-rangeslider-disabled-track-color: var(--zk-color-grey-lighter);
  --zk-rangeslider-disabled-button-color: hsl(from var(--zk-rangeslider-button-color) h s calc(l + 30));
  --zk-rangeslider-border-radius: 3px;
  --zk-rangeslider-tooltip-border-radius: 2px;
  --zk-rangeslider-tooltip-background-color: rgba(0, 0, 0, 0.8);
  --zk-rangeslider-disabled-tooltip-background-color: rgba(0, 0, 0, 0.5);
  --zk-rangeslider-inner-size: 6px;
  --zk-rangeslider-dot-size: 12px;
  --zk-rangeslider-dot-border-width: 3px;
  --zk-rangeslider-label-font-size: var(--zk-font-size-medium);
  --zk-rangeslider-horizontal-button-margin-top: -5px;
  --zk-rangeslider-horizontal-button-margin-left: -8px;
  --zk-rangeslider-horizontal-tooltip-position-top: -8px;
  --zk-rangeslider-horizontal-tooltip-padding: 2px 4px;
  --zk-rangeslider-horizontal-mark-dot-position-top: -3px;
  --zk-rangeslider-horizontal-mark-label-position-top: 19px;
  --zk-rangeslider-vertical-tooltip-position-left: 24px;
  --zk-rangeslider-vertical-tooltip-padding: 4px 2px;
  --zk-multislider-track-color: var(--zk-color-grey-light);
  --zk-multislider-shadow-color: rgba(0, 0, 0, 0.2);
  --zk-multislider-button-size: 16px;
  --zk-multislider-button-border-width: 2px;
  --zk-multislider-button-color: var(--zk-color-primary);
  --zk-multislider-button-hover-color: var(--zk-color-primary-light);
  --zk-multislider-button-active-color: var(--zk-color-primary-dark);
  --zk-multislider-button-focus-border-color: var(--zk-color-accent);
  --zk-multislider-button-color2: var(--zk-color-primary-light);
  --zk-multislider-button-hover-color2: hsl(from var(--zk-multislider-button-color2) h s calc(l + 15));
  --zk-multislider-button-active-color2: hsl(from var(--zk-multislider-button-color2) h s calc(l - 20));
  --zk-multislider-border-radius: 2px;
  --zk-multislider-tooltip-background-color: rgba(0, 0, 0, 0.8);
  --zk-multislider-disabled-tooltip-background-color: rgba(0, 0, 0, 0.5);
  --zk-multislider-inner-size: 6px;
  --zk-multislider-disabled-track-color: var(--zk-color-grey-lighter);
  --zk-multislider-disabled-button-color: hsl(from var(--zk-multislider-button-color) h s calc(l + 30));
  --zk-multislider-disabled-button-color2: hsl(from var(--zk-multislider-button-color2) h s calc(l + 20));
  --zk-inputgroup-text-background-color: #E9ECEF;
  --zk-pdfviewer-container-background-color: gray;
  --zk-pdfviewer-selection-background-color: blue;
  --zk-pdfviewer-toolbar-background-color: var(--zk-color-background3);
  --zk-pdfviewer-toolbar-border-color: var(--zk-base-border-color);
  --zk-pdfviewer-toolbar-border-radius: var(--zk-base-border-radius);
  --zk-pdfviewer-toolbar-padding: 3px 8px;
  --zk-pdfviewer-toolbar-button-size: 24px;
  --zk-pdfviewer-toolbar-margins: 6px;
  --zk-pdfviewer-toolbar-button-color: var(--zk-text-color-default);
  --zk-pdfviewer-toolbar-button-background-color: var(--zk-color-background3);
  --zk-pdfviewer-toolbar-button-hover-color: var(--zk-text-color-default);
  --zk-pdfviewer-toolbar-button-hover-background-color: var(--zk-color-primary-lighter);
  --zk-pdfviewer-toolbar-button-active-color: var(--zk-text-color-default3);
  --zk-pdfviewer-toolbar-button-active-background-color: var(--zk-color-primary);
  --zk-pdfviewer-toolbar-separator-color: var(--zk-base-border-color);
  --zk-pdfviewer-toolbar-separator-height: 18px;
  --zk-pdfviewer-toolbar-page-active-width: 37px;
  --zk-searchbox-height: 24px;
  --zk-searchbox-font-size: var(--zk-font-size-medium);
  --zk-searchbox-padding: 0 5px;
  --zk-searchbox-border-color: var(--zk-input-border-color);
  --zk-searchbox-color: var(--zk-input-color);
  --zk-searchbox-placeholder-color: var(--zk-input-placeholder-color);
  --zk-searchbox-icon-color: var(--zk-icon-color);
  --zk-searchbox-icon-right: 0px;
  --zk-searchbox-icon-size: 18px;
  --zk-searchbox-background-color: var(--zk-input-background-color);
  --zk-searchbox-border-radius: var(--zk-input-border-radius);
  --zk-searchbox-hover-border-color: var(--zk-input-hover-border-color);
  --zk-searchbox-focus-border-color: var(--zk-input-focus-border-color);
  --zk-searchbox-active-border-color: var(--zk-color-primary-dark);
  --zk-searchbox-active-background-color: var(--zk-color-primary);
  --zk-searchbox-active-color: var(--zk-text-color-default3);
  --zk-searchbox-active-icon-color: var(--zk-text-color-default3);
  --zk-searchbox-disable-border-color: var(--zk-input-border-color);
  --zk-searchbox-disable-background-color: var(--zk-input-disable-background-color);
  --zk-searchbox-disable-color: var(--zk-input-disable-color);
  --zk-searchbox-disable-icon-color: var(--zk-icon-disabled-color);
  --zk-searchbox-popup-background-color: var(--zk-text-color-default3);
  --zk-searchbox-popup-border-color: var(--zk-combo-popup-border-color);
  --zk-searchbox-popup-border-radius: var(--zk-base-border-radius);
  --zk-searchbox-popup-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
  --zk-searchbox-popup-item-border-radius: var(--zk-base-border-radius);
  --zk-searchbox-popup-item-hover-background-color: var(--zk-color-primary-lighter);
  --zk-searchbox-popup-item-hover-color: var(--zk-text-color-default);
  --zk-searchbox-popup-item-active-background-color: var(--zk-color-primary-light);
  --zk-searchbox-popup-item-active-color: var(--zk-text-color-default);
  --zk-searchbox-popup-item-selected-color: var(--zk-text-color-active);
  --zk-searchbox-popup-item-padding: 4px 5px;
  --zk-searchbox-popup-item-check-size: 16px;
  --zk-searchbox-popup-item-check-margin-right: 5px;
  --zk-searchbox-popup-item-check-border-color: var(--zk-checked-border-color);
  --zk-searchbox-popup-item-check-border-radius: var(--zk-base-border-radius);
  --zk-searchbox-popup-item-check-background-color: var(--zk-base-background-color);
  --zk-searchbox-popup-item-check-checked-color: var(--zk-text-color-default3);
  --zk-searchbox-popup-item-check-checked-background-color: var(--zk-color-primary);
  --zk-stepbar-padding: 8px;
  --zk-stepbar-separator-size: 4px;
  --zk-step-size: 24px;
  --zk-step-font-size: 14px;
  --zk-step-icon-error-size: 16px;
  --zk-step-icon-complete-size: 16px;
  --zk-step-icon-empty-border-width: 3px;
  --zk-step-inactive-color: var(--zk-color-grey-light);
  --zk-step-active-color: var(--zk-color-primary);
  --zk-step-error-color: var(--zk-color-accent2);
  --zk-step-complete-color: var(--zk-color-primary);
  --zk-step-hover-color: var(--zk-color-primary-light);
  --zk-step-click-color: var(--zk-color-primary-dark);
  --zk-portalchildren-frame-border-color: var(--zk-color-grey-dark);
  --zk-portalchildren-frame-radius: 4px;
  --zk-portalchildren-frame-background-color: var(--zk-color-background1);
  --zk-portalchildren-frame-margin: 10px;
  --zk-portalchildren-frame-padding: 8px;
  --zk-portalchildren-frame-title-font-family: var(--zk-base-title-font-family);
  --zk-portalchildren-frame-title-font-size: var(--zk-font-size-medium);
  --zk-portalchildren-frame-title-font-color: var(--zk-container-header-color);
  --zk-portalchildren-counter-radius: 10px;
  --zk-portalchildren-counter-padding: 4px;
  --zk-portalchildren-counter-background: var(--zk-color-grey-light);
  --zk-portalchildren-frame-panel-header-text-color: var(--zk-text-color-active);
  --zk-portalchildren-frame-panel-header-text-size: var(--zk-font-size-medium);
  --zk-portalchildren-frame-panel-header-padding: 6px 10px 0 10px;
  --zk-portalchildren-frame-panel-children-padding: 6px 10px;
  --zk-portalchildren-frame-panel-background-color: var(--zk-color-background3);
  --zk-portalchildren-frame-panel-padding: 8px;
  --zk-portalchildren-frame-drag-button-size: var(--zk-base-icon-width);
  --zk-portalchildren-frame-drag-button-color: var(--zk-color-grey-dark);
  --zk-linelayout-line-color: var(--zk-color-primary);
  --zk-linelayout-line-width: 4px;
  --zk-linelayout-cave-padding: 20px;
  --zk-linelayout-point-border: 0;
  --zk-linelayout-point-radius: 50%;
  --zk-linelayout-point-size: 24px;
  --zk-linelayout-point-icon-size: 16px;
  --zk-linelayout-point-icon-color: var(--zk-text-color-default3);
  --zk-linelayout-point-icon-fix-top: 0;
  --zk-linelayout-point-icon-fix-left: 0;
  --zk-linelayout-point-background-color: var(--zk-color-primary);
  --zk-linelayout-point-shadow: 0 0 4px rgba(0, 0, 0, 0.3);
  --zk-coachmark-padding: 8px;
  --zk-coachmark-padding-left: 10px;
  --zk-coachmark-padding-right: 22px;
  --zk-coachmark-icon-size: 14px;
  --zk-coachmark-mask-background: rgba(0, 0, 0, 0.5);
  --zk-coachmark-background-color: var(--zk-color-background3);
  --zk-cascader-height: 24px;
  --zk-cascader-line-height: 22px;
  --zk-cascader-color: var(--zk-text-color-default);
  --zk-cascader-font-size: var(--zk-font-size-medium);
  --zk-cascader-padding: 0 5px;
  --zk-cascader-separator-color: var(--zk-color-grey-light);
  --zk-cascader-border-color: var(--zk-input-border-color);
  --zk-cascader-border-radius: var(--zk-input-border-radius);
  --zk-cascader-background-color: var(--zk-input-background-color);
  --zk-cascader-icon-color: var(--zk-icon-color);
  --zk-cascader-placeholder-color: var(--zk-input-placeholder-color);
  --zk-cascader-active-border-color: var(--zk-color-primary-dark);
  --zk-cascader-active-background-color: var(--zk-color-primary);
  --zk-cascader-hover-border-color: var(--zk-input-hover-border-color);
  --zk-cascader-focus-border-color: var(--zk-input-focus-border-color);
  --zk-cascader-disable-color: var(--zk-input-disable-color);
  --zk-cascader-disable-background-color: var(--zk-input-disable-background-color);
  --zk-cascader-popup-border-color: var(--zk-combo-popup-border-color);
  --zk-cascader-popup-cave-padding: 3px;
  --zk-cascader-popup-item-padding: 0px 28px 0px 5px;
  --zk-cascader-popup-item-height: 24px;
  --zk-cascader-popup-item-hover-background-color: var(--zk-color-primary-lighter);
  --zk-cascader-popup-item-selected-color: var(--zk-color-primary);
  --zk-cropper-toolbar-button-font-size: var(--zk-font-size-medium);
  --zk-cropper-toolbar-button-padding: 5px 11px;
}
<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
/*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
/* Document
   ========================================================================== */
/**
 * 1. Correct the line height in all browsers.
 * 2. Prevent adjustments of font size after orientation changes in iOS.
 */
<c:if test="${empty c:property('org.zkoss.zul.theme.browserDefault')}">
html {
  line-height: normal;
  /* 1 */
  /* James chu, Potix, 20240124, reported issue: https://github.com/necolas/normalize.css/issues/865 */
  -webkit-text-size-adjust: 100%;
  /* 2 */
}
/* Sections
   ========================================================================== */
/**
 * Remove the margin in all browsers.
 */
body {
  margin: 0;
}
/**
 * Render the `main` element consistently in IE.
 */
main {
  display: block;
}
</c:if>
/**
 * Correct the font size and margin on `h1` elements within `section` and
 * `article` contexts in Chrome, Firefox, and Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>h1 {
  font-size: 2em;
  margin: 0.67em 0;
}
/* Grouping content
   ========================================================================== */
/**
 * 1. Add the correct box sizing in Firefox.
 * 2. Show the overflow in Edge and IE.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>hr {
  box-sizing: content-box;
  /* 1 */
  height: 0;
  /* 1 */
  overflow: visible;
  /* 2 */
}
/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>pre {
  font-family: monospace, monospace;
  /* 1 */
  font-size: 1em;
  /* 2 */
}
/* Text-level semantics
   ========================================================================== */
/**
 * Remove the gray background on active links in IE 10.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>a {
  background-color: transparent;
}
/**
 * 1. Remove the bottom border in Chrome 57-
 * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>abbr[title] {
  border-bottom: none;
  /* 1 */
  text-decoration: underline;
  /* 2 */
  text-decoration: underline dotted;
  /* 2 */
}
/**
 * Add the correct font weight in Chrome, Edge, and Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>b,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>strong {
  font-weight: bolder;
}
/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>code,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>kbd,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>samp {
  font-family: monospace, monospace;
  /* 1 */
  font-size: 1em;
  /* 2 */
}
/**
 * Add the correct font size in all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>small {
  font-size: 80%;
}
/**
 * Prevent `sub` and `sup` elements from affecting the line height in
 * all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>sub,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>sub {
  bottom: -0.25em;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>sup {
  top: -0.5em;
}
/* Embedded content
   ========================================================================== */
/**
 * Remove the border on images inside links in IE 10.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>img {
  vertical-align: middle;
  /* James chu, Potix, 20240125, aligns the image vertically with the text */
  border-style: none;
}
/* Forms
   ========================================================================== */
/**
 * 1. Change the font styles in all browsers.
 * 2. Remove the margin in Firefox and Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>optgroup,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>select,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea {
  font-family: inherit;
  /* 1 */
  font-size: 100%;
  /* 1 */
  line-height: 1.15;
  /* 1 */
  margin: 0;
  /* 2 */
  vertical-align: middle;
  /* James chu, Potix, 20240205, aligns vertically with the text */
}
/**
 * Show the overflow in IE.
 * 1. Show the overflow in Edge.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input {
  /* 1 */
  overflow: visible;
}
/**
 * Remove the inheritance of text transform in Edge, Firefox, and IE.
 * 1. Remove the inheritance of text transform in Firefox.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>select {
  /* 1 */
  text-transform: none;
}
/* James chu, Potix, 20240205, cursor should be pointer */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>label,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>select,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"],
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"] {
  cursor: pointer;
}
/**
 * Correct the inability to style clickable types in iOS and Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="button"],
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="reset"],
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="submit"] {
  -webkit-appearance: button;
  /* James chu, Potix, 20240205, cursor should be pointer */
  cursor: pointer;
}
/**
 * Remove the inner border and padding in Firefox.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button::-moz-focus-inner,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="button"]::-moz-focus-inner,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="reset"]::-moz-focus-inner,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="submit"]::-moz-focus-inner {
  border-style: none;
  padding: 0;
}
/**
 * Restore the focus styles unset by the previous rule.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>button:-moz-focusring,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="button"]:-moz-focusring,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="reset"]:-moz-focusring,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="submit"]:-moz-focusring {
  outline: 1px dotted ButtonText;
}
/**
 * Correct the padding in Firefox.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>fieldset {
  padding: 0.35em 0.75em 0.625em;
}
/**
 * 1. Correct the text wrapping in Edge and IE.
 * 2. Correct the color inheritance from `fieldset` elements in IE.
 * 3. Remove the padding so developers are not caught out when they zero out
 *    `fieldset` elements in all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>legend {
  box-sizing: border-box;
  /* 1 */
  color: inherit;
  /* 2 */
  display: table;
  /* 1 */
  max-width: 100%;
  /* 1 */
  padding: 0;
  /* 3 */
  white-space: normal;
  /* 1 */
}
/**
 * Add the correct vertical alignment in Chrome, Firefox, and Opera.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>progress {
  vertical-align: baseline;
}
/**
 * Remove the default vertical scrollbar in IE 10+.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea {
  overflow: auto;
}
/**
 * 1. Add the correct box sizing in IE 10.
 * 2. Remove the padding in IE 10.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="checkbox"],
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="radio"] {
  box-sizing: border-box;
  /* 1 */
  padding: 0;
  /* 2 */
}
/**
 * Correct the cursor style of increment and decrement buttons in Chrome.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="number"]::-webkit-inner-spin-button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="number"]::-webkit-outer-spin-button {
  height: auto;
}
/**
 * 1. Correct the odd appearance in Chrome and Safari.
 * 2. Correct the outline style in Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="search"] {
  -webkit-appearance: textfield;
  /* 1 */
  outline-offset: -2px;
  /* 2 */
}
/**
 * Remove the inner padding in Chrome and Safari on macOS.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[type="search"]::-webkit-search-decoration {
  -webkit-appearance: none;
}
/**
 * 1. Correct the inability to style clickable types in iOS and Safari.
 * 2. Change font properties to `inherit` in Safari.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>::-webkit-file-upload-button {
  -webkit-appearance: button;
  /* 1 */
  font: inherit;
  /* 2 */
}
/* Interactive
   ========================================================================== */
/*
 * Add the correct display in Edge, IE 10+, and Firefox.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>details {
  display: block;
}
/*
 * Add the correct display in all browsers.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>summary {
  display: list-item;
}
/* Misc
   ========================================================================== */
/**
 * Add the correct display in IE 10+.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>template {
  display: none;
}
/**
 * Add the correct display in IE 10.
 */
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>[hidden] {
  display: none;
}
@media print {
  * {
    text-shadow: none !important;
    box-shadow: none !important;
  }
  a,
  a:visited {
    text-decoration: underline;
  }
  a[href]:after {
    content: " (" attr(href) ")";
  }
  abbr[title]:after {
    content: " (" attr(title) ")";
  }
  .ir a:after,
  a[href^="javascript:"]:after,
  a[href^="#"]:after {
    content: "";
  }
  pre,
  blockquote {
    border: 1px solid #999;
    page-break-inside: avoid;
  }
  thead {
    display: table-header-group;
  }
  tr,
  img {
    page-break-inside: avoid;
  }
  @page {
    margin: 0.5cm;
  }
  p,
  h2,
  h3 {
    orphans: 3;
    widows: 3;
  }
  h2,
  h3 {
    page-break-after: avoid;
  }
}
<c:if test="${empty c:property('org.zkoss.zul.theme.browserDefault')}">
html,
body {
  height: 100%;
}
</c:if>
[class^="z-"],
[class*=" z-"],
[class^="z-"]:after,
[class*=" z-"]:after,
[class^="z-"]:before,
[class*=" z-"]:before,
.z-borderbox {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -o-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type=number]::-webkit-inner-spin-button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input:focus,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea:focus {
  -webkit-appearance: none;
  -moz-appearance: none;
  outline: none;
  -webkit-user-select: text;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>*:focus {
  outline: none;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>fieldset {
  border: 1px solid #c0c0c0;
  border-radius: 0;
  margin: 0 2px;
  padding: 0px;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>legend {
  border: 0;
  padding: 0;
}
.gecko button::-moz-focus-inner {
  border: 0;
}
<c:if test="${empty c:property('org.zkoss.zul.theme.browserDefault')}">
body {
  margin: 0;
  padding: 0 5px;
}
</c:if>
.mobile * {
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
.z-error {
  display: none;
  width: 450px;
  color: var(--zk-errorbox-color);
  border: 1px solid var(--zk-errorbox-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-error-padding);
  background: var(--zk-errorbox-background-color);
  position: absolute;
  top: 0;
  left: 40%;
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  z-index: 9999999;
}
.z-error .messagecontent {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  padding: var(--zk-error-message-content-padding);
}
.z-error .messages {
  word-wrap: break-word;
  overflow: auto;
}
.z-error .messages .message {
  margin-top: 8px;
}
.z-error .newmessage {
  background: var(--zk-errorbox-background-color);
  display: none;
}
.z-error .button {
  font-size: var(--zk-error-button-font-size);
  width: var(--zk-error-button-size);
  height: var(--zk-error-button-size);
  margin-left: var(--zk-error-button-margin-left);
  cursor: pointer;
  float: right;
}
.z-error .button > .z-icon-times {
  font-size: var(--zk-error-close-button-font-size);
}
.z-error #zk_err-p {
  height: 24px;
  cursor: move;
}
.z-error .errornumbers {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-error-number-font-size);
  font-weight: 700;
  font-style: normal;
  float: left;
}
div.z-log {
  width: 50%;
  text-align: right;
  position: absolute;
  right: 10px;
  bottom: 5px;
  z-index: 99000;
}
div.z-log textarea {
  width: 100%;
  border-color: rgba(82, 168, 236, 0.8);
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);
  -moz-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);
  -o-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);
  -ms-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);
  box-shadow: inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(82,168,236,0.6);
}
div.z-log button {
  font-size: var(--zk-font-size-x-small);
}
.noscript {
  width: 100%;
  height: 100%;
  background: #E0E1E3;
  opacity: 0.6;
  text-align: center;
  position: absolute;
  top: 0;
  left: 0;
  zoom: 1;
  z-index: 32000;
}
.noscript p {
  font-weight: bold;
  color: black;
  border: 1px solid black;
  margin: 10% 15%;
  padding: 10px 0;
  background: white;
  opacity: 1;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"] {
  margin: var(--zk-checkbox-margin);
  background: var(--zk-input-background-color);
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:hover {
  border-color: var(--zk-checkbox-hover-border-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:focus-visible {
  box-shadow: 0 0 0 2px var(--zk-focus-border-color);
  transition: unset;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:before {
  content: '';
  display: block;
  width: 12px;
  height: 12px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
  position: relative;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:checked {
  border-color: var(--zk-checked-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:checked:before {
  background-color: var(--zk-checked-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled] {
  cursor: default;
  background-color: var(--zk-input-disable-background-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled]:checked {
  border-color: var(--zk-input-disable-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled]:checked:before {
  background-color: var(--zk-input-disable-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled]:checked:hover {
  border-color: var(--zk-input-disable-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled]:hover {
  border-color: var(--zk-input-border-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]::-ms-check {
  border: 0;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"]:checked::-ms-check {
  border-color: var(--zk-checked-border-color);
  color: var(--zk-checked-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="radio"][disabled]:checked::-ms-check {
  border-color: var(--zk-input-disable-color);
  color: var(--zk-input-disable-color);
  border-radius: 50%;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"] {
  display: inline-block;
  font-family: ZK85Icons, FontAwesome;
  font-style: normal;
  font-weight: normal;
  font-size: inherit;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: auto;
  font-size: var(--zk-font-size-large);
  margin: var(--zk-checkbox-margin);
  background: var(--zk-input-background-color);
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: var(--zk-input-border-radius);
  -moz-border-radius: var(--zk-input-border-radius);
  -o-border-radius: var(--zk-input-border-radius);
  -ms-border-radius: var(--zk-input-border-radius);
  border-radius: var(--zk-input-border-radius);
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:hover {
  border-color: var(--zk-checkbox-hover-border-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:checked {
  background-color: var(--zk-checked-color);
  color: var(--zk-checked-background-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:checked:before {
  content: "\f00c";
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:indeterminate {
  background-color: var(--zk-checked-color);
  color: var(--zk-checked-background-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:indeterminate:before {
  content: "\f068";
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"][disabled] {
  cursor: default;
  color: var(--zk-input-disable-color);
  background-color: var(--zk-input-disable-background-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"][disabled]:hover {
  border-color: var(--zk-input-border-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]::-ms-check {
  border: 0;
  -webkit-border-radius: var(--zk-input-border-radius);
  -moz-border-radius: var(--zk-input-border-radius);
  -o-border-radius: var(--zk-input-border-radius);
  -ms-border-radius: var(--zk-input-border-radius);
  border-radius: var(--zk-input-border-radius);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"]:checked::-ms-check {
  border: 0;
  background-clip: content-box;
  background-color: var(--zk-checked-color);
  color: var(--zk-checked-background-color);
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type="checkbox"][disabled]:checked::-ms-check {
  background-color: var(--zk-input-disable-background-color);
  color: var(--zk-input-disable-color);
}
.z-label {
  line-height: normal;
}
.z-label,
.z-radio-content,
.z-checkbox-content,
.z-loading {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
}
.z-temp,
.z-modal-mask {
  width: 100%;
  height: 100%;
  background: var(--zk-mask-background-color);
  opacity: 0.6;
  position: fixed;
  top: 0;
  left: 0;
}
#zk_proc > .z-modal-mask {
  opacity: 1;
}
.mobile .z-temp,
.mobile .z-modal-mask {
  min-height: 100vh;
}
.z-initing {
  width: 60px;
  height: 60px;
  background: transparent no-repeat center;
  position: absolute;
  right: 10px;
  bottom: 10px;
  z-index: 32000;
}
.z-loading,
.z-apply-loading {
  background: var(--zk-loading-background-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  position: absolute;
  cursor: wait;
  white-space: nowrap;
}
.z-loading {
  top: 0;
  left: 0;
  z-index: 31000;
}
.z-apply-loading {
  z-index: 89500;
}
.z-loading-indicator,
.z-apply-loading-indicator {
  color: var(--zk-loading-text-color);
  background: var(--zk-loading-background-color);
  white-space: nowrap;
}
.z-loading-indicator {
  padding: var(--zk-loading-indicator-padding);
  text-align: center;
}
.z-apply-loading-indicator {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  padding: var(--zk-apply-loading-indicator-padding);
  position: relative;
  overflow: hidden;
}
.z-apply-loading-icon,
.z-renderdefer {
  width: var(--zk-apply-loading-icon-size);
  height: var(--zk-apply-loading-icon-size);
  background: transparent no-repeat center;
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/progress-32.gif")});
  background-size: contain;
}
.z-loading-icon {
  width: var(--zk-loading-icon-size);
  height: var(--zk-loading-icon-size);
  background: transparent no-repeat center;
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/progress-72.gif")});
  background-size: contain;
  display: block;
  vertical-align: top;
  position: relative;
  left: 50%;
  margin-left: calc(var(--zk-loading-icon-size) / -2);
  margin-bottom: var(--zk-loading-icon-margin-bottom);
}
.z-apply-loading-icon {
  display: inline-block;
  vertical-align: top;
  position: absolute;
  left: var(--zk-apply-loading-icon-position-left);
  top: 50%;
  margin-top: calc(var(--zk-apply-loading-icon-size) / -2);
}
.z-apply-mask {
  width: 100%;
  height: 100%;
  background: var(--zk-mask-background-color);
  opacity: 0.6;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 89000;
}
.z-inline-block {
  display: inline-block;
  vertical-align: top;
}
.z-word-wrap {
  word-wrap: break-word;
}
.z-word-nowrap {
  white-space: nowrap;
}
.z-overflow-hidden {
  overflow: hidden;
}
.z-dd-stackup {
  width: 100%;
  height: 100%;
  background-image: url(${c:encodeURL("data:image/gif;base64,R0lGODlhAQABAIAAAP///////yH5BAUUAAEALAAAAAABAAEAAAICTAEAOw==")});
  position: absolute;
  left: 0;
  top: 0;
  z-index: 16800;
}
.z-temp * {
  font-size: 5px;
  color: #FFFFFF;
  text-decoration: none;
}
.z-temp .z-loading {
  background: var(--zk-loading-background-color);
  top: 49%;
  left: 46%;
}
.z-temp .z-loading-indicator {
  font-size: var(--zk-font-size-medium);
  color: var(--zk-text-color-light);
}
.z-clear {
  font-size: 0;
  width: 0;
  height: 0;
  line-height: 0;
  overflow: hidden;
  clear: both;
}
.z-dragged {
  color: var(--zk-drag-color);
  background: none no-repeat scroll 0 0 var(--zk-drag-background-color);
}
.z-drag-over {
  background: var(--zk-drag-hover-background-color) !important;
}
.z-drag-ghost {
  list-style: none;
}
.gecko .z-draggable-over > * {
  -moz-user-select: none;
}
.z-drop-allow {
  background: var(--zk-drag-background-color);
  -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -o-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -ms-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  overflow: hidden;
}
.z-drop-allow .z-drop-content {
  background: var(--zk-drag-allow-background-color);
}
.z-drop-allow .z-drop-icon {
  color: var(--zk-drag-allow-icon-color);
}
.z-drop-disallow {
  background: var(--zk-drag-background-color);
  -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -o-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -ms-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  overflow: hidden;
}
.z-drop-disallow .z-drop-content {
  background: var(--zk-drag-disallow-background-color);
}
.z-drop-disallow .z-drop-icon {
  color: var(--zk-drag-disallow-icon-color);
}
.z-drop-disallow .z-drop-text {
  color: var(--zk-disabled-color);
}
.z-drop-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-drag-color);
  padding: var(--zk-drop-content-padding);
  line-height: var(--zk-drop-content-line-height);
  position: relative;
}
.z-drop-icon {
  font-size: var(--zk-drop-icon-size);
  width: var(--zk-drop-icon-size);
  height: var(--zk-drop-icon-size);
  line-height: var(--zk-drop-icon-size);
  background: transparent;
  text-align: center;
  vertical-align: var(--zk-drop-icon-vertical-align);
}
.z-drop-text {
  padding-left: 8px;
}
.z-focus-a {
  font-size: 0 !important;
  width: 1px !important;
  height: 1px !important;
  border: 0 !important;
  margin: 0 !important;
  padding: 0 !important;
  line-height: 0 !important;
  background: transparent !important;
  position: absolute;
  top: 0;
  left: 0;
  -moz-outline: 0 none;
  outline: 0 none;
  -moz-user-select: text;
  -khtml-user-select: text;
  overflow: hidden;
}
.z-focus-a:focus {
  -moz-outline: 0 none;
  outline: 0 none;
}
span.z-upload {
  font-size: 0;
  display: inline-block;
  width: 0;
  height: 0;
  margin: 0;
  padding: 0;
  position: relative;
}
span.z-upload input {
  font-size: 45pt;
  margin: 0;
  padding: 0;
  opacity: 0;
  position: absolute;
  cursor: pointer;
  z-index: -1;
}
.z-upload-icon {
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/prgmeter.png")});
  overflow: hidden;
}
.z-fileupload-add,
.z-fileupload-remove {
  color: #1096BC;
  width: 16px;
  height: 17px;
  cursor: pointer;
}
.z-fileupload-progress {
  width: 300px;
}
.z-fileupload-manager {
  width: 350px;
}
.z-scrollbar {
  display: none;
  position: absolute;
  line-height: 1;
}
.z-scrollbar-wrapper {
  position: absolute;
}
.z-scrollbar-indicator {
  border: 1px solid var(--zk-scrollbar-border-color);
  -webkit-border-radius: calc(var(--zk-scrollbar-bar-size) / 2);
  -moz-border-radius: calc(var(--zk-scrollbar-bar-size) / 2);
  -o-border-radius: calc(var(--zk-scrollbar-bar-size) / 2);
  -ms-border-radius: calc(var(--zk-scrollbar-bar-size) / 2);
  border-radius: calc(var(--zk-scrollbar-bar-size) / 2);
  background-color: var(--zk-scrollbar-bar-background-color);
  position: absolute;
  cursor: pointer;
  z-index: 100;
}
.z-scrollbar-indicator:hover {
  background-color: var(--zk-scrollbar-bar-hover-background);
}
.z-scrollbar-rail {
  position: absolute;
  width: 100%;
  height: 100%;
  background: var(--zk-scrollbar-background-color);
  -webkit-border-radius: calc(var(--zk-scrollbar-rail-size) / 2);
  -moz-border-radius: calc(var(--zk-scrollbar-rail-size) / 2);
  -o-border-radius: calc(var(--zk-scrollbar-rail-size) / 2);
  -ms-border-radius: calc(var(--zk-scrollbar-rail-size) / 2);
  border-radius: calc(var(--zk-scrollbar-rail-size) / 2);
}
.z-scrollbar-icon {
  display: var(--zk-scrollbar-icon-display);
  color: var(--zk-icon-color);
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  position: absolute;
}
.z-scrollbar-vertical {
  width: var(--zk-scrollbar-size);
  height: 100%;
  top: 0;
  right: 0;
  margin-right: 4px;
}
.z-scrollbar-vertical .z-scrollbar-wrapper {
  width: 100%;
  top: var(--zk-base-icon-height);
  left: 0;
}
.z-scrollbar-vertical .z-scrollbar-rail {
  width: var(--zk-scrollbar-rail-size);
  left: 3px;
}
.z-scrollbar-vertical .z-scrollbar-indicator {
  width: var(--zk-scrollbar-bar-size);
  left: 1px;
}
.z-scrollbar-vertical .z-scrollbar-icon {
  margin-top: -8px;
  left: -1px;
  top: 50%;
  -webkit-transform: scale(0.5, 0.7);
  -moz-transform: scale(0.5, 0.7);
  -o-transform: scale(0.5, 0.7);
  -ms-transform: scale(0.5, 0.7);
  transform: scale(0.5, 0.7);
}
.z-scrollbar-vertical-embed {
  -webkit-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -moz-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -o-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -ms-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  background-color: var(--zk-scrollbar-embedded-color);
  position: absolute;
  width: var(--zk-scrollbar-embedded-size);
  height: var(--zk-scrollbar-embedded-size);
  height: 100%;
  top: 0;
  right: 0;
}
.z-scrollbar-up,
.z-scrollbar-down {
  font-size: var(--zk-font-size-x-large);
  color: var(--zk-scrollbar-button-color);
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  background: var(--zk-scrollbar-button-background);
  position: absolute;
  cursor: pointer;
  margin-left: -4px;
}
.z-scrollbar-up:hover,
.z-scrollbar-down:hover {
  color: var(--zk-scrollbar-button-hover-color);
  background: var(--zk-scrollbar-button-hover-background);
}
.z-scrollbar-down {
  bottom: 0;
}
.z-scrollbar-horizontal {
  width: 100%;
  height: var(--zk-scrollbar-size);
  left: 0;
  bottom: 0;
  margin-bottom: 4px;
}
.z-scrollbar-horizontal .z-scrollbar-wrapper {
  height: 100%;
  bottom: 0;
  left: var(--zk-base-icon-width);
}
.z-scrollbar-horizontal .z-scrollbar-rail {
  height: var(--zk-scrollbar-rail-size);
  top: 3px;
}
.z-scrollbar-horizontal .z-scrollbar-indicator {
  height: var(--zk-scrollbar-bar-size);
  top: 1px;
}
.z-scrollbar-horizontal .z-scrollbar-icon {
  margin-left: -8px;
  left: 50%;
  top: -1px;
  -webkit-transform: rotate(90deg) scale(0.5, 0.7);
  -moz-transform: rotate(90deg) scale(0.5, 0.7);
  -o-transform: rotate(90deg) scale(0.5, 0.7);
  -ms-transform: rotate(90deg) scale(0.5, 0.7);
  transform: rotate(90deg) scale(0.5, 0.7);
}
.z-scrollbar-horizontal-embed {
  -webkit-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -moz-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -o-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  -ms-border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  border-radius: calc(var(--zk-scrollbar-embedded-size) / 2);
  background-color: var(--zk-scrollbar-embedded-color);
  position: absolute;
  width: var(--zk-scrollbar-embedded-size);
  height: var(--zk-scrollbar-embedded-size);
  width: 100%;
  bottom: 0;
  left: 0;
}
.z-scrollbar-left,
.z-scrollbar-right {
  font-size: var(--zk-font-size-x-large);
  color: var(--zk-scrollbar-button-color);
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  background: var(--zk-scrollbar-button-background);
  position: absolute;
  cursor: pointer;
  margin-top: -4px;
}
.z-scrollbar-left:hover,
.z-scrollbar-right:hover {
  color: var(--zk-scrollbar-button-hover-color);
  background: var(--zk-scrollbar-button-hover-background);
}
.z-scrollbar-right {
  right: 0;
}
.z-macro {
  display: inline-block;
  min-width: 1px;
}
