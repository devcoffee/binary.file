<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-groupbox {
  padding-top: 16px;
}
.z-groupbox > .z-groupbox-header {
  background: var(--zk-base-background-color);
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-groupbox-header-font-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-groupbox-header-color);
  width: 100%;
  height: var(--zk-base-icon-height);
  border: 1px solid var(--zk-base-border-color);
  border-bottom: 0;
  padding-left: 12px;
  line-height: normal;
  zoom: 1;
}
.z-groupbox > .z-groupbox-header .z-groupbox-title {
  height: auto;
  min-height: 24px;
  white-space: nowrap;
}
.z-groupbox > .z-groupbox-header .z-groupbox-title-content {
  display: inline-block;
  line-height: var(--zk-base-button-height);
  padding: 0 4px;
}
.z-groupbox > .z-groupbox-header .z-caption,
.z-groupbox > .z-groupbox-header .z-groupbox-title {
  display: inline;
  width: auto;
  padding: 0 4px;
  line-height: var(--zk-base-button-height);
  background: var(--zk-base-background-color);
  position: relative;
  cursor: pointer;
}
.z-groupbox > .z-groupbox-header .z-caption-readonly,
.z-groupbox > .z-groupbox-header .z-groupbox-title-readonly {
  cursor: default;
}
.z-groupbox > .z-groupbox-header .z-caption-content,
.z-groupbox > .z-groupbox-header .z-label {
  float: none;
}
.z-groupbox > .z-groupbox-readonly .z-groupbox-title {
  cursor: default;
}
.z-groupbox-content {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  background: var(--zk-base-background-color);
  display: block;
  height: inherit;
  border: 1px solid var(--zk-base-border-color);
  border-top: 0;
  padding: var(--zk-groupbox-content-padding);
  overflow: hidden;
  zoom: 1;
}
.z-groupbox-notitle {
  padding: 0;
}
.z-groupbox-notitle .z-groupbox-content {
  border-top: 1px solid var(--zk-base-border-color);
  padding: var(--zk-groupbox-notitle-content-padding);
}
.z-groupbox-collapsed .z-groupbox-header {
  border-left: 1px solid transparent;
  border-right: 1px solid transparent;
}
.z-groupbox-3d {
  padding: 0;
}
.z-groupbox-3d > .z-groupbox-header {
  height: auto;
  min-height: var(--zk-base-bar-height);
  border-bottom: 1px solid var(--zk-base-border-color);
  padding: 0;
}
.z-groupbox-3d > .z-groupbox-header .z-caption,
.z-groupbox-3d > .z-groupbox-header .z-groupbox-title {
  display: inline-block;
  width: 100%;
  margin: 0;
  padding: var(--zk-groupbox-3d-header-padding);
  line-height: var(--zk-base-button-height);
  background: none;
  top: 0;
}
.z-groupbox-3d > .z-groupbox-header .z-caption:has(> span:focus-visible) .z-caption-content {
  box-shadow: var(--zk-groupbox-focus-box-shadow);
  transition: unset;
  border-radius: var(--zk-groupbox-focus-border-radius);
}
.z-groupbox-3d > .z-groupbox-header .z-caption-content,
.z-groupbox-3d > .z-groupbox-header .z-groupbox-title-content {
  line-height: var(--zk-base-icon-height);
  font-size: var(--zk-groupbox-header-font-size);
  color: var(--zk-groupbox-header-color);
  padding: 0;
}
.z-groupbox-3d > .z-groupbox-header .z-caption-content > .z-caption-image,
.z-groupbox-3d > .z-groupbox-header .z-groupbox-title-content > .z-caption-image {
  margin-left: 0;
  margin-right: 4px;
}
.z-groupbox-3d > .z-groupbox-content {
  padding: var(--zk-groupbox-3d-content-padding);
}
.z-groupbox:not(.z-groupbox-3d) > .z-groupbox-header .z-caption:has(> span:focus-visible) {
  box-shadow: var(--zk-groupbox-focus-box-shadow);
  transition: unset;
  border-radius: var(--zk-groupbox-focus-border-radius);
}
