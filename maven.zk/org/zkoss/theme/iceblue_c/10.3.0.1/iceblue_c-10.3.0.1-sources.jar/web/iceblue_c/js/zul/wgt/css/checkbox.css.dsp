<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-checkbox-default > input[type="checkbox"]:focus-visible {
  box-shadow: 0 0 0 2px var(--zk-focus-border-color);
  transition: unset;
}
.z-checkbox-default > .z-checkbox-mold {
  display: none;
}
.z-checkbox-tristate > input[type="checkbox"]:focus-visible {
  box-shadow: 0 0 0 2px var(--zk-focus-border-color);
  transition: unset;
}
.z-checkbox-tristate > .z-checkbox-mold {
  display: none;
}
.z-checkbox-switch {
  display: inline-block;
}
.z-checkbox-switch > input[type="checkbox"] {
  display: none;
}
.z-checkbox-switch > .z-checkbox-mold {
  margin: var(--zk-checkbox-switch-margin);
  position: relative;
  width: var(--zk-checkbox-switch-width);
  height: var(--zk-checkbox-switch-height);
  transition: 0.4s;
  border-radius: calc(var(--zk-checkbox-switch-height) / 2);
  display: inline-block;
  vertical-align: middle;
}
.z-checkbox-switch > .z-checkbox-mold:before {
  content: "";
  position: absolute;
  width: var(--zk-checkbox-switch-size);
  height: var(--zk-checkbox-switch-size);
  left: var(--zk-checkbox-switch-offset-left);
  bottom: var(--zk-checkbox-switch-offset-bottom);
  transition: 0.4s;
  border-radius: 50%;
  background-color: white;
  -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -o-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  -ms-box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
  box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16);
}
.z-checkbox-switch > .z-checkbox-mold:focus {
  -webkit-box-shadow: 0 0 0px 2px var(--zk-focus-border-color);
  -moz-box-shadow: 0 0 0px 2px var(--zk-focus-border-color);
  -o-box-shadow: 0 0 0px 2px var(--zk-focus-border-color);
  -ms-box-shadow: 0 0 0px 2px var(--zk-focus-border-color);
  box-shadow: 0 0 0px 2px var(--zk-focus-border-color);
  transition: unset;
}
.z-checkbox-switch > .z-checkbox-content {
  display: inline-block;
}
.z-checkbox-switch-off > .z-checkbox-mold {
  background-color: var(--zk-disabled-color);
}
.z-checkbox-switch-on > .z-checkbox-mold {
  background-color: var(--zk-checked-color);
}
.z-checkbox-switch-on > .z-checkbox-mold:before {
  -webkit-transform: translateX(var(--zk-checkbox-switch-step));
  -moz-transform: translateX(var(--zk-checkbox-switch-step));
  -o-transform: translateX(var(--zk-checkbox-switch-step));
  -ms-transform: translateX(var(--zk-checkbox-switch-step));
  transform: translateX(var(--zk-checkbox-switch-step));
}
.z-checkbox-switch-disabled > .z-checkbox-mold {
  opacity: 0.5;
  cursor: default;
}
.z-checkbox-toggle {
  display: inline-block;
}
.z-checkbox-toggle > input[type="checkbox"] {
  display: none;
}
.z-checkbox-toggle > .z-checkbox-mold {
  margin: 0 4px 4px;
  width: var(--zk-checkbox-toggle-size);
  height: var(--zk-checkbox-toggle-size);
  border-radius: 4px;
  transition: 0.1s;
  display: inline-block;
  vertical-align: middle;
}
.z-checkbox-toggle > .z-checkbox-content {
  display: inline-block;
}
.z-checkbox-toggle-off > .z-checkbox-mold {
  background-color: var(--zk-disabled-color);
  -webkit-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39);
  -moz-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39);
  -o-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39);
  -ms-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39);
  box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39);
}
.z-checkbox-toggle-off > .z-checkbox-mold:focus {
  -webkit-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39), 0 1px 0px 2px var(--zk-focus-border-color);
  -moz-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39), 0 1px 0px 2px var(--zk-focus-border-color);
  -o-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39), 0 1px 0px 2px var(--zk-focus-border-color);
  -ms-box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39), 0 1px 0px 2px var(--zk-focus-border-color);
  box-shadow: 0 4px 1px rgba(0, 0, 0, 0.39), 0 1px 0px 2px var(--zk-focus-border-color);
  transition: unset;
}
.z-checkbox-toggle-on > .z-checkbox-mold {
  background-color: var(--zk-checked-color);
  -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48), 0 0 6px 2px rgba(0, 0, 0, 0.35) inset;
  -moz-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48), 0 0 6px 2px rgba(0, 0, 0, 0.35) inset;
  -o-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48), 0 0 6px 2px rgba(0, 0, 0, 0.35) inset;
  -ms-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48), 0 0 6px 2px rgba(0, 0, 0, 0.35) inset;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.48), 0 0 6px 2px rgba(0, 0, 0, 0.35) inset;
  -webkit-transform: translateY(4px);
  -moz-transform: translateY(4px);
  -o-transform: translateY(4px);
  -ms-transform: translateY(4px);
  transform: translateY(4px);
}
.z-checkbox-toggle-on > .z-checkbox-mold:focus {
  -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48) inset, 0 0 6px 2px rgba(0, 0, 0, 0.35) inset, 0 1px 0px 2px var(--zk-focus-border-color);
  -moz-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48) inset, 0 0 6px 2px rgba(0, 0, 0, 0.35) inset, 0 1px 0px 2px var(--zk-focus-border-color);
  -o-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48) inset, 0 0 6px 2px rgba(0, 0, 0, 0.35) inset, 0 1px 0px 2px var(--zk-focus-border-color);
  -ms-box-shadow: 0 0 5px rgba(0, 0, 0, 0.48) inset, 0 0 6px 2px rgba(0, 0, 0, 0.35) inset, 0 1px 0px 2px var(--zk-focus-border-color);
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.48) inset, 0 0 6px 2px rgba(0, 0, 0, 0.35) inset, 0 1px 0px 2px var(--zk-focus-border-color);
  transition: unset;
}
.z-checkbox-toggle-disabled > .z-checkbox-mold {
  opacity: 0.5;
  cursor: default;
}
