<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-listbox {
  background: var(--zk-mask-background-color);
  border: 1px solid var(--zk-base-border-color);
  overflow: hidden;
  zoom: 1;
}
.z-listbox:focus-visible {
  box-shadow: var(--zk-mesh-focus-box-shadow);
  transition: unset;
}
.z-listbox-header {
  width: 100%;
  position: relative;
  overflow: hidden;
}
.z-listbox-header table {
  border-spacing: 0;
}
.z-listbox-header table th,
.z-listbox-header table td {
  background-clip: padding-box;
  padding: 0;
}
.z-listbox-header table th {
  text-align: inherit;
}
.z-listbox-body {
  position: relative;
  overflow: hidden;
  overflow-anchor: none;
}
.z-listbox-body table {
  border-spacing: 0;
}
.z-listbox-body table th,
.z-listbox-body table td {
  background-clip: padding-box;
  padding: 0;
}
.z-listbox-body table th {
  text-align: inherit;
}
.z-listbox-body .z-listbox-emptybody td {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-disabled-color);
  text-align: left;
  height: 1px;
}
.z-listbox-body .z-listbox-emptybody .z-listbox-emptybody-content {
  background: var(--zk-mesh-background-color);
  padding: var(--zk-mesh-empty-body-padding);
}
.z-listbox-footer {
  overflow: hidden;
  white-space: nowrap;
}
.z-listbox-footer table {
  border-spacing: 0;
}
.z-listbox-footer table th,
.z-listbox-footer table td {
  background-clip: padding-box;
  padding: 0;
}
.z-listbox-footer table th {
  text-align: inherit;
}
.z-listbox-footer .z-listfooter {
  overflow: hidden;
  background: var(--zk-mesh-foot-background-color);
  border-top: 1px solid var(--zk-base-border-color);
}
.z-listbox-footer .z-listfoot-bar {
  background: var(--zk-mesh-foot-background-color);
}
.z-listbox .z-listcell {
  background: var(--zk-mesh-background-color);
}
.z-listbox-odd > .z-listcell {
  background: var(--zk-mesh-stripe-background-color);
}
.z-listbox-loading {
  background: transparent no-repeat center;
  background-image: url(${c:encodeThemeURL("~./zul/img/misc/progress-72.gif")});
}
.z-listhead th:first-child {
  border-left: none;
}
.z-listhead th:first-child.z-listhead-border {
  border-left: 1px solid var(--zk-mesh-title-border-color);
}
.z-listhead-bar {
  background: var(--zk-mesh-title-background-color);
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
}
.z-listheader {
  border-left: 1px solid var(--zk-mesh-title-border-color);
  border-bottom: 1px solid var(--zk-mesh-title-border-color);
  padding: 0;
  background: var(--zk-mesh-title-background-color);
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}
.z-listheader:focus-visible {
  box-shadow: var(--zk-mesh-title-focus-box-shadow);
  transition: unset;
}
.z-listheader-sort .z-listheader-content {
  cursor: pointer;
}
.z-listheader-sort .z-listheader-content:active {
  background: var(--zk-mesh-title-active-background-color);
  color: var(--zk-mesh-title-color);
}
.z-listheader-sort .z-listheader-sorticon {
  font-size: var(--zk-font-size-large);
  color: var(--zk-mesh-title-color);
  position: absolute;
  top: var(--zk-mesh-column-sort-icon-top);
  left: 50%;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  transform: translateX(-50%);
}
.z-listheader-sort .z-listheader-sorticon :active {
  background: rgba(0, 0, 0, 0);
}
.z-listheader-hover {
  background: var(--zk-mesh-title-hover-background-color);
}
.z-listheader-hover .z-listheader-button {
  display: block;
}
.z-listheader-hover .z-listheader-content {
  color: var(--zk-mesh-title-hover-color);
}
.z-listheader-visited {
  background: var(--zk-mesh-title-background-color);
}
.z-listheader-visited .z-listheader-button {
  background: var(--zk-mesh-title-active-background-color);
}
.z-listheader-visited .z-listheader-content {
  color: var(--zk-mesh-title-active-color);
}
.z-listheader-checkable {
  display: inline-block;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-checked-color);
  border: 1px solid var(--zk-checked-border-color);
  background: var(--zk-checked-background-color);
  vertical-align: text-top;
  margin-right: 8px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  position: relative;
  left: var(--zk-listheader-checked-position-left);
}
.z-listheader-checkable:focus-visible {
  box-shadow: var(--zk-mesh-title-focus-box-shadow);
  transition: unset;
}
.z-listheader-checkable .z-listheader-icon {
  display: none;
  cursor: default;
}
.z-listheader-checkable.z-listheader-checked .z-listheader-icon {
  display: block;
}
.z-listheader-button {
  font-size: var(--zk-font-size-large);
  color: var(--zk-mesh-title-color);
  display: none;
  width: var(--zk-mesh-column-sort-button-width);
  height: var(--zk-mesh-column-sort-button-height);
  line-height: var(--zk-mesh-column-sort-button-height);
  text-align: center;
  position: absolute;
  top: 0;
  right: 0;
  text-decoration: none;
  cursor: pointer;
  -webkit-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -moz-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -o-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  -ms-box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  box-shadow: inset 1px 0 var(--zk-mesh-title-border-color);
  z-index: 15;
}
.z-listheader-sizing,
.z-listheader-sizing .z-listheader-button,
.z-listheader-sizing.z-listheader-sort .z-listheader-content {
  cursor: col-resize;
}
.z-listhead-menupopup .z-listheader-content {
  padding-right: 34px;
  text-overflow: ellipsis;
}
.z-listitem .z-listcell {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  overflow: hidden;
  cursor: pointer;
  position: relative;
  z-index: 0;
}
.z-listitem:hover > .z-listcell {
  background: var(--zk-hover-background-color);
}
.z-listitem:hover > .z-listcell > .z-listcell-content {
  color: var(--zk-hover-color);
}
.z-listitem-checkable {
  display: inline-block;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-checked-color);
  border: 1px solid var(--zk-checked-border-color);
  background: var(--zk-checked-background-color);
  vertical-align: text-top;
  margin-right: 8px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  position: relative;
  left: var(--zk-listheader-checked-position-left);
}
.z-listitem-checkable.z-listitem-radio {
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
}
.z-listitem-checkable.z-listitem-radio:hover {
  border-color: var(--zk-checkbox-hover-border-color);
}
.z-listitem-checkable .z-listitem-icon {
  display: none;
  cursor: default;
}
.z-listitem.z-listitem-selected > .z-listcell {
  background: var(--zk-selected-background-color);
}
.z-listitem.z-listitem-selected > .z-listcell > .z-listcell-content {
  color: var(--zk-selected-color);
}
.z-listitem.z-listitem-selected > .z-listcell > .z-listcell-content > .z-listitem-checkable.z-listitem-radio {
  border-color: var(--zk-checkbox-hover-border-color);
}
.z-listitem.z-listitem-selected:hover > .z-listcell {
  background: var(--zk-selected-hover-background-color);
}
.z-listitem.z-listitem-selected:hover .z-listcell-content {
  color: var(--zk-selected-hover-color);
}
.z-listitem.z-listitem-selected.z-listitem-focus > .z-listcell {
  background: var(--zk-selected-focus-background-color);
}
.z-listitem.z-listitem-selected.z-listitem-focus > .z-listcell > .z-listcell-content {
  color: var(--zk-selected-focus-color);
}
.z-listitem.z-listitem-selected.z-listitem-focus:hover > .z-listcell {
  background: var(--zk-selected-hover-background-color);
}
.z-listitem.z-listitem-selected.z-listitem-focus:hover .z-listcell-content {
  color: var(--zk-selected-hover-color);
}
.z-listitem-focus > .z-listcell {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-listitem-focus > .z-listcell:first-child {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 2px 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-listitem-focus > .z-listcell:last-child {
  box-shadow: inset 0 2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 -2px 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset 0 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color), inset -2px 0 0 0 var(--zk-mesh-cell-focus-box-shadow-color);
}
.z-listitem-focus .z-listcell-content {
  color: var(--zk-hover-color);
}
.z-listitem-selected > .z-listcell > .z-listcell-content > .z-listitem-checkable .z-listitem-icon {
  display: block;
  cursor: pointer;
}
.z-listitem-selected > .z-listcell > .z-listcell-content > .z-listitem-checkable .z-listitem-icon.z-icon-radio {
  width: var(--zk-listbox-radio-icon-size);
  height: var(--zk-listbox-radio-icon-size);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  -o-border-radius: 50%;
  -ms-border-radius: 50%;
  border-radius: 50%;
  background: var(--zk-checked-color);
  position: relative;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.z-listitem.z-listitem-disabled * {
  color: var(--zk-disabled-color) !important;
  cursor: default !important;
}
.z-listitem.z-listitem-disabled a,
.z-listitem.z-listitem-disabled a:visited,
.z-listitem.z-listitem-disabled a:hover {
  text-decoration: none;
}
.z-listitem a,
.z-listitem a:visited,
.z-listitem a:hover {
  text-decoration: none;
}
.z-listgroup-inner {
  border-top: 1px solid var(--zk-mesh-content-border-color);
  border-bottom: 1px solid var(--zk-mesh-group-border-color);
  background: var(--zk-mesh-group-background-color);
  position: relative;
  overflow: hidden;
}
.z-listgroup-inner .z-listcell-content,
.z-listgroup-inner .z-listgroup-content {
  padding: var(--zk-mesh-body-padding);
}
.z-listgroup.z-listgroup-open .z-listgroup-inner {
  background: var(--zk-mesh-group-open-background-color);
  border-bottom: var(--zk-mesh-group-open-border);
}
.z-listgroup.z-listgroup-open .z-listgroup-inner .z-listgroup-icon,
.z-listgroup.z-listgroup-open .z-listgroup-inner .z-listcell-content {
  color: var(--zk-mesh-group-open-color);
}
.z-listgroup-checkable {
  display: inline-block;
  width: var(--zk-checkbox-size);
  height: var(--zk-checkbox-size);
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-checked-color);
  border: 1px solid var(--zk-checked-border-color);
  background: var(--zk-checked-background-color);
  vertical-align: text-top;
  margin-right: 8px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  position: relative;
  left: var(--zk-listheader-checked-position-left);
}
.z-listgroup-checkable .z-listgroup-icon {
  display: none;
  cursor: default;
}
.z-listgroup-selected .z-listgroup-checkable .z-listgroup-icon {
  display: block;
  cursor: pointer;
}
.z-listgroup-selected .z-listgroup-checkable .z-listgroup-icon:hover {
  color: var(--zk-checked-color);
}
.z-listgroup-icon {
  font-size: var(--zk-checked-icon-size);
  color: var(--zk-mesh-group-color);
  display: inline-block;
  width: var(--zk-base-icon-width);
  height: var(--zk-base-icon-height);
  line-height: var(--zk-checked-icon-size);
  text-align: center;
  vertical-align: text-top;
  position: relative;
  cursor: pointer;
  margin-right: 8px;
}
.z-listheader-content,
.z-listcell-content,
.z-listgroup-content,
.z-listgroupfoot-content,
.z-listfooter-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-base-text-color);
  line-height: var(--zk-mesh-content-line-height);
  overflow: hidden;
  padding: var(--zk-mesh-body-padding);
}
.z-listheader-content {
  color: var(--zk-mesh-title-color);
  position: relative;
}
.z-listheader-content .z-listheader-sorticon {
  background: rgba(0, 0, 0, 0);
}
.z-listfooter-content {
  color: var(--zk-text-color-light);
}
.z-listgroup .z-listcell-content {
  color: var(--zk-mesh-group-color);
}
.z-listgroupfoot-inner {
  border-top: 1px solid var(--zk-mesh-content-border-color);
}
.z-listgroupfoot .z-listcell-content {
  color: var(--zk-mesh-group-footer-color);
  padding: var(--zk-mesh-body-padding);
}
.z-listgroup-open.z-listgroupfoot .z-listcell-content {
  color: var(--zk-mesh-group-footer-open-color);
}
.z-listbox-paging-top {
  border-bottom: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
  width: 100%;
}
.z-listbox-paging-bottom {
  border-top: 1px solid var(--zk-paging-border-color);
  overflow: hidden;
  width: 100%;
}
.z-listbox-autopaging .z-listcell-content {
  height: var(--zk-mesh-auto-paging-row-height);
  padding: var(--zk-mesh-auto-paging-row-padding);
  line-height: var(--zk-mesh-auto-paging-row-line-height);
  overflow: hidden;
}
.z-listhead-menugrouping .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-group.png")});
}
.z-listhead-menuungrouping .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-ungroup.png")});
}
.z-listhead-menuascending .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-arrowup.png")});
}
.z-listhead-menudescending .z-menuitem-image {
  background-image: url(${c:encodeThemeURL("~./zul/img/grid/menu-arrowdown.png")});
}
.z-select {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
}
.z-listcell-hidden-header {
  white-space: nowrap;
  overflow: hidden;
}
