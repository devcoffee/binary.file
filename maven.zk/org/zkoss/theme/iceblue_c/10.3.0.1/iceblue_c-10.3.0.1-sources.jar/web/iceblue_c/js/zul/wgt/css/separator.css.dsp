<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-separator {
  opacity: 0.69;
  text-align: center;
  position: relative;
}
.z-separator-horizontal,
.z-separator-horizontal-bar {
  font-size: 0;
  height: 7px;
  line-height: 0;
  overflow: hidden;
}
.z-separator-horizontal-bar:after {
  content: "";
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  border-top: 1px solid var(--zk-color-grey-dark);
  -webkit-transform: translate(0, -50%);
  -moz-transform: translate(0, -50%);
  -o-transform: translate(0, -50%);
  -ms-transform: translate(0, -50%);
  transform: translate(0, -50%);
}
.z-separator-vertical,
.z-separator-vertical-bar {
  display: inline-block;
  width: 10px;
  overflow: hidden;
}
.z-separator-vertical-bar:after {
  content: "";
  position: absolute;
  left: 50%;
  top: 0;
  bottom: 0;
  border-left: 1px solid var(--zk-color-grey-dark);
  -webkit-transform: translate(-50%);
  -moz-transform: translate(-50%);
  -o-transform: translate(-50%);
  -ms-transform: translate(-50%);
  transform: translate(-50%);
}
