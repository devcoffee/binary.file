<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-drawer {
  position: fixed;
  top: 0;
  z-index: 1000;
  width: 0;
  height: 0;
}
.z-drawer-open {
  width: 100%;
  height: 100%;
}
.z-drawer-mask {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: var(--zk-drawer-mask-background-color);
  opacity: 0;
}
.z-drawer-mask-enabled {
  opacity: var(--zk-drawer-mask-opacity);
}
.z-drawer-real {
  position: fixed;
  background-color: var(--zk-drawer-background-color);
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: column;
  flex-direction: column;
  will-change: transform;
  transition: transform 200ms ease-out;
}
.z-drawer-container {
  -ms-flex: 1;
  flex: 1;
  overflow: auto;
}
.z-drawer-header {
  padding: var(--zk-drawer-title-padding);
  border-bottom: 1px solid var(--zk-drawer-title-line-color);
}
.z-drawer-title {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-drawer-title-font-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-drawer-title-text-color);
}
.z-drawer-close {
  font-size: var(--zk-drawer-close-button-size);
  color: var(--zk-icon-color);
  width: var(--zk-drawer-close-button-size);
  height: var(--zk-drawer-close-button-size);
  position: absolute;
  right: var(--zk-drawer-close-button-right);
  top: var(--zk-drawer-close-button-top);
  text-align: center;
  cursor: pointer;
}
.z-drawer-close:hover {
  color: var(--zk-icon-hover-color);
}
.z-drawer-cave {
  padding: var(--zk-drawer-container-padding);
  height: 100%;
}
.z-drawer-open.z-drawer-left .z-drawer-real {
  box-shadow: 4px 0 8px var(--zk-drawer-shadow-color);
  transform: translateX(0%);
}
.z-drawer-open.z-drawer-right .z-drawer-real {
  box-shadow: -4px 0 8px var(--zk-drawer-shadow-color);
  transform: translateX(0%);
}
.z-drawer-open.z-drawer-top .z-drawer-real {
  box-shadow: 0 4px 8px var(--zk-drawer-shadow-color);
  transform: translateY(0%);
}
.z-drawer-open.z-drawer-bottom .z-drawer-real {
  box-shadow: 0 -4px 8px var(--zk-drawer-shadow-color);
  transform: translateY(0%);
}
.z-drawer-left .z-drawer-real {
  left: 0;
  width: 280px;
  height: 100%;
  transform: translateX(-100%);
}
.z-drawer-right .z-drawer-real {
  right: 0;
  width: 280px;
  height: 100%;
  transform: translateX(100%);
}
.z-drawer-top .z-drawer-real {
  top: 0;
  bottom: auto;
  left: 0;
  width: 100%;
  height: 280px;
  transform: translateY(-100%);
}
.z-drawer-bottom .z-drawer-real {
  top: auto;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 280px;
  transform: translateY(100%);
}
