<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-window {
  overflow: hidden;
  zoom: 1;
  border: 1px solid var(--zk-container-border-color);
  -webkit-border-radius: var(--zk-container-border-radius);
  -moz-border-radius: var(--zk-container-border-radius);
  -o-border-radius: var(--zk-container-border-radius);
  -ms-border-radius: var(--zk-container-border-radius);
  border-radius: var(--zk-container-border-radius);
  padding: var(--zk-container-padding);
  background-color: var(--zk-container-background);
}
.z-window-shadow {
  -webkit-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -moz-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -o-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -ms-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
}
.z-window-header {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-container-header-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-container-header-color);
  line-height: var(--zk-base-button-width);
  padding: var(--zk-window-header-padding);
  overflow: hidden;
  zoom: 1;
  cursor: default;
}
.z-window-header-move {
  cursor: move;
}
.z-window-content {
  padding: var(--zk-container-padding);
  background: var(--zk-base-background-color);
  color: var(--zk-container-body-color);
  overflow: hidden;
  zoom: 1;
}
.z-window-icons {
  display: inline-block;
  float: right;
}
.z-window-icon {
  font-size: var(--zk-container-button-size);
  color: var(--zk-container-button-color);
  display: inline-block;
  width: calc(var(--zk-base-button-width) + 4px);
  height: var(--zk-base-button-height);
  margin: auto 1px;
  padding: var(--zk-container-button-padding);
  line-height: var(--zk-base-button-height);
  text-align: center;
  overflow: hidden;
  cursor: pointer;
  border: none;
  background: transparent;
}
.z-window-icon:hover {
  color: var(--zk-container-button-hover-color);
}
.z-window-resize-faker {
  border: 1px dashed #1854C2;
  background: #D7E6F7;
  opacity: 0.5;
  position: absolute;
  left: 0;
  top: 0;
  overflow: hidden;
  z-index: 60000;
}
.z-window-move-ghost {
  border: 1px solid var(--zk-container-border-color);
  -webkit-border-radius: var(--zk-container-border-radius);
  -moz-border-radius: var(--zk-container-border-radius);
  -o-border-radius: var(--zk-container-border-radius);
  -ms-border-radius: var(--zk-container-border-radius);
  border-radius: var(--zk-container-border-radius);
  padding: 0;
  background: var(--zk-color-primary-lighter);
  opacity: 0.65;
  position: absolute;
  overflow: hidden;
  cursor: move !important;
}
.z-window-move-ghost .z-window-header-move {
  padding: var(--zk-window-ghost-header-padding);
}
.z-window-move-ghost dl {
  font-size: 0;
  display: block;
  border-top: 1px solid var(--zk-container-border-color);
  margin: 0;
  padding: 0;
  line-height: 0;
  overflow: hidden;
}
.z-window-embedded .z-window-shadow {
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  -o-box-shadow: none;
  -ms-box-shadow: none;
  box-shadow: none;
}
.z-window-noborder {
  border: 0;
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  -o-border-radius: 0;
  -ms-border-radius: 0;
  border-radius: 0;
}
.z-window-noborder.z-window-noheader {
  padding: 0;
}
.z-window-noborder.z-window-noheader > .z-window-content {
  padding: 0;
}
.z-window-noborder > .z-window-content {
  border: 0;
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  -o-border-radius: 0;
  -ms-border-radius: 0;
  border-radius: 0;
}
.z-messagebox {
  display: inline-block;
  white-space: normal;
  width: calc(var(--zk-messagebox-window-width) - var(--zk-messagebox-icon-margin-left) - var(--zk-messagebox-icon-size) - var(--zk-messagebox-padding-horizontal));
}
.z-messagebox-window {
  padding: var(--zk-messagebox-window-padding);
  width: var(--zk-messagebox-window-width);
}
.z-messagebox-window .z-window-header {
  padding: var(--zk-messagebox-header-padding);
}
.z-messagebox-window .z-window-content {
  padding: var(--zk-messagebox-window-content-padding);
}
.z-messagebox-buttons {
  text-align: right;
  margin-right: 16px;
  left: 0;
  position: sticky;
}
.z-messagebox-buttons > * {
  margin-left: var(--zk-messagebox-buttons-margin-left);
}
.z-messagebox-button {
  width: 100%;
  min-width: 48px;
}
.z-messagebox-icon {
  font-size: 30px;
  display: inline-block;
  width: var(--zk-messagebox-icon-size);
  height: var(--zk-messagebox-icon-size);
  border: 0;
  background-repeat: no-repeat;
  text-align: center;
  vertical-align: top;
  cursor: pointer;
  margin-left: var(--zk-messagebox-icon-margin-left);
}
.z-messagebox-question {
  background-image: url(${c:encodeThemeURL("~./zul/img/msgbox/question-btn.png")});
}
.z-messagebox-viewport {
  overflow: auto;
  white-space: nowrap;
  margin-bottom: var(--zk-messagebox-viewport-margin-bottom);
}
.z-messagebox-exclamation {
  background-image: url(${c:encodeThemeURL("~./zul/img/msgbox/warning-btn.png")});
}
.z-messagebox-information {
  background-image: url(${c:encodeThemeURL("~./zul/img/msgbox/info-btn.png")});
}
.z-messagebox-error {
  background-image: url(${c:encodeThemeURL("~./zul/img/msgbox/stop-btn.png")});
}
.z-messagebox .z-label {
  display: inline-block;
  padding: var(--zk-messagebox-padding);
}
