<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-hbox,
.z-vbox {
  border-spacing: 0;
}
.z-hbox th,
.z-vbox th,
.z-hbox td,
.z-vbox td {
  padding: 0;
  background-clip: padding-box;
}
.z-hbox th,
.z-vbox th {
  text-align: inherit;
}
.z-hbox-separator,
.z-vbox-separator {
  margin: 0;
  padding: 0;
}
.z-hbox-separator {
  width: 0.3em;
}
.z-vbox-separator {
  height: 0.3em;
}
.z-vbox-separator td {
  line-height: 0;
}
tr.z-splitter-outer > td {
  height: var(--zk-splitter-size);
  max-height: var(--zk-splitter-size);
}
td.z-splitter-outer {
  width: var(--zk-splitter-size);
  max-width: var(--zk-splitter-size);
  padding: 0;
}
.z-splitter {
  border: 1px solid var(--zk-splitter-border-color);
  background-color: var(--zk-splitter-background-color);
}
.z-splitter-button {
  color: var(--zk-splitter-button-text-color);
  display: inline-block;
  position: relative;
  vertical-align: top;
  cursor: pointer;
}
.z-splitter-button-disabled {
  border: 0;
}
.z-splitter-vertical .z-splitter-button-disabled {
  cursor: row-resize;
}
.z-splitter-horizontal .z-splitter-button-disabled {
  cursor: col-resize;
}
.z-splitter-horizontal {
  width: var(--zk-splitter-size);
  border-width: 0 1px;
  overflow: hidden;
  cursor: col-resize;
}
.z-splitter-horizontal > .z-splitter-button {
  width: var(--zk-splitter-size);
  height: 30px;
  border-width: 1px 0;
}
.z-splitter-horizontal .z-splitter-icon {
  font-size: var(--zk-splitter-button-text-size);
  position: absolute;
  top: 8px;
  left: -3px;
}
.z-splitter-horizontal .z-splitter-icon.z-icon-ellipsis-v {
  top: -21px;
  left: 2px;
  cursor: col-resize;
  visibility: hidden;
}
.z-splitter-horizontal .z-splitter-icon.z-icon-ellipsis-v ~ .z-splitter-icon.z-icon-ellipsis-v {
  top: 39px;
}
.z-splitter-vertical {
  height: var(--zk-splitter-size);
  border-width: 1px 0;
  overflow: hidden;
  cursor: row-resize;
}
.z-splitter-vertical > .z-splitter-button {
  width: 30px;
  height: var(--zk-splitter-size);
  border-width: 0 1px;
}
.z-splitter-vertical .z-splitter-icon {
  font-size: var(--zk-splitter-button-text-size);
  line-height: normal;
  position: absolute;
  top: -4px;
  left: 9px;
}
.z-splitter-vertical .z-splitter-icon.z-icon-ellipsis-h {
  top: -2px;
  left: -16px;
  cursor: row-resize;
  visibility: hidden;
}
.z-splitter-vertical .z-splitter-icon.z-icon-ellipsis-h ~ .z-splitter-icon.z-icon-ellipsis-h {
  left: 36px;
}
.z-splitter:hover {
  background-color: var(--zk-splitter-hover-background-color);
}
.z-splitter:hover .z-splitter-button {
  color: var(--zk-splitter-button-text-hover-color);
}
.z-splitter-nosplitter {
  cursor: default;
}
.z-splitter-ghost {
  background: var(--zk-splitter-drag-background-color) !important;
}
