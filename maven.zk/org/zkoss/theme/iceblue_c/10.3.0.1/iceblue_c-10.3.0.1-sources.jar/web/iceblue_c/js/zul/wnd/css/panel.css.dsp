<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-panel {
  overflow: hidden;
  zoom: 1;
  padding: 0;
  border: 1px solid var(--zk-container-border-color);
  background: var(--zk-container-background);
  -webkit-border-radius: var(--zk-container-border-radius);
  -moz-border-radius: var(--zk-container-border-radius);
  -o-border-radius: var(--zk-container-border-radius);
  -ms-border-radius: var(--zk-container-border-radius);
  border-radius: var(--zk-container-border-radius);
}
.z-panel-shadow {
  -webkit-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -moz-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -o-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  -ms-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.24);
}
.z-panel-collapsed {
  height: auto !important;
}
.z-panel-head {
  overflow: hidden;
}
.z-panel-header {
  font-family: var(--zk-base-title-font-family);
  font-size: var(--zk-container-header-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-container-header-color);
  border: 0;
  padding: var(--zk-panel-header-padding);
  line-height: 24px;
  overflow: hidden;
  zoom: 1;
}
.z-panel-header-move {
  cursor: move;
}
.z-panel-body {
  margin: 0;
  padding: 0;
  background: var(--zk-base-background-color);
  color: var(--zk-container-body-color);
  overflow: hidden;
  zoom: 1;
}
.z-panel-drag-button {
  display: none;
}
.z-panel-drag-button + .z-panel-body {
  height: 100%;
}
.z-panel-icons {
  display: inline-block;
  float: right;
}
.z-panel-icon {
  background: transparent;
  color: var(--zk-container-button-color);
  margin: auto 1px;
  padding: var(--zk-container-button-padding);
  text-align: center;
  overflow: hidden;
  cursor: pointer;
  font-size: var(--zk-container-button-size);
  display: inline-block;
  width: calc(var(--zk-base-button-width) + 4px);
  height: var(--zk-base-button-height);
  line-height: var(--zk-base-button-height);
  border: none;
}
.z-panel-icon:hover {
  color: var(--zk-container-button-hover-color);
}
.z-panel-close {
  font-size: var(--zk-font-size-x-large);
}
.z-panel-resize-faker {
  border: 1px dashed #1854C2;
  background: #D7E6F7;
  opacity: 0.5;
  position: absolute;
  left: 0;
  top: 0;
  overflow: hidden;
  z-index: 60000;
}
.z-panel-move-ghost {
  -webkit-border-radius: var(--zk-container-border-radius);
  -moz-border-radius: var(--zk-container-border-radius);
  -o-border-radius: var(--zk-container-border-radius);
  -ms-border-radius: var(--zk-container-border-radius);
  border-radius: var(--zk-container-border-radius);
  margin: 0;
  padding: 0;
  background: #D7E6F7;
  opacity: 0.6;
  position: absolute;
  overflow: hidden;
  cursor: move;
}
.z-panel-move-ghost .z-panel-body {
  padding: 0;
}
.z-panel-move-ghost dl {
  font-size: 0;
  display: block;
  border: 1px solid var(--zk-container-border-color);
  border-top: 0;
  margin: 0;
  padding: 0;
  line-height: 0;
  overflow: hidden;
}
.z-panel-noborder {
  border: 0;
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  -o-border-radius: 0;
  -ms-border-radius: 0;
  border-radius: 0;
}
.z-panel-move-block {
  border: 2px dashed #B2CAD6;
}
.z-panelchildren {
  position: relative;
  padding: var(--zk-container-padding);
  overflow: hidden;
  zoom: 1;
}
