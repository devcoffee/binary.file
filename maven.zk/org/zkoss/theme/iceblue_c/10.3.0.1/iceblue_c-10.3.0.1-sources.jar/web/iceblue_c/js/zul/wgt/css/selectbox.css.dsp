<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-selectbox {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-input-text-size);
  line-height: normal;
  color: var(--zk-input-color);
  height: var(--zk-input-height);
  min-width: 180px;
  background-color: var(--zk-input-background-color);
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg%20fill%3D%27var%28--zk-icon-color%29%27%20height%3D%2724%27%20viewBox%3D%270%200%2024%2024%27%20width%3D%2724%27%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%3E%3Cpath%20d%3D%27M7%2010l5%205%205-5z%27%2F%3E%3C%2Fsvg%3E");
  background-repeat: no-repeat;
  background-position: top 50% right 0;
  border: 1px solid var(--zk-input-border-color);
  border-radius: var(--zk-input-border-radius);
  padding: var(--zk-input-padding);
  padding-right: 24px;
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
}
.z-selectbox::-ms-expand {
  display: none;
}
.z-selectbox:hover {
  border-color: var(--zk-color-grey-dark);
}
.z-selectbox:focus {
  border-color: var(--zk-input-focus-border-color);
}
.z-selectbox:active {
  color: var(--zk-active-color);
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg%20fill%3D%27var%28--zk-active-color%29%27%20height%3D%2724%27%20viewBox%3D%270%200%2024%2024%27%20width%3D%2724%27%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%3E%3Cpath%20d%3D%27M7%2010l5%205%205-5z%27%2F%3E%3C%2Fsvg%3E");
  background-color: var(--zk-color-primary);
  border-color: var(--zk-color-primary-dark);
}
.z-selectbox[disabled] {
  color: var(--zk-input-disable-color);
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg%20fill%3D%27var%28--zk-input-disable-color%29%27%20height%3D%2724%27%20viewBox%3D%270%200%2024%2024%27%20width%3D%2724%27%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%3E%3Cpath%20d%3D%27M7%2010l5%205%205-5z%27%2F%3E%3C%2Fsvg%3E");
  background-color: var(--zk-input-disable-background-color);
  cursor: default;
  border-color: var(--zk-input-border-color);
}
