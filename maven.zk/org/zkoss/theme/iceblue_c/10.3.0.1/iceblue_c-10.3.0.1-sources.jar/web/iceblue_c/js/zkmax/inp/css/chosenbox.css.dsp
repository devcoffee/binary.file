<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-chosenbox {
  display: inline-block;
  border: 1px solid var(--zk-input-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  line-height: normal;
  background: var(--zk-input-background-color);
  overflow: hidden;
  padding: var(--zk-chosenbox-padding);
  min-height: var(--zk-chosenbox-min-height);
  vertical-align: bottom;
}
.z-chosenbox-focus {
  border-color: var(--zk-input-focus-border-color);
}
.z-chosenbox-item {
  display: inline-block;
  border: 1px solid var(--zk-chosenbox-item-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  margin: var(--zk-chosenbox-item-margin);
  padding: var(--zk-chosenbox-item-padding);
  background-color: var(--zk-chosenbox-item-background-color);
  vertical-align: middle;
  position: relative;
  white-space: nowrap;
  cursor: pointer;
}
.z-chosenbox-item-content {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-chosenbox-item-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-chosenbox-item-color);
  display: inline-block;
  padding: var(--zk-chosenbox-item-content-padding);
  margin-right: var(--zk-chosenbox-item-content-margin-right);
  float: left;
}
.z-chosenbox-item-focus {
  background-color: var(--zk-chosenbox-item-focus-background-color);
}
.z-chosenbox-button {
  font-size: var(--zk-chosenbox-icon-size);
  color: var(--zk-chosenbox-item-color);
  width: var(--zk-chosenbox-icon-size);
  height: var(--zk-chosenbox-icon-size);
  line-height: var(--zk-chosenbox-icon-size);
  text-align: center;
  position: absolute;
  right: var(--zk-chosenbox-button-position-right);
  top: var(--zk-chosenbox-button-position-top);
}
.z-chosenbox-input {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-input-text-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-input-color);
  display: inline-block;
  width: var(--zk-chosenbox-input-width);
  height: var(--zk-chosenbox-input-height);
  border: 0 !important;
  padding: 1px 4px 2px 8px;
  background: transparent !important;
  outline: 0;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  -o-box-shadow: none;
  -ms-box-shadow: none;
  box-shadow: none;
}
.z-chosenbox-disabled {
  border-color: var(--zk-chosenbox-item-disabled-border-color);
  background: var(--zk-disabled-background-color);
}
.z-chosenbox-disabled .z-chosenbox-item {
  cursor: default;
  border-color: var(--zk-chosenbox-item-disabled-border-color);
  background-color: var(--zk-chosenbox-item-disabled-background-color);
}
.z-chosenbox-disabled .z-chosenbox-item-content {
  color: var(--zk-chosenbox-item-disabled-color);
  margin-right: 0;
}
.z-chosenbox-disabled .z-chosenbox-button {
  display: none;
}
.z-chosenbox-textcontent {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  display: none;
  white-space: nowrap;
}
.z-chosenbox-popup {
  font-family: var(--zk-base-content-font-family);
  font-size: var(--zk-font-size-medium);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-combo-popup-item-color);
  display: block;
  border: 1px solid var(--zk-combo-popup-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-chosenbox-popup-padding);
  background: var(--zk-popup-background-color);
  position: absolute;
  overflow: auto;
}
.z-chosenbox-popup-hidden {
  display: none;
}
.z-chosenbox-shadow {
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
}
.z-chosenbox-option {
  cursor: pointer;
  padding: var(--zk-chosenbox-option-padding);
  min-height: var(--zk-chosenbox-option-min-height);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-chosenbox-option:hover,
.z-chosenbox-option-hover {
  background: var(--zk-chosenbox-popup-hover-background-color);
}
.z-chosenbox-empty {
  color: var(--zk-disabled-color);
  padding: var(--zk-chosenbox-option-padding);
  min-height: var(--zk-chosenbox-option-min-height);
}
.z-chosenbox-empty-creatable {
  color: var(--zk-input-color);
  padding-top: 2px;
  cursor: pointer;
}
.z-chosenbox-select {
  display: inline-block;
  min-width: 100%;
}
.z-chosenbox-create {
  font-size: var(--zk-chosenbox-create-icon-size);
  color: var(--zk-chosenbox-create-icon-color);
  width: var(--zk-chosenbox-create-icon-size);
  height: var(--zk-chosenbox-create-icon-size);
  margin-right: 2px;
}
.z-chosenbox-create:before {
  content: '\f067';
}
.z-chosenbox-inplace {
  width: 100%;
  height: 100%;
  font-style: normal;
  display: inline-block;
  font-size: 18px;
  padding: 4px;
}
.z-chosenbox-hide {
  display: none;
}
