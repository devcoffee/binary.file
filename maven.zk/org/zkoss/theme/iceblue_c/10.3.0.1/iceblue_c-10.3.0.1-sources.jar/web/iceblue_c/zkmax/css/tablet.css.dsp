<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>*,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>*:before,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>*:after {
  -webkit-user-drag: none;
  -webkit-user-select: none;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>*:focus {
  outline: none;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type=number]::-webkit-inner-spin-button,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>input:focus,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea,
<c:if test="${not empty c:property('org.zkoss.zul.theme.browserDefault')}">${".z-page "}</c:if>textarea:focus {
  -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
  -webkit-appearance: none;
  -moz-appearance: none;
  -webkit-user-modify: read-write-plaintext-only;
  outline: none;
  -webkit-user-select: text;
}
.z-radio,
.z-checkbox {
  display: inline-block;
  line-height: 28px;
}
.z-radio-content,
.z-checkbox-content {
  cursor: pointer;
}
.z-radiogroup-vertical .z-radio {
  display: block;
}
.z-html {
  display: inline-block;
}
.z-error {
  width: auto;
  max-width: 90%;
  padding: 12px 8px 16px 16px;
  left: 0;
  right: 0;
  margin: 0 auto;
}
.z-error .errornumbers {
  font-size: 17px;
}
.z-error .messagecontent {
  padding-top: 16px;
  padding-right: 8px;
  font-size: 15px;
}
.z-error .button {
  width: 22px;
  height: 22px;
  font-size: 22px;
  margin-left: 12px;
}
.z-error .button > .z-icon-times {
  font-size: 22px;
}
.z-biglistbox-outer {
  margin: 0 22px 22px 0;
}
.z-biglistbox-verticalbar-tick {
  width: 14px;
  height: 100%;
  border: 0;
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  -o-border-radius: 0;
  -ms-border-radius: 0;
  border-radius: 0;
  background: transparent;
}
.z-biglistbox-verticalbar-tick:hover,
.z-biglistbox-verticalbar-tick:active {
  background: 0;
  border: 0;
}
.z-biglistbox-verticalbar-tick:before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  display: block;
  width: 14px;
  height: 22px;
  background: #fff;
  border: 1px solid var(--zk-base-border-color);
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  -o-border-radius: 2px;
  -ms-border-radius: 2px;
  border-radius: 2px;
}
.z-biglistbox-verticalbar-tick:hover:before {
  background-color: var(--zk-biglistbox-scrollbar-hover-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-hover-border-color);
}
.z-biglistbox-verticalbar-tick:active:before {
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-verticalbar-tick:after {
  content: '\e910';
  position: absolute;
  bottom: 1px;
  display: block;
  left: -3px;
  font-size: 20px;
}
.z-biglistbox-wscroll-vertical {
  width: 22px;
  right: -22px;
  -webkit-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -moz-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -o-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -ms-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag {
  width: 22px;
  height: 168px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  font-size: 20px;
  line-height: 22px;
  text-align: center;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  width: 100%;
  height: 28px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  width: 100%;
  height: 56px;
  top: 56px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:before {
  left: 0;
  top: 20px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up {
  top: 28px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down {
  bottom: 28px;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-pos {
  width: 22px;
  height: 168px;
  -webkit-border-radius: 2em;
  -moz-border-radius: 2em;
  -o-border-radius: 2em;
  -ms-border-radius: 2em;
  border-radius: 2em;
}
.z-biglistbox-wscroll-vertical .z-biglistbox-wscroll-endbar {
  width: 22px;
  height: 8px;
}
.z-biglistbox-wscroll-horizontal {
  height: 22px;
  bottom: -22px;
  -webkit-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -moz-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -o-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  -ms-box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
  box-shadow: inset 1px 1px 7px rgba(210, 210, 210, 0.75), inset -1px -1px 7px rgba(210, 210, 210, 0.75);
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag {
  width: 168px;
  height: 22px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  font-size: 20px;
  line-height: 22px;
  text-align: center;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-home,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down,
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-end {
  width: 28px;
  height: 100%;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body {
  width: 56px;
  height: 100%;
  left: 56px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-body:before {
  left: 20px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-up {
  left: 28px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-drag .z-biglistbox-wscroll-down {
  right: 28px;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-pos {
  width: 168px;
  height: 22px;
  -webkit-border-radius: 2em;
  -moz-border-radius: 2em;
  -o-border-radius: 2em;
  -ms-border-radius: 2em;
  border-radius: 2em;
}
.z-biglistbox-wscroll-horizontal .z-biglistbox-wscroll-endbar {
  width: 8px;
  height: 22px;
  background: var(--zk-biglistbox-scrollbar-end-bar-background-color);
}
.z-biglistbox-wscroll-home-clk .z-biglistbox-wscroll-home {
  color: #FFF;
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-up-clk .z-biglistbox-wscroll-up {
  color: #FFF;
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-down-clk .z-biglistbox-wscroll-down {
  color: #FFF;
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-end-clk .z-biglistbox-wscroll-end {
  color: #FFF;
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-biglistbox-wscroll-body-clk .z-biglistbox-wscroll-body {
  color: #FFF;
  background-color: var(--zk-biglistbox-scrollbar-active-background-color);
  border: 1px solid var(--zk-biglistbox-scrollbar-active-border-color);
}
.z-north-header,
.z-south-header,
.z-west-header,
.z-center-header,
.z-east-header {
  font-size: 14px;
  line-height: 20px;
  height: 32px;
}
.z-borderlayout-icon {
  font-size: 22px;
}
.z-button {
  line-height: 14px;
}
.z-button img {
  width: auto;
  height: auto;
}
.z-calendar {
  min-width: 420px;
  padding: 2px;
}
.z-calendar-icon {
  font-size: 20px;
}
.z-calendar th {
  font-size: 14px;
}
.z-calendar-cell {
  font-size: 14px;
}
.z-calendar-cell:hover {
  color: initial;
  background: initial;
}
.z-calendar-selected:hover {
  color: var(--zk-calendar-selected-hover-color);
  background: var(--zk-calendar-selected-hover-background-color);
}
.z-calendar-decade .z-calendar-cell,
.z-calendar-month .z-calendar-cell,
.z-calendar-year .z-calendar-cell {
  width: 63px;
  height: 48px;
}
.z-calendar-wk.z-calendar .z-calendar-decade .z-calendar-cell,
.z-calendar-wk.z-calendar .z-calendar-month .z-calendar-cell,
.z-calendar-wk.z-calendar .z-calendar-year .z-calendar-cell {
  width: 72px;
  height: 48px;
}
.z-calendar-today {
  margin: 8px 10px 0;
}
.z-calendar-today .z-calendar-title {
  font-size: 15px;
}
.z-datebox-popup .z-calendar {
  border: 0px;
  min-width: 100px;
}
.z-calendar-wheel-date {
  display: -webkit-box;
  display: -moz-box;
  display: box;
  -webkit-box-orient: horizontal;
  -moz-box-orient: horizontal;
  -o-box-orient: horizontal;
  -ms-box-orient: horizontal;
  box-orient: horizontal;
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -o-box-flex: 1;
  -ms-box-flex: 1;
  box-flex: 1;
  width: 100%;
  position: relative;
  background: var(--zk-base-background-color);
  margin-right: 2px;
}
.z-calendar-wheel-cave {
  position: relative;
}
.z-calendar-wheel-body {
  display: -webkit-box;
  display: -moz-box;
  display: box;
  -webkit-box-orient: horizontal;
  -moz-box-orient: horizontal;
  -o-box-orient: horizontal;
  -ms-box-orient: horizontal;
  box-orient: horizontal;
  width: 100%;
}
.z-calendar-wheel-line {
  width: 100%;
  height: 0;
  position: absolute;
  top: 50%;
  z-index: 1;
}
.z-calendar-wheel-list {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -o-box-flex: 1;
  -ms-box-flex: 1;
  box-flex: 1;
  color: var(--zk-text-color-default);
  background: var(--zk-base-background-color);
  height: 120px;
  margin: 0 1px 0 0;
  position: relative;
  overflow: hidden;
}
.z-calendar-wheel-list ul {
  width: 100%;
  margin: 0;
  padding: 0;
  position: relative;
  list-style: none;
  z-index: 2;
}
.z-calendar-wheel-list li {
  font-size: 17px;
  display: block;
  height: 40px;
  margin: 0;
  padding: 0;
  line-height: 40px;
  opacity: 0.3;
  text-align: center;
  white-space: nowrap;
  list-style: none;
}
.z-calendar-wheel-footer {
  height: 50px;
  padding: 5px 0;
  clear: both;
}
.z-calendar-wheel-button {
  font-family: var(--zk-base-content-font-family);
  font-size: 15px;
  font-weight: normal;
  font-style: normal;
  color: #000000;
  width: 45%;
  border: none;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: 8px 0;
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
}
.z-calendar-wheel-left {
  float: left;
  background: var(--zk-color-primary);
  color: var(--zk-text-color-default3);
  border: 1px solid transparent;
}
.z-calendar-wheel-right {
  float: right;
  background: var(--zk-base-background-color);
  color: var(--zk-text-color-default);
  border: 1px solid var(--zk-color-grey-light);
}
li.z-calendar-wheel-list-selected {
  opacity: 1;
}
.z-chosenbox {
  min-height: 32px;
}
.z-chosenbox-item {
  margin: 1px;
}
.z-chosenbox-item-content {
  font-size: 12px;
  padding: 3px 20px 3px 4px;
  line-height: 18px;
  margin-right: 0;
}
.z-chosenbox-button {
  font-size: 14px;
  line-height: normal;
  text-align: center;
  top: 3px;
}
.z-chosenbox-option,
.z-chosenbox-empty {
  padding: 8px;
  font-size: 15px;
}
.z-chosenbox-disabled .z-chosenbox-item-content {
  padding-right: 3px;
}
.z-colorbox {
  height: 34px;
}
.z-menu-popup .z-colorpalette {
  padding: 4px;
}
.z-colorpalette {
  width: 586px;
  height: 460px;
  padding: 0;
}
.z-colorpalette-newcolor {
  width: 50px;
  height: 34px;
  right: 116px;
}
.z-colorpalette-input {
  width: 96px;
  height: 34px;
}
.z-colorpalette-color {
  width: 32px;
  height: 32px;
  margin: 0px;
}
.z-colorpalette-body {
  max-height: 416px;
  overflow: auto;
  padding-top: 2px;
}
.z-colorpicker {
  padding: 4px;
}
.z-colorpicker-main {
  top: 34px;
}
.z-colorbox-popup {
  padding: 4px;
}
.z-menu-image.z-colorbox-color {
  width: 24px;
  height: 24px;
  min-width: 24px;
  min-height: 24px;
}
.z-colorbox-paletteicon,
.z-menu-paletteicon,
.z-colorbox-pickericon,
.z-menu-pickericon {
  font-size: 24px;
  width: 32px;
  height: 32px;
  line-height: 32px;
  padding: 0;
  text-align: center;
  left: 4px;
  top: 5px;
}
.z-colorbox-paletteicon,
.z-menu-paletteicon {
  left: 40px;
  top: 5px;
}
.z-palette-button .z-colorbox-paletteicon,
.z-picker-button .z-colorbox-pickericon {
  color: var(--zk-toolbar-button-checked-color);
  background-color: var(--zk-toolbar-button-checked-background-color);
}
.z-combobox,
.z-bandbox,
.z-datebox,
.z-timebox,
.z-spinner,
.z-doublespinner,
.z-timepicker {
  min-height: 32px;
}
.z-combobox-input,
.z-bandbox-input,
.z-datebox-input,
.z-timebox-input,
.z-spinner-input,
.z-doublespinner-input,
.z-timepicker-input {
  line-height: 14px;
  height: 32px;
  padding: 4px 5px;
}
.z-combobox-button,
.z-bandbox-button,
.z-datebox-button,
.z-timebox-button,
.z-spinner-button,
.z-doublespinner-button,
.z-timepicker-button {
  font-size: 20px;
  min-width: 34px;
  height: 32px;
  max-height: 32px;
  padding: 5px 6px;
  text-align: center;
  line-height: 14px;
}
.z-combobox-input:not(.z-combobox-input-full) {
  padding-right: 39px;
}
.z-bandbox-input:not(.z-bandbox-input-full) {
  padding-right: 39px;
}
.z-datebox-input:not(.z-datebox-input-full) {
  padding-right: 39px;
}
.z-timebox-input:not(.z-timebox-input-full) {
  padding-right: 39px;
}
.z-timepicker-input:not(.z-timepicker-input-full) {
  padding-right: 39px;
}
.z-spinner-input:not(.z-spinner-input-full) {
  padding-right: 69px;
}
.z-spinner-button > a {
  line-height: 32px;
}
.z-doublespinner-input:not(.z-doublespinner-input-full) {
  padding-right: 69px;
}
.z-doublespinner-button > a {
  line-height: 32px;
}
.z-timebox-button > a > i,
.z-spinner-button > a > i,
.z-doublespinner-button > a > i {
  transform: none;
}
.z-timebox-button:hover {
  border-color: var(--zk-combo-button-hover-border-color);
  background: var(--zk-combo-button-hover-background-color);
}
.z-timebox-button:hover > i {
  width: auto;
  height: auto;
  border-top-width: 0;
  position: static;
}
.z-timebox-button:active {
  color: var(--zk-combo-button-active-icon-color);
  border-color: var(--zk-combo-button-active-border-color);
  background-color: var(--zk-combo-button-active-background-color);
}
.z-spinner-button,
.z-doublespinner-button {
  width: 65px;
  padding: 0;
  border: none;
}
.z-spinner-button:hover > i,
.z-doublespinner-button:hover > i {
  border-top: none;
  position: static;
}
.z-spinner-button > a,
.z-doublespinner-button > a {
  font-size: 22px;
  width: 32px;
  height: 32px;
  padding: 2px 4px;
  border: 1px solid var(--zk-input-border-color);
  line-height: 30px;
  position: static;
  float: right;
}
.z-spinner-button > a:first-child,
.z-doublespinner-button > a:first-child {
  border-left: none;
  -webkit-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -moz-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -o-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  -ms-border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
  border-radius: 0 var(--zk-base-border-radius) var(--zk-base-border-radius) 0;
}
.z-spinner-button > a:hover,
.z-doublespinner-button > a:hover {
  border: 1px solid var(--zk-combo-button-hover-border-color);
  background: var(--zk-combo-button-hover-background-color);
}
.z-spinner-button > a:active,
.z-doublespinner-button > a:active {
  color: var(--zk-combo-button-active-icon-color);
  border: 1px solid var(--zk-combo-button-active-border-color);
  background-color: var(--zk-combo-button-active-background-color);
}
.z-timebox-disabled .z-timebox-button {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
}
.z-timebox-disabled .z-timebox-button:hover,
.z-timebox-disabled .z-timebox-button:active {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
}
.z-spinner-disabled .z-spinner-button > a {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
  background: 0 !important;
}
.z-spinner-disabled .z-spinner-button > a:hover,
.z-spinner-disabled .z-spinner-button > a:active {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
  background: 0 !important;
}
.z-doublespinner-disabled .z-doublespinner-button > a {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
  background: 0 !important;
}
.z-doublespinner-disabled .z-doublespinner-button > a:hover,
.z-doublespinner-disabled .z-doublespinner-button > a:active {
  color: var(--zk-input-disable-color) !important;
  border-color: var(--zk-input-border-color) !important;
  background: var(--zk-input-disable-background-color) !important;
  cursor: default !important;
  background: 0 !important;
}
.z-timepicker-button {
  line-height: 32px;
  padding: 3px 0;
}
.z-combobox-popup,
.z-timepicker-popup {
  overflow: hidden;
}
.z-comboitem,
.z-timepicker-option {
  font-size: 15px;
  padding: 8px;
}
.z-comboitem:after,
.z-timepicker-option:after {
  content: '';
  display: inline-block;
  vertical-align: middle;
  height: 100%;
  width: 0;
}
.z-comboitem-inner,
.z-timepicker-option-inner {
  display: block;
  font-size: 12px;
}
.z-comboitem-image,
.z-timepicker-option-image {
  float: none;
  width: 22px;
  height: 22px;
}
.z-comboitem-image:empty,
.z-timepicker-option-image:empty {
  display: none;
}
.z-datebox-input[readonly],
.z-timebox-input[readonly] {
  background: var(--zk-input-background-color);
  border-color: var(--zk-input-border-color);
}
.z-datebox-input[readonly]:focus,
.z-timebox-input[readonly]:focus {
  border-color: var(--zk-input-focus-border-color);
}
.z-timebox-popup .z-timebox-wheel-body {
  margin: 4px 0;
}
.z-timebox-wheel {
  padding: 0 2px;
}
.z-timebox-wheel-time {
  display: -webkit-box;
  display: -moz-box;
  display: box;
  -webkit-box-orient: horizontal;
  -moz-box-orient: horizontal;
  -o-box-orient: horizontal;
  -ms-box-orient: horizontal;
  box-orient: horizontal;
  width: 50%;
  position: relative;
  background: var(--zk-base-background-color);
}
.z-timebox-wheel-cave {
  position: relative;
}
.z-timebox-wheel-body {
  display: -webkit-box;
  display: -moz-box;
  display: box;
  -webkit-box-orient: horizontal;
  -moz-box-orient: horizontal;
  -o-box-orient: horizontal;
  -ms-box-orient: horizontal;
  box-orient: horizontal;
  width: 100%;
}
.z-timebox-wheel-line {
  width: 100%;
  height: 0;
  position: absolute;
  top: 50%;
  z-index: 1;
}
.z-timebox-wheel-list {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -o-box-flex: 1;
  -ms-box-flex: 1;
  box-flex: 1;
  color: var(--zk-text-color-default);
  background: var(--zk-base-background-color);
  height: 120px;
  margin: 0 1px 0 0;
  position: relative;
  overflow: hidden;
}
.z-timebox-wheel-list ul {
  width: 100%;
  margin: 0;
  padding: 0;
  position: relative;
  list-style: none;
  z-index: 2;
}
.z-timebox-wheel-list li {
  font-size: 17px;
  display: block;
  height: 40px;
  margin: 0;
  padding: 0;
  line-height: 40px;
  opacity: 0.3;
  text-align: center;
  white-space: nowrap;
  list-style: none;
}
.z-timebox-wheel-footer {
  height: 50px;
  padding: 5px 0;
  clear: both;
}
.z-timebox-wheel-button {
  font-family: var(--zk-base-content-font-family);
  font-size: 15px;
  font-weight: normal;
  font-style: normal;
  color: #000000;
  width: 45%;
  border: none;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: 8px 0;
  -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -moz-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -o-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  -ms-box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
  box-shadow: 0 3px 6px 0 rgba(0,0,0,0.16), 0 2px 4px 0 rgba(0,0,0,0.24);
}
.z-timebox-wheel-left {
  float: left;
  background: var(--zk-color-primary);
  color: var(--zk-text-color-default3);
}
.z-timebox-wheel-right {
  float: right;
  background: var(--zk-base-background-color);
  color: var(--zk-text-color-default);
  border: 1px solid var(--zk-color-grey-light);
}
li.z-timebox-wheel-list-selected {
  opacity: 1;
}
.z-columns-menupopup .z-column-content {
  padding-right: 24px;
}
.z-column-button {
  width: 24px;
  height: 32px;
  display: block;
}
.z-groupbox-content,
.z-groupbox-content > .z-label {
  font-size: 15px;
}
.z-groupbox-3d .z-caption-content,
.z-groupbox-3d .z-groupbox-title-content {
  font-size: 17px;
}
.z-groupbox-3d > .z-groupbox-header {
  padding: 3px 4px;
}
.z-groupbox-3d > .z-groupbox-header .z-caption,
.z-groupbox-3d > .z-groupbox-header .z-groupbox-title {
  padding: 10px 16px;
  display: inline-block;
  width: 100%;
  margin: 0;
  line-height: 24px;
  background: 0;
  top: 0;
  position: relative;
  cursor: pointer;
}
.z-groupbox-notitle .z-groupbox-content {
  padding: 12px 16px;
}
.z-groupbox-header,
.z-groupbox-3d .z-groupbox-header {
  line-height: 24px;
}
.z-groupbox-3d > .z-groupbox-header .z-caption-content {
  padding: 4px 0 4px 0;
  line-height: 16px;
}
.z-groupbox-3d > .z-groupbox-content {
  padding: 5px;
}
.z-listhead-menupopup .z-listheader-content {
  padding-right: 24px;
}
.z-listheader-button {
  width: 24px;
  height: 32px;
  line-height: 32px;
  font-size: 16px;
  display: block;
}
.z-listgroup-inner .z-listcell-content,
.z-listgroup-inner .z-listgroup-content {
  padding: 3px 5px;
}
.z-listgroup-icon {
  width: 24px;
  height: 24px;
  font-size: 22px;
  line-height: 22px;
}
.z-listgroup-selected .z-listgroup-checkable .z-listgroup-icon {
  font-size: 22px;
  line-height: 22px;
}
.z-listgroupfoot .z-listcell-content {
  padding: 4px 5px;
}
.z-listheader-checkable,
.z-listitem-checkable,
.z-listgroup-checkable {
  width: 24px;
  height: 24px;
  font-size: 22px;
}
.z-listitem-selected > .z-listcell > .z-listcell-content > .z-listitem-checkable .z-listitem-icon.z-icon-radio {
  width: 16px;
  height: 16px;
}
.z-textbox,
.z-decimalbox,
.z-intbox,
.z-longbox,
.z-doublebox {
  height: 32px;
}
.z-errorbox {
  cursor: move;
}
.z-errorbox-icon {
  top: -3px;
}
.z-errorbox-content {
  font-size: 15px;
  word-wrap: break-word;
}
.z-errorbox > .z-errorbox-icon {
  font-size: 22px;
  top: 6px;
}
.z-errorbox-up + .z-errorbox-icon {
  top: 14px;
}
.z-errorbox-close {
  font-size: 22px;
}
.z-menu-clickable .z-menu-separator {
  right: 26px;
}
.z-menubar {
  overflow: auto;
}
.z-paging {
  height: 40px;
  padding: 4px 12px 3px;
}
.z-paging-icon {
  font-size: 22px;
}
.z-paging-button {
  min-width: 32px;
  height: 32px;
  line-height: 24px;
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  font-size: 18px;
  padding: 4px 3px;
  margin: 0;
}
.z-paging-text {
  font-size: 14px;
  margin-right: 2px;
}
.z-paging-info {
  font-size: 14px;
  top: 0;
}
.z-paging-input {
  height: 32px;
  margin-left: 2px;
  font-size: 14px;
}
.z-paging-os ul > li {
  margin-left: 2px;
}
.z-paging-os ul > li.z-paging-navigate + li,
.z-paging-os ul > li + li.z-paging-navigate {
  margin-left: 4px;
}
.z-paging-os ul > li.z-paging-navigate + li.z-paging-navigate {
  margin-left: 2px;
}
.z-paging-os .z-paging-button {
  padding: 0 8px;
  font-size: 14px;
  height: 30px;
  min-width: 30px;
}
.z-panel-header {
  font-size: 14px;
  line-height: 30px;
}
.z-panel-icon {
  line-height: 30px;
  height: auto;
}
.z-panel-maximize,
.z-panel-minimize,
.z-panel-close,
.z-panel-expand {
  font-size: 22px;
}
.z-popup-content {
  font-size: 15px;
}
.z-notification-content {
  min-height: 0;
  font-size: 15px;
}
.z-notification-close {
  width: 22px;
  height: 22px;
  font-size: 22px;
}
.z-slider-button {
  width: 22px;
  height: 22px;
}
.z-slider-vertical .z-slider-button {
  left: -8px;
}
.z-slider-horizontal .z-slider-button {
  top: -9px;
}
.z-tab-image {
  width: 16px;
  height: 16px;
}
.z-tabbox-left > .z-tabs .z-tab .z-tab-content > .z-tab-text > .z-tab-image {
  margin-right: 4px;
}
.z-tabbox-right > .z-tabs .z-tab .z-tab-content > .z-tab-text > .z-tab-image {
  margin-right: 4px;
}
.z-tree-icon,
.z-tree-line {
  width: 24px;
  height: 24px;
  line-height: 24px;
}
.z-tree-icon {
  font-size: 20px;
}
.z-treecell-text {
  margin-left: 4px;
}
.z-treecol-content,
.z-treecell-content,
.z-treefooter-content {
  font-size: 12px;
  padding: 4px 5px;
}
.z-treecell-content {
  line-height: 22px;
}
.z-tree-body .z-tree-emptybody td {
  font-size: 15px;
  padding: 10px 12px;
}
.z-treerow-checkable {
  width: 24px;
  height: 24px;
  font-size: 22px;
}
.z-treerow-selected > .z-treecell > .z-treecell-content > .z-treerow-checkable .z-treerow-icon.z-icon-radio {
  width: 16px;
  height: 16px;
}
.z-window-header {
  font-size: 14px;
  line-height: 32px;
}
.z-window-icon {
  width: 30px;
  height: 30px;
  line-height: 30px;
}
.z-window-maximize,
.z-window-minimize,
.z-window-close {
  font-size: 22px;
}
.z-messagebox-icon {
  font-size: 24px;
  width: 24px;
  height: 24px;
  -webkit-background-size: 24px;
  -moz-background-size: 24px;
  -o-background-size: 24px;
  -ms-background-size: 24px;
  background-size: 24px;
}
.z-messagebox .z-label {
  font-size: 15px;
}
.z-nav-content,
.z-navitem-content {
  padding: 4px 8px;
}
.z-nav-info {
  font-size: 11px;
}
