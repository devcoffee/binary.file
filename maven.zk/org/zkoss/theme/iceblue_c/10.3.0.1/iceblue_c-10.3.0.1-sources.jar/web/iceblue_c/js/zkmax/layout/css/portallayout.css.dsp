<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-portallayout,
.z-portalchildren,
.z-portalchildren-content {
  overflow: hidden;
}
.z-portallayout-vertical > .z-portalchildren {
  height: 100%;
  float: left;
}
.z-portalchildren-content {
  width: 100%;
  height: 100%;
}
.z-portallayout-horizontal .z-portalchildren-content > .z-panel,
.z-portallayout-horizontal .z-portalchildren-content > .z-panel-move-block {
  float: left;
}
.z-portallayout,
.z-portalchildren {
  -ms-zoom: 1;
}
.z-portalchildren-counter {
  display: none;
  border-radius: var(--zk-portalchildren-counter-radius);
  padding: 0 var(--zk-portalchildren-counter-padding);
  margin-right: var(--zk-portalchildren-counter-padding);
  background: var(--zk-portalchildren-counter-background);
  font-size: 14px;
  font-weight: 700;
}
.z-portalchildren-counter-on {
  display: inline;
}
.z-portalchildren-frame {
  border: 1px solid var(--zk-portalchildren-frame-border-color);
  border-radius: var(--zk-portalchildren-frame-radius);
  background: var(--zk-portalchildren-frame-background-color);
  overflow: hidden;
  padding: var(--zk-portalchildren-frame-padding);
  padding-bottom: 0;
  margin-right: var(--zk-portalchildren-frame-margin);
}
.z-portalchildren-frame:last-child {
  margin-right: 0;
}
.z-portalchildren-frame > .z-portalchildren-title {
  display: block;
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel {
  background: var(--zk-portalchildren-frame-panel-background-color);
  margin-bottom: var(--zk-portalchildren-frame-panel-padding);
  position: relative;
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel:last-child {
  margin-bottom: var(--zk-portalchildren-frame-padding);
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel-header {
  color: var(--zk-portalchildren-frame-panel-header-text-color);
  padding: var(--zk-portalchildren-frame-panel-header-padding);
  font-size: var(--zk-portalchildren-frame-panel-header-text-size);
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel-drag-button {
  display: block;
  color: var(--zk-portalchildren-frame-drag-button-color);
  width: var(--zk-portalchildren-frame-drag-button-size);
  height: var(--zk-portalchildren-frame-drag-button-size);
  float: left;
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1;
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel-collapsed .z-panel-drag-button {
  position: relative;
}
.z-portalchildren-frame > .z-portalchildren-content .z-panel .z-panelchildren {
  padding: var(--zk-portalchildren-frame-panel-children-padding);
}
.z-portalchildren-title {
  display: none;
  font-family: var(--zk-portalchildren-frame-title-font-family);
  font-size: var(--zk-portalchildren-frame-title-font-size);
  font-weight: normal;
  font-style: normal;
  color: var(--zk-portalchildren-frame-title-font-color);
  border: 0;
  overflow: hidden;
  padding-bottom: var(--zk-portalchildren-frame-padding);
}
.z-portallayout-horizontal > .z-portalchildren {
  height: 100%;
}
.z-portallayout-horizontal > .z-portalchildren-frame {
  float: left;
  clear: both;
  margin-bottom: var(--zk-portalchildren-frame-padding);
}
.z-portallayout-horizontal > .z-portalchildren-frame:last-child {
  margin-bottom: 0;
}
.z-portallayout-horizontal > .z-portalchildren-frame > .z-portalchildren-content > .z-panel {
  margin-right: var(--zk-portalchildren-frame-panel-padding);
}
.z-portallayout-horizontal > .z-portalchildren-frame > .z-portalchildren-content > .z-panel:last-child {
  margin-right: 0;
}
.z-portallayout-popup {
  font-family: var(--zk-base-content-font-family);
  font-weight: normal;
  font-size: var(--zk-font-size-medium);
  display: none;
  color: var(--zk-text-color-default);
  border: 1px solid var(--zk-combo-popup-border-color);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
  padding: var(--zk-comboitem-padding);
  background: var(--zk-popup-background-color);
  position: absolute;
  overflow: auto;
  min-height: 10px;
}
.z-portallayout-popup-content {
  border: 0;
  padding: 0;
  margin: 0;
  background: transparent none repeat 0 0;
  position: relative;
  list-style: none outside none;
  min-width: 100%;
  display: inline-block;
}
.z-portallayout-popup-nav {
  cursor: pointer;
  padding: var(--zk-comboitem-padding);
  -webkit-border-radius: var(--zk-base-border-radius);
  -moz-border-radius: var(--zk-base-border-radius);
  -o-border-radius: var(--zk-base-border-radius);
  -ms-border-radius: var(--zk-base-border-radius);
  border-radius: var(--zk-base-border-radius);
}
.z-portallayout-popup-nav:focus {
  background-color: var(--zk-color-primary-lighter);
}
.z-portallayout-popup-open {
  display: block;
}
