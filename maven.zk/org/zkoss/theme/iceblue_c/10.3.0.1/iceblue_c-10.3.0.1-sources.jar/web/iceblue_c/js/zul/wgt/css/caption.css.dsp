<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-caption {
  background-color: transparent;
  font-size: var(--zk-caption-font-size);
  width: 100%;
  height: auto;
  min-height: var(--zk-base-button-height);
  line-height: normal;
}
.z-caption-content,
.z-caption .z-label {
  display: inline-block;
  line-height: var(--zk-base-button-height);
}
.z-caption-content {
  padding: 4px 0;
}
.z-caption-content > * {
  margin-left: var(--zk-caption-elements-margin);
}
.z-caption-content > *:first-child {
  margin-left: 0;
}
.z-caption-label {
  margin: 0 2px;
}
.z-caption .z-label {
  padding: 0;
}
.z-caption-image {
  vertical-align: middle;
  height: var(--zk-caption-image-max-size);
  width: var(--zk-caption-image-max-size);
}
.z-caption input {
  font-size: var(--zk-font-size-small);
}
.z-caption .z-toolbar .z-a,
.z-caption .z-toolbar .z-a:visited,
.z-caption .z-toolbar .z-a:hover {
  color: #FFFFFF;
  border: 0;
  background: none;
}
.z-caption .z-button {
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  -o-box-shadow: none;
  -ms-box-shadow: none;
  box-shadow: none;
  padding: var(--zk-caption-button-padding);
  font-size: var(--zk-caption-button-font-size);
}
.z-caption .z-a,
.z-caption .z-a:visited {
  font-size: var(--zk-font-size-small);
  font-weight: normal;
  color: var(--zk-base-text-color);
  background: none;
  text-decoration: none;
}
.z-caption .z-a:hover {
  text-decoration: underline;
}
