<%@ taglib uri="http://www.zkoss.org/dsp/web/core" prefix="c" %>
<%@ taglib uri="http://www.zkoss.org/dsp/zk/core" prefix="z" %>
<%@ taglib uri="http://www.zkoss.org/dsp/web/theme" prefix="t" %>
.z-barcodescanner {
  display: inline-block;
  background: black;
  position: relative;
}
.z-barcodescanner-video {
  height: 100%;
  width: 100%;
}
.z-barcodescanner-canvas {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto auto;
  width: 100%;
  height: 100%;
}
