package org.zkoss.zk;

import java.lang.String;

public final class Version {
  public static final String UID = "10.3.0.1";

  public static final String RELEASE = "10.3.0.1";

  private Version() {
  }
}
